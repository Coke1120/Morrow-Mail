#include "pch.h"
#include "Ui.h"
#include <winrt/Windows.Globalization.h>
#include <winrt/Microsoft.UI.Xaml.Automation.h>
#include <winrt/Microsoft.UI.Xaml.Automation.Peers.h>
#include <cmath>
#include <cwchar>
#include <cwctype>
#include <map>
#include <set>
#include <string_view>

namespace morrow {
using namespace winrt;
using namespace Windows::Foundation;
using namespace Windows::Data::Json;
using namespace controls;
IAsyncAction intelligencePage(std::shared_ptr<Shell> shell, hstring kind);
namespace {
Json clone(Json const& value) { return Json::Parse(value.Stringify()); }
Json subset(Json const& source, std::initializer_list<wchar_t const*> keys) {
    Json result;
    for (auto key : keys) if (auto item = source.TryLookup(key)) result.Insert(key, item);
    return clone(result);
}
void truth(Json const& target, wchar_t const* key, bool value) { target.Insert(key, Value::CreateBooleanValue(value)); }
bool checked(CheckBox const& control) { auto value = control.IsChecked(); return value && value.Value(); }
hstring count(Json const& value, wchar_t const* key) {
    auto item = value.TryLookup(key);
    return item && item.ValueType() == JsonValueType::Number ? item.Stringify() : L"0";
}
void require(bool value, wchar_t const* message) { if (!value) throw hresult_error(E_INVALIDARG, message); }
hstring trim(hstring const& text) {
    std::wstring value(text); auto first = value.find_first_not_of(L" \t\r\n");
    if (first == std::wstring::npos) return {};
    return hstring(value.substr(first, value.find_last_not_of(L" \t\r\n") - first + 1));
}
hstring bounded(hstring const& value, size_t maximum = 64000) {
    if (value.size() <= maximum) return value;
    auto end = maximum;
    if (end && value.c_str()[end - 1] >= 0xd800 && value.c_str()[end - 1] <= 0xdbff) --end;
    return hstring(value.c_str(), static_cast<uint32_t>(end)) + L"\n[Display limit reached]";
}
void words(StackPanel const& panel, hstring const& value, double size = 14) {
    auto control = label(bounded(value), size); control.IsTextSelectionEnabled(true); panel.Children().Append(control);
}
StackPanel group(StackPanel const& parent, hstring const& heading) {
    auto panel = stack(10); words(panel, heading, 20); parent.Children().Append(panel); return panel;
}
hstring aliasesText(Json const& identity) {
    hstring result;
    for (auto const& name : array(identity, L"aliases")) result = result + (result.empty() ? L"" : L"\n") + name.GetString();
    return result;
}
Array aliases(hstring const& text) {
    Array result; std::wstring value(text); size_t start = 0;
    while (start <= value.size()) {
        auto end = value.find(L'\n', start);
        auto name = trim(hstring(value.substr(start, end == std::wstring::npos ? value.size() - start : end - start)));
        if (!name.empty()) {
            require(name.size() <= 100 && result.Size() < 10, L"Use at most 10 aliases, each at most 100 characters.");
            result.Append(Value::CreateStringValue(name));
        }
        if (end == std::wstring::npos) break;
        start = end + 1;
    }
    return result;
}
Json identityFields(Json const& identity) {
    Json value; put(value, L"displayName", text(identity, L"displayName")); put(value, L"aliasesText", aliasesText(identity));
    truth(value, L"confirmed", flag(identity, L"confirmed")); return value;
}

struct Editor {
    Json value, saved;
    bool initializing = false;
    std::map<std::wstring, weak_ref<TextBox>> fields;
    std::map<std::wstring, weak_ref<CheckBox>> toggles;
    std::map<std::wstring, weak_ref<NumberBox>> numbers;
    std::map<std::wstring, weak_ref<ComboBox>> choices;
    bool dirty() const { return value.Stringify() != saved.Stringify(); }
    void show() {
        initializing = true;
        for (auto const& [key, weak] : fields) if (auto control = weak.get()) control.Text(text(value, key.c_str()));
        for (auto const& [key, weak] : toggles) if (auto control = weak.get()) control.IsChecked(flag(value, key.c_str()));
        for (auto const& [key, weak] : numbers) if (auto control = weak.get()) control.Value(value.GetNamedNumber(key, 0));
        for (auto const& [key, weak] : choices) if (auto control = weak.get()) {
            auto selected = value.TryLookup(key); if (!selected) continue;
            for (uint32_t i = 0; i < control.Items().Size(); ++i) {
                auto item = control.Items().GetAt(i).as<ComboBoxItem>();
                if (unbox_value<hstring>(item.Tag()) == selected.Stringify()) control.SelectedIndex(static_cast<int32_t>(i));
            }
        }
        initializing = false;
    }
    void accept(Json const& next) { value = clone(next); saved = clone(next); show(); }
    void acceptSubmitted(Json const& submitted, Json const& next) {
        bool unchanged = value.Stringify() == submitted.Stringify();
        saved = clone(next);
        if (unchanged) value = clone(next);
        show();
    }
};
struct Intelligence : std::enable_shared_from_this<Intelligence> {
    std::shared_ptr<Shell> shell;
    hstring owner, kind, previewVoiceId, learningPaint, suggestionPaint, connection, context;
    uint64_t generation = 0, revision = 0, learningRevision = 0;
    bool live = true, busy = false, polling = false, cancelling = false, generatingStyle = false, selecting = false, agentRecovering = false;
    Json state, suggestions, workflow, output, outputMessage, outputSource, memoryPreview;
    std::set<std::wstring> selectedMemories, editingRules;
    weak_ref<StackPanel> categoryEditor;
    weak_ref<Expander> skillEditor;
    weak_ref<StackPanel> memoryPanel, writingRuleList;
    hstring outputAction, outputContext, workflowContext, workflowOwner;
    std::map<std::wstring, Editor> forms;
    std::set<std::wstring> selectedCandidates;
    weak_ref<StackPanel> body, previewPanel, proposalPanel, candidatePanel, jobPanel, resultPanel, skillList, categoryList, recordList;
    weak_ref<StackPanel> toolPanel;
    weak_ref<ContentControl> editorHost, suggestionOptions;
    TextBlock notice{nullptr};
    weak_ref<ComboBox> messagePicker, featurePicker, skillPicker;
    weak_ref<DatePicker> date;
    weak_ref<TimePicker> time;
    weak_ref<Button> cancelStyle;
    std::vector<Json> messages, features;
    std::vector<hstring> cursors{L""};
    hstring nextCursor;
    xaml::DispatcherTimer timer{nullptr};
    std::wstring key() const { return L"intelligence:" + std::to_wstring(generation); }
    bool current() const { return live && !shell->closing && generation == shell->generation && (owner == L"all" || shell->connected(owner)); }
    void tell(hstring const& value) { if (current()) if (auto control = notice) control.Text(value); }
    bool edited() const { for (auto const& [_, form] : forms) if (form.dirty()) return true; return false; }
    bool writingRulesEdited() const {
        for (auto const& [name, form] : forms) if (name.starts_with(L"writingRule:") && form.dirty()) return true;
        return false;
    }
    void dirty() {
        if (!live) return;
        if (busy || cancelling || edited()) shell->dirty.insert(key()); else shell->dirty.erase(key());
    }
    void clearResult() {
        workflow = Json(); output = Json(); outputMessage = Json(); outputSource = Json(); memoryPreview = Json(); selectedMemories.clear();
        if (auto panel = memoryPanel.get()) panel.Children().Clear();
        if (auto panel = resultPanel.get()) panel.Children().Clear();
    }
    void changed(std::wstring const& formName) {
        if (!current()) return;
        if (formName == L"tool" || formName == L"rule") clearResult();
        ++revision; dirty();
    }
    void stop() {
        if (!live) return; live = false; ++revision; ++learningRevision;
        if (timer) { timer.Stop(); timer = nullptr; }
        if (!busy && !cancelling) shell->dirty.erase(key());
        // TextBlock peers stay retained until root.Unloaded; other control references are weak.
        // Service-owned reviewed background jobs continue normally.
    }
};
using Page = std::shared_ptr<Intelligence>;

hstring connectionOf(Json const& state, hstring const& owner) {
    for (auto const& entry : array(state, L"accounts")) {
        auto account = entry.GetObject();
        if (text(account, L"id") == owner) return object(account, L"settings").Stringify();
    }
    return {};
}
hstring contextOf(Json const& state, hstring const& owner) {
    Json context;
    context.Insert(L"settings", subset(object(state, L"settings"), {L"policy", L"ai", L"preferences"}));
    auto workspace = object(state, L"workspace"), learning = object(workspace, L"styleLearning");
    context.Insert(L"search",object(object(state,L"settings"),L"searchAI"));
    context.Insert(L"brain", object(workspace, L"brain")); context.Insert(L"skills", array(workspace, L"skills"));
    context.Insert(L"style", object(learning, L"profile")); context.Insert(L"identity", object(object(learning, L"settings"), L"identity"));
    put(context, L"connection", connectionOf(state, owner)); return context.Stringify();
}
bool ownedState(Page const& p, Json const& next) {
    return text(object(next, L"account"), L"id") == p->owner && (p->owner == L"all" || !connectionOf(next, p->owner).empty());
}
void acceptState(Page const& p, Json const& next) {
    require(ownedState(p, next), L"The mailbox connection changed. Reopen this page from the original account.");
    auto context = contextOf(next, p->owner);
    if (!p->context.empty() && p->context != context) p->clearResult();
    p->state = clone(next); p->context = context; p->connection = connectionOf(next, p->owner);
    if (p->owner == p->shell->owner) p->shell->state = clone(next);
    else if (next.HasKey(L"today")) p->shell->state.Insert(L"today", object(next, L"today"));
}
void validateContext(Page const& p, hstring const& captured) {
    auto const& source = p->owner == p->shell->owner ? p->shell->state : p->state;
    require(p->current() && p->context == captured && contextOf(source, p->owner) == captured,
        L"The account, model, identity or permissions changed. Review fresh context before continuing.");
}
Editor& editor(Page const& p, wchar_t const* name, Json const& value) {
    auto& form = p->forms[name]; form.accept(value); return form;
}
TextBox editText(Page const& p, StackPanel const& panel, wchar_t const* formName, wchar_t const* key, wchar_t const* caption, int limit, bool multiline = false) {
    auto control = field(caption, text(p->forms[formName].value, key), multiline); control.MaxLength(limit);
    p->forms[formName].fields[key] = make_weak(control); std::weak_ptr<Intelligence> weak = p;
    control.TextChanged([weak, form = std::wstring(formName), key = std::wstring(key)](auto const& sender, auto const&) {
        if (auto p = weak.lock(); p && p->current() && !p->forms[form].initializing) {
            auto& edit = p->forms[form]; put(edit.value, key.c_str(), sender.template as<TextBox>().Text());
            if (form == L"identity" && key != L"confirmed") {
                truth(edit.value, L"confirmed", false);
                if (auto box = edit.toggles[L"confirmed"].get()) box.IsChecked(false);
            }
            p->changed(form);
        }
    }); panel.Children().Append(control); return control;
}
CheckBox editCheck(Page const& p, StackPanel const& panel, wchar_t const* formName, wchar_t const* key, hstring caption) {
    CheckBox control; control.Content(box_value(caption)); control.IsChecked(flag(p->forms[formName].value, key));
    p->forms[formName].toggles[key] = make_weak(control); std::weak_ptr<Intelligence> weak = p;
    control.Click([weak, form = std::wstring(formName), key = std::wstring(key)](auto const& sender, auto const&) {
        if (auto p = weak.lock(); p && p->current() && !p->forms[form].initializing) {
            truth(p->forms[form].value, key.c_str(), checked(sender.template as<CheckBox>()));
            if (form == L"learning" && key == L"enabled" && !flag(p->forms[form].value, L"enabled")) {
                truth(p->forms[form].value, L"weekly", false);
                if (auto box = p->forms[form].toggles[L"weekly"].get()) box.IsChecked(false);
                truth(p->forms[form].value, L"daily", false);
                if (auto box = p->forms[form].toggles[L"daily"].get()) box.IsChecked(false);
            }
            if (form == L"learning" && key == L"daily" && flag(p->forms[form].value, L"daily")) {
                truth(p->forms[form].value, L"weekly", false);
                if (auto box = p->forms[form].toggles[L"weekly"].get()) box.IsChecked(false);
            }
            p->changed(form);
        }
    }); panel.Children().Append(control); return control;
}
void editNumber(Page const& p, StackPanel const& panel, wchar_t const* formName, wchar_t const* key, wchar_t const* caption, double minimum, double maximum, double step = 1) {
    NumberBox control; control.Header(box_value(caption)); control.Minimum(minimum); control.Maximum(maximum); control.SmallChange(step);
    control.SpinButtonPlacementMode(NumberBoxSpinButtonPlacementMode::Compact); control.Value(p->forms[formName].value.GetNamedNumber(key, minimum));
    p->forms[formName].numbers[key] = make_weak(control); std::weak_ptr<Intelligence> weak = p;
    control.ValueChanged([weak, form = std::wstring(formName), key = std::wstring(key)](NumberBox const& sender, auto const&) {
        if (auto p = weak.lock(); p && p->current() && !p->forms[form].initializing) {
            p->forms[form].value.Insert(key, std::isfinite(sender.Value()) ? Value::CreateNumberValue(sender.Value()) : Value::CreateNullValue()); p->changed(form);
        }
    }); panel.Children().Append(control);
}
ComboBox editChoice(Page const& p, StackPanel const& panel, wchar_t const* formName, wchar_t const* key, wchar_t const* caption,
    std::initializer_list<std::pair<wchar_t const*, wchar_t const*>> choices, bool numeric = false) {
    ComboBox control; control.Header(box_value(caption)); control.HorizontalAlignment(xaml::HorizontalAlignment::Stretch);
    auto value = p->forms[formName].value.TryLookup(key);
    for (auto const& [id, title] : choices) {
        auto stored = numeric ? Value::CreateNumberValue(std::stod(id)) : Value::CreateStringValue(id);
        ComboBoxItem item; item.Content(box_value(title)); item.Tag(box_value(stored.Stringify())); control.Items().Append(item);
        if (value && value.Stringify() == stored.Stringify()) control.SelectedItem(item);
    }
    p->forms[formName].choices[key] = make_weak(control); std::weak_ptr<Intelligence> weak = p;
    control.SelectionChanged([weak, form = std::wstring(formName), key = std::wstring(key)](auto const& sender, auto const&) {
        if (auto p = weak.lock(); p && p->current() && !p->forms[form].initializing) {
            auto item = sender.template as<ComboBox>().SelectedItem().template try_as<ComboBoxItem>();
            if (item) { p->forms[form].value.Insert(key, Value::Parse(unbox_value<hstring>(item.Tag()))); p->changed(form); }
        }
    }); panel.Children().Append(control); return control;
}

// Keeping the callable in this coroutine frame also keeps coroutine-lambda
// captures alive across awaits. Buttons themselves capture only a weak page.
fire_and_forget perform(Page p, std::function<IAsyncAction(Page)> task) {
    if (!p->current() || p->busy || p->cancelling || p->shell->loading) co_return;
    p->busy = true; ++p->revision; p->dirty(); p->tell(L"Working…");
    // Disable the editor only. Sidebar and review-account tabs stay available during AI.
    if (auto host = p->editorHost.get()) host.IsEnabled(false);
    try { co_await task(p); }
    catch (ApiError const& error) {
        if (error.status == 403 || error.status == 409 || error.status == 404) p->clearResult();
        p->tell(error.message());
    }
    catch (hresult_error const& error) { p->tell(error.message()); }
    catch (...) { p->tell(L"The request could not finish. Your saved data is retained. Retry only after reviewing its status."); }
    p->busy = false; p->generatingStyle = false;
    if (auto cancel = p->cancelStyle.get()) cancel.IsEnabled(false);
    if (p->current()) { if (auto host = p->editorHost.get()) host.IsEnabled(!p->cancelling && !p->agentRecovering); p->dirty(); }
    else p->shell->dirty.erase(p->key());
}
Button action(Page const& p, StackPanel const& panel, hstring const& caption, std::function<IAsyncAction(Page)> task) {
    std::weak_ptr<Intelligence> weak = p;
    auto control = button(caption, [weak, task = std::move(task)] { if (auto p = weak.lock()) perform(p, task); });
    panel.Children().Append(control); return control;
}
MenuFlyoutItem menuAction(Page const& p, MenuFlyout const& menu, hstring const& caption, std::function<IAsyncAction(Page)> task) {
    auto item = menuItem(caption, [weak = std::weak_ptr<Intelligence>(p), task = std::move(task)] { if (auto page = weak.lock()) perform(page, task); });
    menu.Items().Append(item); return item;
}
IAsyncAction changePage(Page p, hstring target) {
    if (!p->current() || p->busy || p->cancelling) co_return;
    if (p->edited() && !(co_await p->shell->confirm(L"Discard unsaved edits?", L"Only explicitly saved settings, styles and workspace notes take effect.", L"Discard"))) co_return;
    if (!p->current()) co_return;
    auto shell = p->shell; p->stop();
    if (target == L"reply-suggestions" || target == L"agent" || target == L"skills" || target == L"today" || target == L"brain" || target == L"categories" || target == L"learning") {
        if (target == L"reply-suggestions") shell->review->scope = p->owner;
        co_await shell->navigate(target);
        co_return;
    }
    co_await intelligencePage(shell, target);
}
void renderLearning(Page const& p);
void renderSuggestions(Page const& p);
void renderSkills(Page const& p);
void renderRecords(Page const& p);
IAsyncAction loadMessages(Page p);
void renderTool(Page const& p);

Json learning(Page const& p) { return object(object(p->state, L"workspace"), L"styleLearning"); }
Json learningFields(Json const& value) { return subset(object(value, L"settings"), {L"enabled", L"weekly", L"daily", L"months", L"maxSamples", L"tokenBudget"}); }
void updateLearningForms(Page const& p, bool settings = false, bool identity = false) {
    auto value = learning(p);
    if (settings || !p->forms[L"learning"].dirty()) p->forms[L"learning"].accept(learningFields(value));
    if (identity || !p->forms[L"identity"].dirty()) p->forms[L"identity"].accept(identityFields(object(object(value, L"settings"), L"identity")));
    renderLearning(p); p->dirty();
}
hstring learningReview(Page const& p, Json const& preview) {
    auto model = object(object(p->state, L"settings"), L"ai");
    auto result = L"Account: " + p->owner + L" · your downloaded Sent bodies only\nModel: " + text(model, L"model") + L"\nEndpoint: " + text(model, L"baseUrl") +
        L"\n" + count(preview, L"sampleCount") + L" / " + count(preview, L"eligible") + L" useful samples · cap " + count(preview, L"effectiveCap") +
        L"\nEstimated tokens ≤ " + count(preview, L"estimatedTokens") + L" · budget " + count(preview, L"tokenBudget") +
        L"\nQuote/signature removal is heuristic. Review all samples on the page. This generates a proposal only; your approved style remains until Save approved style.";
    uint32_t i = 0;
    for (auto const& sample : array(preview, L"samples")) { if (i++ == 2) break; result = result + L"\n\nSample excerpt:\n" + bounded(text(sample.GetObject(), L"body"), 200); }
    return result;
}
IAsyncAction generateStyle(Page p) {
    require(!p->edited(), L"Save or discard settings, identity and proposal edits before analysis.");
    auto value = learning(p), preview = object(value, L"preview");
    require(flag(value, L"permitted") && flag(object(value, L"settings"), L"enabled") && text(preview, L"status") == L"prepared", L"Prepare valid samples using saved opt-in and permitted Sent body access first.");
    auto id = text(preview, L"id"), context = p->context;
    if (!(co_await p->shell->confirm(L"Analyze these samples — uses AI?", learningReview(p, preview), L"Generate style proposal")) || !p->current()) co_return;
    validateContext(p, context);
    auto epoch = ++p->learningRevision; p->generatingStyle = true;
    if (auto cancel = p->cancelStyle.get()) cancel.IsEnabled(true);
    p->tell(L"Analyzing reviewed Sent samples. Cancel revokes the result; provider tokens may already be used.");
    Json body; put(body, L"previewId", id);
    auto result = co_await p->shell->service->request(L"/style/generate", p->owner, L"POST", body);
    if (!p->current() || epoch != p->learningRevision) co_return;
    acceptState(p, result); renderLearning(p); p->tell(L"Analysis finished. Review the proposal before Save approved style.");
}
IAsyncAction previewStyle(Page p, bool analyze) {
    require(!p->edited(), L"Save or discard settings, identity and proposal edits before preparing samples.");
    if (!flag(object(learning(p), L"settings"), L"enabled")) {
        if (!(co_await p->shell->confirm(L"Enable writing-style learning?", p->owner + L"\nOnly downloaded Sent bodies are used. You will review samples before the AI call and approve a style before it affects drafts or replies. Provider charges may apply.", L"Enable learning")) || !p->current()) co_return;
        auto settings = learningFields(learning(p)); truth(settings, L"enabled", true);
        auto enabled = co_await p->shell->service->request(L"/style/settings", p->owner, L"POST", settings);
        if (!p->current()) co_return;
        acceptState(p, enabled); updateLearningForms(p, true);
    }
    auto preview = object(learning(p), L"preview");
    if (text(preview, L"status") == L"ready" && !(co_await p->shell->confirm(L"Replace the current style proposal?", L"Your approved style is retained. The unsaved proposal will be replaced by a new reviewed selection.", L"Replace proposal"))) co_return;
    if (!p->current()) co_return;
    auto result = co_await p->shell->service->request(L"/style/preview", p->owner, L"POST");
    if (!p->current()) co_return;
    acceptState(p, result); renderLearning(p);
    p->tell(L"Samples prepared locally. No AI call has been made.");
    if (analyze) co_await generateStyle(p);
}
fire_and_forget revokeStyle(Page p) {
    if (!p->current() || p->cancelling) co_return;
    p->cancelling = true; p->dirty();
    auto settings = learningFields(learning(p));
    try {
        if (co_await p->shell->confirm(L"Cancel analysis / discard preview?", L"The preview and any pending result are revoked. The approved style and confirmed identity remain. An in-flight model request may still finish and use tokens.", L"Revoke preview")) {
            if (p->current()) {
                ++p->learningRevision; ++p->revision;
                auto result = co_await p->shell->service->request(L"/style/settings", p->owner, L"POST", settings);
                if (p->current()) { acceptState(p, result); renderLearning(p); p->tell(L"Preview revoked. Approved style retained; any provider request already underway may still consume tokens."); }
            }
        }
    } catch (hresult_error const& error) { p->tell(error.message()); }
    catch (...) { p->tell(L"Preview revocation was not confirmed. Refresh before retrying."); }
    p->cancelling = false;
    if (p->live) p->dirty(); else if (!p->busy) p->shell->dirty.erase(p->key());
}
void renderLearning(Page const& p) {
    auto panel = p->previewPanel.get(); if (!panel) return;
    auto value = learning(p), preview = object(value, L"preview"), profile = object(value, L"profile");
    auto signature = value.Stringify();
    if (signature == p->learningPaint) return;
    auto id = text(preview, L"id");
    auto readyId = text(preview, L"status") == L"ready" ? id : hstring();
    if (readyId != p->previewVoiceId) {
        if (!p->previewVoiceId.empty() && p->forms[L"voice"].dirty()) p->tell(L"The proposal changed or was revoked; its stale editor has been cleared.");
        Json voice; put(voice, L"voice", readyId.empty() ? hstring() : text(preview, L"voice")); p->forms[L"voice"].accept(voice); p->previewVoiceId = readyId;
    }
    p->learningPaint = signature; panel.Children().Clear();
    words(panel, flag(object(value, L"settings"), L"daily") ? L"Sent review: Daily" : flag(object(value, L"settings"), L"weekly") ? L"Sent review: Legacy weekly" : L"Sent review: Manual", 12);
    words(panel, flag(value, L"permitted") ? L"Saved opt-in and source permissions are ready." : L"Requires saved Learning opt-in, AI enabled, writing style and notes, Sent and body access. Import Sent mail in Mail settings if needed.");
    if (profile.Size()) { words(panel, flag(profile, L"active") ? L"Approved style — active for writing / replies" : L"Approved style — inactive under current permissions or changed source scope", 18); words(panel, text(profile, L"voice")); }
    else words(panel, L"No approved learned style.");
    if (!preview.Size()) { words(panel, L"No valid preview. Prepare samples to review them without making an AI call."); p->dirty(); return; }
    words(panel, text(preview, L"status") + L" · " + count(preview, L"sampleCount") + L" / " + count(preview, L"eligible") + L" useful samples", 18);
    words(panel, L"Estimated tokens ≤ " + count(preview, L"estimatedTokens") + L" · budget " + count(preview, L"tokenBudget") + L" · effective cap " + count(preview, L"effectiveCap"));
    if (!text(preview, L"error").empty()) words(panel, text(preview, L"error"));
    Expander samples; samples.Header(box_value(L"Review exact selected Sent text")); auto list = stack(10);
    uint32_t i = 0; for (auto const& sample : array(preview, L"samples")) {
        require(++i <= 50 && text(sample.GetObject(), L"body").size() <= 12000, L"The learning review exceeds its supported bounds. Prepare a smaller selection.");
        words(list, L"Sample " + to_hstring(i), 16); words(list, text(sample.GetObject(), L"body"));
    }
    samples.Content(scroll(list)); panel.Children().Append(samples);
    if (text(preview, L"status") == L"prepared") action(p, panel, L"Analyze reviewed samples — uses AI…", generateStyle);
    if (text(preview, L"status") == L"ready") {
        editText(p, panel, L"voice", L"voice", L"Review and edit proposed writing style", 2000, true);
        words(panel, L"Provider-reported tokens: " + count(object(preview, L"usage"), L"total_tokens"));
        action(p, panel, L"Save approved style…", [id](Page page) -> IAsyncAction {
            require(!page->forms[L"learning"].dirty() && !page->forms[L"identity"].dirty(), L"Save or discard Learning settings and identity edits first.");
            auto voice = trim(text(page->forms[L"voice"].value, L"voice")); require(!voice.empty() && voice.size() <= 2000, L"Approved style must contain 1–2,000 characters.");
            if (!(co_await page->shell->confirm(L"Activate this approved writing style?", page->owner + L"\n\n" + voice + L"\n\nThis informs writing/replies under writing style and notes permissions. Saved contacts, notes and manual voice remain unchanged.", L"Save approved style")) || !page->current()) co_return;
            Json body; put(body, L"previewId", id); put(body, L"voice", voice);
            auto result = co_await page->shell->service->request(L"/style/apply", page->owner, L"POST", body);
            if (page->current()) { acceptState(page, result); renderLearning(page); page->tell(L"Approved writing style saved."); }
        });
    }
    p->dirty();
}

void buildLearning(Page const& p, StackPanel const& body) {
    words(body, L"Writing voice", 24);
    words(body, L"Learn from your own downloaded Sent mail. Approve the proposed style before AI drafts and replies use it.");
    editor(p, L"learning", learningFields(learning(p)));
    editor(p, L"identity", identityFields(object(object(learning(p), L"settings"), L"identity")));
    Json voice; put(voice, L"voice", L""); editor(p, L"voice", voice);
    auto preview = stack(10); body.Children().Append(preview); p->previewPanel = make_weak(preview);
    action(p, body, L"Learn Now — review before AI…", [](Page page) { return previewStyle(page, true); });
    action(p, body, L"Change daily Sent review…", [](Page page) -> IAsyncAction {
        require(!page->edited(), L"Save or discard edits before changing daily review.");
        auto settings = learningFields(learning(page)); bool enable = !flag(settings, L"daily");
        truth(settings, L"enabled", true); truth(settings, L"weekly", false); truth(settings, L"daily", enable);
        if (enable && !(co_await page->shell->confirm(L"Enable daily Sent review?", page->owner + L"\nModel: " + text(object(object(page->state, L"settings"), L"ai"), L"model") + L"\nBudget: " + count(settings, L"tokenBudget") + L" estimated tokens per analysis. Runs while Morrow is open; each proposal waits for your approval. Provider charges may apply.", L"Enable daily review"))) co_return;
        if (!page->current()) co_return;
        auto state = co_await page->shell->service->request(L"/style/settings", page->owner, L"POST", settings);
        if (!page->current()) co_return;
        acceptState(page, state); updateLearningForms(page, true);
        page->tell(enable ? L"Daily Sent review enabled." : L"Daily Sent review paused.");
    });
    words(body, L"Daily checks run only while Morrow is open. Each paid proposal waits for review and approval.", 12);
    Expander more; more.Header(box_value(L"More learning options")); auto extra=stack(10); more.Content(extra); body.Children().Append(more);
    action(p, extra, L"Preview Sent samples — no AI call", [](Page page) { return previewStyle(page, false); });
    action(p, extra, L"Discard preview (retain approved style)…", [](Page page) -> IAsyncAction {
        if (!(co_await page->shell->confirm(L"Discard the style preview?", L"The approved style and confirmed identity are retained. Pending results will be revoked.", L"Discard preview")) || !page->current()) co_return;
        auto result = co_await page->shell->service->request(L"/style/settings", page->owner, L"POST", learningFields(learning(page)));
        if (page->current()) { ++page->learningRevision; acceptState(page, result); renderLearning(page); page->tell(L"Preview discarded. Approved style retained."); }
    });
    Expander configuration; configuration.Header(box_value(L"Learning configuration")); auto options=stack(12); configuration.Content(options); body.Children().Append(configuration);
    editCheck(p, options, L"learning", L"enabled", L"Enable writing-style learning for this account");
    editCheck(p, options, L"learning", L"daily", L"Review newly sent mail daily within the saved budget");
    if (flag(object(learning(p), L"settings"), L"weekly")) editCheck(p, options, L"learning", L"weekly", L"Keep legacy weekly review (turn off to pause)");
    words(options, L"The first eligible analysis starts after enabling, then updates use new cached Sent mail at most daily while Morrow is open. Every proposal still needs review and Save. It pauses while a preview awaits review; no automatic retry of failed paid jobs.");
    editChoice(p, options, L"learning", L"months", L"Sent history", {{L"1", L"Last month"}, {L"3", L"Last 3 months"}, {L"6", L"Last 6 months"}, {L"12", L"Last 12 months"}}, true);
    editNumber(p, options, L"learning", L"maxSamples", L"Maximum samples (also limited by AI & privacy)", 1, 50);
    editNumber(p, options, L"learning", L"tokenBudget", L"Estimated token budget per analysis", 4000, 64000, 1000);
    action(p, options, L"Save Learning settings…", [](Page page) -> IAsyncAction {
        auto body = clone(page->forms[L"learning"].value);
        auto review = L"Account: " + page->owner + L"\nLearning: " + (flag(body, L"enabled") ? hstring(L"enabled") : hstring(L"disabled")) + L"\nAutomatic analysis: " + (flag(body, L"daily") ? hstring(L"daily") : flag(body, L"weekly") ? hstring(L"weekly") : hstring(L"off")) + L"\nSample cap " + count(body, L"maxSamples") + L" · last " + count(body, L"months") + L" months · budget " + count(body, L"tokenBudget") + L"\nExisting preview is discarded; approved style retained.";
        if (!(co_await page->shell->confirm(L"Save Learning settings?", review, L"Save settings")) || !page->current()) co_return;
        auto result = co_await page->shell->service->request(L"/style/settings", page->owner, L"POST", body);
        if (page->current()) { acceptState(page, result); updateLearningForms(page, true); page->tell(L"Learning settings saved. No immediate analysis was started."); }
    });
    Expander identityPanel; identityPanel.Header(box_value(L"Your confirmed identity for this account"));
    auto identity = stack(12); identityPanel.Content(identity); body.Children().Append(identityPanel);
    words(identity, L"Include only names that refer to you, including names used in group mail. Editing either field resets confirmation. Saving identity does not enable Learning or require Sent access.");
    editText(p, identity, L"identity", L"displayName", L"Your display name", 100);
    editText(p, identity, L"identity", L"aliasesText", L"Other names / nicknames — one per line, at most 10", 1100, true);
    editCheck(p, identity, L"identity", L"confirmed", L"I confirm that this name and these aliases identify me for this account");
    action(p, identity, L"Save identity — no AI call…", [](Page page) -> IAsyncAction {
        auto form = page->forms[L"identity"].value; Json identity;
        put(identity, L"displayName", trim(text(form, L"displayName"))); identity.Insert(L"aliases", aliases(text(form, L"aliasesText"))); truth(identity, L"confirmed", flag(form, L"confirmed"));
        if (!(co_await page->shell->confirm(L"Save this identity?", page->owner + L"\n" + text(identity, L"displayName") + L"\n" + aliasesText(identity) + (flag(identity, L"confirmed") ? L"\nConfirmed for AI identity context." : L"\nUnconfirmed — identity will not be used by AI.") + L"\nThis revokes pending style previews/results; the approved style remains.", L"Save identity")) || !page->current()) co_return;
        Json body; body.Insert(L"identity", identity);
        auto result = co_await page->shell->service->request(L"/style/settings", page->owner, L"POST", body);
        if (page->current()) { acceptState(page, result); updateLearningForms(page, false, true); page->tell(L"Identity saved for this account only."); }
    });
    action(p, extra, L"Delete learned style & stop learning…", [](Page page) -> IAsyncAction {
        if (!(co_await page->shell->confirm(L"Delete learned style and stop learning?", L"This account’s approved style and preview are removed, and Learning is disabled. Confirmed identity and separate saved notes and contacts remain.", L"Delete learned style")) || !page->current()) co_return;
        auto result = co_await page->shell->service->request(L"/style/profile", page->owner, L"DELETE");
        if (page->current()) { acceptState(page, result); updateLearningForms(page, true); page->tell(L"Learned style removed; Learning stopped."); }
    });
    action(p, extra, L"Discard unsaved Learning edits", [](Page page) -> IAsyncAction {
        for (auto name : {L"learning", L"identity", L"voice"}) page->forms[name].accept(page->forms[name].saved);
        page->dirty(); page->tell(L"Saved values restored."); co_return;
    });
    renderLearning(p);
}

void sourceLinks(Page const& p, StackPanel const& panel, Array const& sources) {
    if (!sources.Size()) return;
    Expander details; details.Header(box_value(L"Mail supplied as context (" + to_hstring(sources.Size()) + L")")); auto links=stack(6); details.Content(links); panel.Children().Append(details);
    for (auto const& entry : sources) {
        auto source=entry.GetObject(); auto caption=(source.HasKey(L"reference") ? L"[" + count(source,L"reference") + L"] " : hstring()) + text(source,L"subject",L"Subject withheld") + L" · " + text(source,L"date");
        std::weak_ptr<Intelligence> weak=p;
        links.Children().Append(button(caption,[weak,source]{ if (auto page=weak.lock();page && page->current() && !page->busy) page->shell->openSource(source); }));
    }
}
Json brainFields(Json const& state) {
    auto brain = object(object(state, L"workspace"), L"brain"); Json value;
    put(value, L"voice", text(brain, L"voice")); put(value, L"notes", text(brain, L"notes")); put(value,L"guardrails",text(brain,L"guardrails")); return value;
}
void memorySources(StackPanel const& panel, Json const& item) {
    for (auto const& entry : array(item, L"sourceLabels")) {
        auto source = entry.GetObject(); words(panel, L"Source: " + text(source, L"subject") + L" · " + text(source, L"date"), 12);
    }
}
void renderMemoryPreview(Page const& p) {
    auto panel = p->memoryPanel.get(); if (!panel) return; panel.Children().Clear();
    auto preview = p->memoryPreview;
    if (!preview.Size()) return;
    auto items = array(preview, L"items");
    if (!items.Size()) words(panel, L"No durable memories found in this selection.");
    for (auto const& entry : items) {
        auto item = entry.GetObject(); CheckBox check;
        auto content = stack(4); words(content, text(item, L"text")); memorySources(content, item); check.Content(content);
        auto id = text(item, L"id"); std::weak_ptr<Intelligence> weak = p;
        check.Checked([weak, id](auto const&, auto const&) { if (auto page = weak.lock()) page->selectedMemories.insert(std::wstring(id)); });
        check.Unchecked([weak, id](auto const&, auto const&) { if (auto page = weak.lock()) page->selectedMemories.erase(std::wstring(id)); });
        panel.Children().Append(check);
    }
    action(p, panel, L"Save selected memories", [](Page page) -> IAsyncAction {
        require(!page->forms[L"brain"].dirty(), L"Save or discard your notes first.");
        require(!page->writingRulesEdited(), L"Save or discard writing rule edits before refreshing memories.");
        require(!page->selectedMemories.empty(), L"Select the memories you want to keep.");
        Json input; put(input, L"previewId", text(page->memoryPreview, L"id")); Array ids;
        for (auto const& id : page->selectedMemories) ids.Append(Value::CreateStringValue(hstring(id)));
        input.Insert(L"itemIds", ids);
        auto state = co_await page->shell->service->request(L"/workspace/brain/apply", page->owner, L"POST", input);
        if (!page->current()) co_return; acceptState(page, state);
        auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"brain");
    });
    action(p, panel, L"Dismiss suggestions", [](Page page) -> IAsyncAction {
        auto saved=object(object(object(page->state,L"workspace"),L"brainLearning"),L"preview");
        if (text(saved,L"id") == text(page->memoryPreview,L"id")) {
            Json input; put(input,L"previewId",text(saved,L"id"));
            auto state=co_await page->shell->service->request(L"/workspace/brain/dismiss",page->owner,L"POST",input);
            if (!page->current()) co_return; acceptState(page,state);
        }
        page->clearResult();
    });
}
void renderWritingRules(Page const& p);
IAsyncAction commitWritingRule(Page page, hstring method, hstring path, Json input, std::wstring formName = {}, Json submitted = Json()) {
    auto state = co_await page->shell->service->request(path, page->owner, method, input);
    if (!page->current()) co_return;
    acceptState(page, state);
    if (!formName.empty()) {
        if (method == L"DELETE") page->forms.erase(formName);
        else {
            Json saved; put(saved, L"text", formName == L"writingRule:new" ? hstring() : text(input, L"text"));
            page->forms.at(formName).acceptSubmitted(submitted, saved);
        }
    }
    renderWritingRules(page); page->dirty(); page->tell(L"Writing rule saved. Other unsaved edits were retained.");
}
void buildWritingRules(Page const& p, StackPanel const& body) {
    auto panel = group(body, L"How you write");
    words(panel, L"Add short rules in your own words. Enabled rules guide Write, Reply, Rewrite and reply suggestions for this mailbox. They never send mail. Learn Now still reviews Sent mail separately and does not create or replace these rules.");
    Json empty; put(empty, L"text", L""); editor(p, L"writingRule:new", empty);
    auto add = editText(p, panel, L"writingRule:new", L"text", L"New writing rule", 500, true);
    add.MinHeight(72); add.MaxHeight(120);
    xaml::Automation::AutomationProperties::SetAutomationId(add, L"writing-rule.new");
    auto addRule = action(p, panel, L"Add rule", [](Page page) -> IAsyncAction {
        auto submitted = clone(page->forms[L"writingRule:new"].value);
        auto value = trim(text(submitted, L"text"));
        require(!value.empty() && value.size() <= 500, L"Enter a writing rule of at most 500 characters.");
        Json input; put(input, L"text", value); truth(input, L"enabled", true); put(input, L"source", L"user");
        co_await commitWritingRule(page, L"POST", L"/workspace/brain/writing-rules", input, L"writingRule:new", submitted);
    });
    xaml::Automation::AutomationProperties::SetAutomationId(addRule, L"writing-rule.add");
    auto discardNew = action(p, panel, L"Discard new rule", [](Page page) -> IAsyncAction {
        page->forms[L"writingRule:new"].accept(page->forms[L"writingRule:new"].saved); page->dirty(); co_return;
    });
    xaml::Automation::AutomationProperties::SetAutomationId(discardNew, L"writing-rule.discard-new");
    auto list = stack(12); panel.Children().Append(list); p->writingRuleList = make_weak(list);
    renderWritingRules(p);
    words(panel, L"Up to 30 rules. Disabled rules stay saved and are left out of prompts.", 12);
}
void renderWritingRules(Page const& p) {
    auto panel = p->writingRuleList.get(); if (!panel) return;
    panel.Children().Clear();
    auto rules = array(object(object(p->state, L"workspace"), L"brain"), L"writingRules");
    if (!rules.Size()) words(panel, L"No writing rules yet. The approved Sent style stays separate.");
    for (auto const& entry : rules) {
        auto rule = entry.GetObject();
        auto learned = text(rule, L"source") == L"learned";
        auto row = stack(6);
        hstring kind = learned ? hstring(L"Learned") : hstring(L"You wrote this");
        words(row, kind + L" · " + text(rule, L"text"));
        if (learned) words(row, L"Learned rules can be turned on or off, or deleted. Add your own rule to change the wording.", 12);
        auto id = text(rule, L"id");
        auto formName = L"writingRule:" + std::wstring(id);
        CheckBox enabled; enabled.Content(box_value(L"Enabled")); enabled.IsChecked(flag(rule, L"enabled"));
        xaml::Automation::AutomationProperties::SetAutomationId(enabled, L"writing-rule.enabled." + id);
        std::weak_ptr<Intelligence> weak = p;
        enabled.Click([weak, id](auto const& sender, auto const&) {
            auto box = sender.template as<CheckBox>();
            if (auto page = weak.lock(); page && page->current()) {
                bool on = checked(box);
                // Keep the saved state visible until the request succeeds, including on failure.
                box.IsChecked(!on);
                if (page->busy || page->cancelling) return;
                perform(page, [id, on](Page page) -> IAsyncAction {
                    Json input; truth(input, L"enabled", on);
                    co_await commitWritingRule(page, L"POST", L"/workspace/brain/writing-rules/" + escaped(id), input);
                });
            }
        });
        row.Children().Append(enabled);
        MenuFlyout management;
        if (!learned) {
            if (!p->forms.contains(formName)) editor(p, formName.c_str(), subset(rule, {L"text"}));
            Expander editorPanel; editorPanel.Header(box_value(L"Edit writing rule"));
            editorPanel.IsExpanded(p->editingRules.contains(formName) || p->forms[formName].dirty());
            editorPanel.Expanding([weak, formName](auto const&, auto const&) { if(auto page=weak.lock(); page && page->current()) page->editingRules.insert(formName); });
            editorPanel.Collapsed([weak, formName](auto const&, auto const&) { if(auto page=weak.lock(); page && page->current()) page->editingRules.erase(formName); });
            auto fields=stack(8); editorPanel.Content(fields); row.Children().Append(editorPanel);
            auto edit = editText(p, fields, formName.c_str(), L"text", L"Edit writing rule", 500, true);
            edit.MinHeight(72); edit.MaxHeight(120);
            xaml::Automation::AutomationProperties::SetAutomationId(edit, L"writing-rule.text." + id);
            auto reveal=menuItem(L"Edit rule",[weak, formName, editor=make_weak(editorPanel)] { if(auto page=weak.lock();page && page->current() && !page->busy) {page->editingRules.insert(formName);if(auto view=editor.get())view.IsExpanded(true);} });
            xaml::Automation::AutomationProperties::SetAutomationId(reveal,L"writing-rule.edit."+id);management.Items().Append(reveal);
            auto save = action(p, fields, L"Save rule", [id, formName](Page page) -> IAsyncAction {
                auto submitted = clone(page->forms.at(formName).value);
                auto value = trim(text(submitted, L"text"));
                require(!value.empty() && value.size() <= 500, L"Enter a writing rule of at most 500 characters.");
                Json input; put(input, L"text", value);
                co_await commitWritingRule(page, L"POST", L"/workspace/brain/writing-rules/" + escaped(id), input, formName, submitted);
            });
            xaml::Automation::AutomationProperties::SetAutomationId(save, L"writing-rule.save." + id);
            auto cancel = action(p, fields, L"Discard rule edits", [formName](Page page) -> IAsyncAction {
                page->forms.at(formName).accept(page->forms.at(formName).saved); page->dirty(); co_return;
            });
            xaml::Automation::AutomationProperties::SetAutomationId(cancel, L"writing-rule.discard." + id);
        }
        menuAction(p, management, L"Delete rule…", [id, formName](Page page) -> IAsyncAction {
            if (!(co_await page->shell->confirm(L"Delete this writing rule?", L"It will stop guiding drafts and replies for this mailbox. Nothing is sent.", L"Delete rule")) || !page->current()) co_return;
            co_await commitWritingRule(page, L"DELETE", L"/workspace/brain/writing-rules/" + escaped(id), Json(), formName);
        });
        auto more=actionMenu(L"More",management,L"More actions for writing rule");
        xaml::Automation::AutomationProperties::SetAutomationId(more,L"writing-rule.more."+id);row.Children().Append(more);
        panel.Children().Append(row);
    }
}
void buildBrain(Page const& p, StackPanel const& body) {
    words(body, L"Writing style & notes", 24);
    buildLearning(p, body);
    buildWritingRules(p, body);
    Expander details; details.Header(box_value(L"Notes and memory suggestions")); auto memory = stack(12); details.Content(memory); body.Children().Append(details);
    auto policy = object(object(p->state, L"settings"), L"policy");
    words(memory, flag(policy, L"enabled") && flag(object(policy, L"behaviors"), L"memory")
        ? L"Explicitly saved voice and notes may inform permitted AI requests. They remain local until included in an authorized model request."
        : L"Writing style and notes are disabled by your saved permissions. Saved notes will not inform AI requests.");
    words(memory, L"Optional notes and memories provide extra context. Manual writing instructions override the approved Sent style. How-you-write rules above stay separate from this voice field.");
    auto automatic = object(object(p->state,L"workspace"),L"brainLearning");
    editor(p,L"memoryOptions",subset(automatic,{L"enabled",L"tokenBudget"}));
    auto automaticPanel = group(memory,L"Automatic memory suggestions");
    editCheck(p,automaticPanel,L"memoryOptions",L"enabled",L"Suggest new memories weekly");
    editNumber(p,automaticPanel,L"memoryOptions",L"tokenBudget",L"Estimated tokens per analysis",4000,64000,1000);
    words(automaticPanel,L"First analysis starts after enabling; later analyses run weekly when mail changes. Proposals survive restart and wait for your review. Status: " + text(automatic,L"status"),12);
    if (!text(automatic,L"error").empty()) words(automaticPanel,text(automatic,L"error"));
    action(p,automaticPanel,L"Save automatic learning",[](Page page) -> IAsyncAction {
        auto options=clone(page->forms[L"memoryOptions"].value);
        if (flag(options,L"enabled") && !(co_await page->shell->confirm(L"Enable automatic memory suggestions?",page->owner + L"\nWeekly budget: " + count(options,L"tokenBudget") + L" estimated tokens. Uses your configured model and permitted downloaded mail while Morrow is open. Provider charges may apply. Proposals require review before saving.",L"Enable"))) co_return;
        auto state=co_await page->shell->service->request(L"/workspace/brain/settings",page->owner,L"POST",options);
        if (!page->current()) co_return; acceptState(page,state); page->forms[L"memoryOptions"].accept(options); page->dirty();
    });
    auto suggestions = group(memory, L"Find memories in your mail");
    words(suggestions, L"Suggest up to 8 memories from your latest permitted mail. Review the sources and select what to keep. Your saved notes are retained.");
    action(p, suggestions, L"Suggest memories — uses AI…", [](Page page) -> IAsyncAction {
        require(!page->forms[L"brain"].dirty(), L"Save or discard your notes first.");
        auto settings = object(page->state, L"settings"), model = object(settings, L"ai"), policy = object(settings, L"policy");
        auto captured = page->context;
        if (!(co_await page->shell->confirm(L"Suggest memories from mail?", page->owner + L"\nModel: " + text(model, L"model") + L"\nUp to " + count(policy, L"maxMessages") + L" permitted downloaded messages. Provider charges may apply. Suggestions are saved only after your review.", L"Suggest memories")) || !page->current()) co_return;
        validateContext(page, captured); page->clearResult();
        auto result = co_await page->shell->service->request(L"/workspace/brain/preview", page->owner, L"POST", Json());
        if (!page->current()) co_return; validateContext(page, captured);
        page->memoryPreview = object(result, L"preview"); renderMemoryPreview(page);
    });
    auto memoryPanel = stack(12); suggestions.Children().Append(memoryPanel); p->memoryPanel = make_weak(memoryPanel);
    p->memoryPreview = object(automatic,L"preview"); renderMemoryPreview(p);
    words(memory, L"Your instructions", 20);
    editor(p, L"brain", brainFields(p->state));
    editText(p, memory, L"brain", L"voice", L"Manual writing instructions", 2000, true);
    editText(p, memory, L"brain", L"notes", L"Business facts & notes", 4000, true);
    editText(p,memory,L"brain",L"guardrails",L"Writing guardrails",2000,true);
    words(memory,L"Keep facts separate from tone. Do not quote prices or promise dates without current evidence. Saved context belongs to this mailbox.",12);
    action(p, memory, L"Save notes", [](Page page) -> IAsyncAction {
        auto input = clone(page->forms[L"brain"].value);
        auto result = co_await page->shell->service->request(L"/workspace/brain", page->owner, L"POST", input);
        if (!page->current()) co_return;
        acceptState(page, result); page->forms[L"brain"].accept(brainFields(result)); page->dirty(); page->tell(L"Notes saved for this account. Contacts, writing rules and learned style were retained.");
    });
    action(p, memory, L"Discard unsaved notes", [](Page page) -> IAsyncAction {
        page->forms[L"brain"].accept(brainFields(page->state)); page->dirty(); page->tell(L"Saved notes restored."); co_return;
    });
    action(p, memory, L"Clear notes & memories…", [](Page page) -> IAsyncAction {
        require(!page->writingRulesEdited(), L"Save or discard writing rule edits before clearing notes and refreshing this page.");
        if (!(co_await page->shell->confirm(L"Clear saved notes and memories?", page->owner + L"\nRemoves saved voice, notes, memories and contacts for this mailbox. How-you-write rules, confirmed identity and the approved Sent style remain saved.", L"Clear notes & memories")) || !page->current()) co_return;
        auto result = co_await page->shell->service->request(L"/workspace/brain", page->owner, L"DELETE");
        if (!page->current()) co_return;
        acceptState(page, result); page->forms[L"brain"].accept(brainFields(result)); page->dirty();
        auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"brain");
    });
    auto memories = group(memory, L"Reviewed memories");
    auto facts = array(object(object(p->state, L"workspace"), L"brain"), L"facts");
    if (!facts.Size()) words(memories, L"No reviewed memories yet. Start with Suggest memories above.");
    for (auto const& entry : facts) {
        auto fact = entry.GetObject(); auto row = stack(6); words(row, text(fact, L"text")); memorySources(row, fact);
        action(p, row, L"Remove memory", [id = text(fact, L"id")](Page page) -> IAsyncAction {
            require(!page->forms[L"brain"].dirty(), L"Save or discard your notes first.");
            require(!page->writingRulesEdited(), L"Save or discard writing rule edits before refreshing memories.");
            auto state = co_await page->shell->service->request(L"/workspace/brain/facts/" + escaped(id), page->owner, L"DELETE", Json());
            if (!page->current()) co_return; acceptState(page, state);
            auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"brain");
        }); memories.Children().Append(row);
    }
    words(memories, L"Memories are used only while their source mail and permissions still match.", 12);
    Expander savedContacts; savedContacts.Header(box_value(L"Saved contacts")); auto contacts = stack(8); savedContacts.Content(contacts); memory.Children().Append(savedContacts);
    auto values = array(object(object(p->state, L"workspace"), L"brain"), L"contacts");
    if (!values.Size()) words(contacts, L"No saved contacts.");
    uint32_t displayed = 0;
    for (auto const& value : values) {
        if (displayed++ == 100) { words(contacts, L"Additional contacts are retained in the workspace."); break; }
        auto contact = value.GetObject(); words(contacts, text(contact, L"name", L"Contact") + L" · " + text(contact, L"email"));
    }
}

bool suggestionsRunning(Page const& p) {
    auto status = text(object(p->suggestions, L"job"), L"status"); return status == L"queued" || status == L"running";
}
void acceptSuggestions(Page const& p, Json const& next, bool saved = false) {
    require(text(next, L"owner") == p->owner, L"Suggestions belong to another mailbox. Reopen this account.");
    p->suggestions = clone(next);
    if (saved || !p->forms[L"suggestions"].dirty()) p->forms[L"suggestions"].accept(object(next, L"settings"));
    std::set<std::wstring> eligible;
    for (auto const& item : array(next, L"candidates")) eligible.insert(std::wstring(text(item.GetObject(), L"id")));
    std::erase_if(p->selectedCandidates, [&](auto const& id) { return !eligible.contains(id); });
    renderSuggestions(p); p->dirty();
}
hstring messageCaption(Json const& value) {
    return text(value, L"fromName", text(value, L"fromEmail", L"Sender withheld")) + L" — " + text(value, L"subject", L"Subject withheld") + L"\n" + text(value, L"date");
}
hstring coverage(Json const& value) {
    return count(value, L"usedMessages") + L" / " + count(value, L"matchedMessages") + L" matching downloaded messages used";
}
IAsyncAction useSuggestion(Page p, hstring id) {
    require(!p->edited(), L"Save or discard suggestion settings before opening a draft.");
    auto context = p->context; Json input; put(input, L"id", id);
    auto result = co_await p->shell->service->request(L"/reply-suggestions/use", p->owner, L"POST", input);
    if (!p->current()) co_return; validateContext(p, context);
    auto message = object(result, L"message"); auto messageId = text(message, L"id"), reply = text(result, L"text");
    require(text(message, L"accountId") == p->owner && !messageId.empty() && !reply.empty(), L"The suggestion owner or source changed.");
    Json request; put(request, L"messageId", messageId); put(request, L"mode", L"reply"); put(request, L"body", reply);
    auto prepared = co_await p->shell->service->request(L"/drafts/prepare", p->owner, L"POST", request);
    if (!p->current()) co_return; validateContext(p, context);
    auto draft = object(prepared, L"draft");
    require(text(draft, L"accountId") == p->owner && text(draft, L"replyToId") == messageId && text(draft, L"body") == reply && text(draft, L"bcc").empty(), L"The prepared reply could not be confirmed for this suggestion.");
    // The server's fresh projection checks connection/permission generations,
    // source hashes and approved style, including changes during draft prepare.
    auto latest = co_await p->shell->service->request(L"/reply-suggestions", p->owner);
    if (!p->current()) co_return; validateContext(p, context);
    bool valid = false;
    if (text(latest, L"owner") == p->owner) for (auto const& entry : array(latest, L"proposals")) {
        auto proposal = entry.GetObject();
        if (text(proposal, L"id") == id && text(proposal, L"messageId") == messageId && text(proposal, L"text") == reply && text(object(proposal, L"message"), L"accountId") == p->owner) valid = true;
    }
    require(valid, L"This suggestion was revoked or its sources changed. Review a fresh batch.");
    p->shell->dirty.erase(p->key()); auto shell = p->shell; p->stop(); co_await compose(shell, draft);
}
IAsyncAction saveAutomaticReplies(Page page, Json input) {
    if (flag(input,L"automatic") && !(co_await page->shell->confirm(L"Automatically find mail that needs a reply?",page->owner + L"\nModel: " + text(object(page->suggestions,L"model"),L"model") + L"\nEndpoint: " + text(object(page->suggestions,L"model"),L"baseUrl") + L"\nDaily budget: " + count(input,L"dailyTokenBudget") + L" estimated tokens per UTC day. Uses permitted Inbox and correspondence while Morrow is open. Provider charges may apply. No mail is sent automatically.",L"Enable automatic checks"))) co_return;
    if (!page->current()) co_return;
    auto result=co_await page->shell->service->request(L"/reply-suggestions/settings",page->owner,L"POST",input);
    if (page->current()) { acceptSuggestions(page,result,true); page->tell(L"Automatic reply settings saved."); }
}
void renderSuggestions(Page const& p) {
    auto jobs=p->jobPanel.get(), proposals=p->proposalPanel.get();
    if (!jobs || !proposals) return;
    auto value=p->suggestions, job=object(value,L"job"); auto signature=value.Stringify();
    if (p->suggestionPaint==signature) return;
    p->suggestionPaint=signature; jobs.Children().Clear(); proposals.Children().Clear();
    if (!flag(value,L"identityReady")) {
        words(jobs,L"Confirm the name to use in your replies first.");
        std::weak_ptr<Intelligence> weak=p;
        jobs.Children().Append(button(L"Confirm my identity",[weak] { if (auto page=weak.lock()) changePage(page,L"learning"); }));
    } else if (!flag(value,L"modelReady") || (!flag(value,L"permitted") && flag(object(value,L"settings"),L"enabled"))) {
        for (auto const& requirement:array(value,L"requirements")) words(jobs,requirement.GetString());
        words(jobs,L"Review AI & privacy and Advanced setup → AI connection in Settings.");
    } else if (!flag(value,L"automaticReady")) {
        action(p,jobs,L"Enable automatic reply suggestions",[](Page page) -> IAsyncAction {
            auto options=clone(page->forms[L"suggestions"].value); truth(options,L"enabled",true); truth(options,L"automatic",true); options.Insert(L"tokenBudget",Value::CreateNumberValue(64000));
            co_await saveAutomaticReplies(page,options);
        });
    } else words(jobs,suggestionsRunning(p) ? L"Checking mail in the background…" : L"Automatic checks are on.");
    if (flag(value,L"automaticReady")) words(jobs,text(value,L"automaticStatus"),12);
    if (!text(job,L"error").empty()) words(jobs,text(job,L"error"));
    if (text(job,L"status")==L"failed" || text(job,L"status")==L"interrupted" || text(job,L"status")==L"cancelled") {
        action(p,jobs,L"Review & restart checks",[](Page page) { return saveAutomaticReplies(page,clone(page->forms[L"suggestions"].value)); });
    }
    if (!array(value,L"proposals").Size()) words(proposals,suggestionsRunning(p) ? L"Suggestions appear as messages are checked." : L"No replies waiting for review. Unnecessary replies are filtered out; AI can still miss a request.");
    for (auto const& entry:array(value,L"proposals")) {
        auto proposal=entry.GetObject(), message=object(proposal,L"message");
        require(text(message,L"accountId")==p->owner,L"Suggestion belongs to another mailbox.");
        auto row=group(proposals,messageCaption(message)); words(row,text(proposal,L"reason")); auto id=text(proposal,L"id");
        auto preview=label(text(proposal,L"text")); preview.MaxLines(4); row.Children().Append(preview);
        words(row,to_hstring(array(proposal,L"sourceMessages").Size()) + L" permitted source(s)" + (flag(proposal,L"approvedStyleUsed") ? L" · Approved writing style" : L""),12);
        sourceLinks(p,row,array(proposal,L"sourceMessages"));
        action(p,row,L"Review suggested reply…",[id](Page page) { return useSuggestion(page,id); });
        action(p,row,L"Ignore",[id](Page page) -> IAsyncAction {
            Json input; put(input,L"id",id);
            auto result=co_await page->shell->service->request(L"/reply-suggestions/dismiss",page->owner,L"POST",input);
            if (page->current()) acceptSuggestions(page,result);
        });
    }
}
void buildSuggestions(Page const& p, StackPanel const& body) {
    words(body,L"Needs a reply",24);
    words(body,L"AI checks downloaded Inbox mail and leaves out messages that do not need a reply. Open a suggestion to edit or send it, or ignore the email.");
    editor(p,L"suggestions",object(p->suggestions,L"settings"));
    auto jobs=stack(10), proposals=stack(14); body.Children().Append(jobs); body.Children().Append(proposals);
    p->jobPanel=make_weak(jobs); p->proposalPanel=make_weak(proposals);
    Expander details; details.Header(box_value(L"Automatic checks & budget")); auto options=stack(12); details.Content(options); body.Children().Append(details);
    editCheck(p,options,L"suggestions",L"automatic",L"Check new Inbox mail automatically");
    editNumber(p,options,L"suggestions",L"dailyTokenBudget",L"Daily token budget (UTC day)",4000,2000000,1000);
    words(options,L"Used today: " + count(p->suggestions,L"spentToday") + L" estimated tokens. Checks cover the newest 200 downloaded Inbox messages and permitted correspondence. Provider billing may differ. Mail is never sent automatically.",12);
    action(p,options,L"Save",[](Page page) -> IAsyncAction {
        auto options=clone(page->forms[L"suggestions"].value); if (flag(options,L"automatic")) truth(options,L"enabled",true);
        co_await saveAutomaticReplies(page,options);
    });
    renderSuggestions(p);
}

Json skillFields(Json const& value = Json()) {
    Json result; put(result, L"id", text(value, L"id")); put(result, L"name", text(value, L"name"));
    put(result, L"instructions", text(value, L"instructions"));
    truth(result, L"enabled", !value.HasKey(L"enabled") || flag(value, L"enabled"));
    auto folders = object(value, L"folders");
    for (auto folder : {L"inbox", L"sent", L"drafts", L"archive", L"trash"}) truth(result, folder, folders.Size() ? flag(folders, folder) : std::wstring_view(folder) == L"inbox");
    truth(result, L"autoExecute", flag(value, L"autoExecute"));
    auto schedule = object(value, L"schedule");
    truth(result, L"scheduleEnabled", flag(schedule, L"enabled"));
    put(result, L"cadence", text(schedule, L"cadence", L"daily"));
    put(result, L"time", text(schedule, L"time", L"09:00"));
    put(result, L"timeZone", text(schedule, L"timeZone", L"UTC"));
    result.Insert(L"intervalHours", Value::CreateNumberValue(schedule.Size() ? schedule.GetNamedNumber(L"intervalHours", 24) : 24));
    return result;
}
void renderSkills(Page const& p) {
    auto list = p->skillList.get(); if (!list) return; list.Children().Clear();
    auto skills = array(object(p->state, L"workspace"), L"skills");
    if (!skills.Size()) words(list, L"No saved skills. Create instructions and a folder scope below.");
    for (auto const& entry : skills) {
        auto skill = entry.GetObject(); auto id = text(skill, L"id");
        auto item = group(list, text(skill, L"name") + (flag(skill, L"enabled") ? L"" : L" — disabled"));
        words(item, text(skill, L"instructions")); hstring folders;
        for (auto const& folder : object(skill, L"folders")) if (folder.Value().ValueType() == JsonValueType::Boolean && folder.Value().GetBoolean()) folders = folders + (folders.empty() ? L"" : L", ") + folder.Key();
        words(item, L"Allowed folders: " + (folders.empty() ? hstring(L"none") : folders) + L". Global AI permissions still apply.");
        auto schedule = object(skill, L"schedule");
        if (schedule.Size()) words(item, L"Schedule: " + text(schedule, L"cadence") + L" " + text(schedule, L"time") + L" " + text(schedule, L"timeZone") + (flag(schedule, L"enabled") ? L" · on" : L" · off"));
        words(item, flag(skill, L"autoExecute") ? L"When due, this skill joins the review queue. It does not send mail." : L"Manual only until you turn on review queueing.");
        MenuFlyout management;
        menuAction(p, management, L"Edit skill", [skill](Page page) -> IAsyncAction {
            if (page->forms[L"skill"].dirty() && !(co_await page->shell->confirm(L"Discard current skill edits?", L"Load this saved skill into the editor below.", L"Edit saved skill"))) co_return;
            if (!page->current()) co_return;
            page->forms[L"skill"].accept(skillFields(skill)); if(auto editor=page->skillEditor.get())editor.IsExpanded(true); page->dirty(); page->tell(L"Saved skill loaded in the editor below.");
        });
        menuAction(p, management, L"Delete skill…", [id, name = text(skill, L"name")](Page page) -> IAsyncAction {
            if (!(co_await page->shell->confirm(L"Delete this skill?", page->owner + L"\n" + name + L"\nMessages are retained. Pending AI results using the old skill will be rejected.", L"Delete skill")) || !page->current()) co_return;
            auto result = co_await page->shell->service->request(L"/skills/" + escaped(id), page->owner, L"DELETE");
            if (!page->current()) co_return; acceptState(page, result);
            if (text(page->forms[L"skill"].value, L"id") == id) page->forms[L"skill"].accept(skillFields());
            renderSkills(page); page->dirty(); page->tell(L"Skill deleted.");
        });
        if (flag(skill, L"enabled")) action(p, item, L"Queue review…", [id, name = text(skill, L"name")](Page page) -> IAsyncAction {
            if (!(co_await page->shell->confirm(L"Queue this skill for review?", name + L"\nNothing is sent and Email Brain is not changed.", L"Queue review")) || !page->current()) co_return;
            Json input; put(input, L"skillId", id); truth(input, L"confirm", true);
            auto result = co_await page->shell->service->request(L"/workspace/skill-reviews", page->owner, L"POST", input);
            if (!page->current()) co_return; acceptState(page, result); renderSkills(page); page->tell(L"Queued for review. Nothing was sent.");
        });
        menuAction(p, management, flag(skill, L"autoExecute") ? L"Stop queueing when due" : L"Queue when due", [id, enabled = flag(skill, L"autoExecute")](Page page) -> IAsyncAction {
            Json input; truth(input, L"enabled", !enabled); put(input, L"autoExecuteMode", L"review");
            auto result = co_await page->shell->service->request(L"/skills/" + escaped(id) + L"/auto-execute", page->owner, L"POST", input);
            if (!page->current()) co_return; acceptState(page, result); renderSkills(page);
            page->tell(enabled ? L"Review queueing is off. Saved mail was not changed." : L"When the schedule is due, a review is queued. Nothing is sent.");
        });
        item.Children().Append(actionMenu(L"More",management,L"More actions for skill: "+text(skill,L"name")));
    }
    words(list, L"Skill library", 20);
    words(list, L"Install a prepared instruction set for this mailbox. Installing does not run it.");
    for (auto const& entry : array(object(p->state, L"workspace"), L"skillLibrary")) {
        auto item = entry.GetObject(); auto row = group(list, text(item, L"name"));
        words(row, text(item, L"instructions"));
        if (flag(item, L"installed")) words(row, L"Installed");
        else action(p, row, L"Install", [id = text(item, L"id")](Page page) -> IAsyncAction {
            Json input; put(input, L"libraryId", id);
            auto result = co_await page->shell->service->request(L"/skills/library", page->owner, L"POST", input);
            if (!page->current()) co_return; acceptState(page, result); renderSkills(page); page->tell(L"Library skill installed. It stays manual until you queue a review.");
        });
    }
    words(list, L"Review queue", 20);
    words(list, L"Schedules and the queue button stop here. Opening a review does not send mail or update Email Brain.");
    auto reviews = array(object(p->state, L"workspace"), L"skillReviews");
    if (!reviews.Size()) words(list, L"Nothing is waiting for review.");
    for (auto const& entry : reviews) {
        auto review = entry.GetObject(); auto id = text(review, L"id");
        auto row = group(list, text(review, L"skillName"));
        words(row, text(review, L"kind") + L" · " + text(review, L"status") + L" · " + text(review, L"source"));
        words(row, text(review, L"detail"));
        action(p, row, L"Open review…", [id](Page page) -> IAsyncAction {
            if (!(co_await page->shell->confirm(L"Open this review?", L"Opening it does not send mail or update Email Brain.", L"Open review")) || !page->current()) co_return;
            Json input; truth(input, L"confirm", true);
            auto result = co_await page->shell->service->request(L"/workspace/skill-reviews/" + escaped(id) + L"/open", page->owner, L"POST", input);
            if (!page->current()) co_return; acceptState(page, result); renderSkills(page);
        });
        action(p, row, L"Dismiss…", [id](Page page) -> IAsyncAction {
            if (!(co_await page->shell->confirm(L"Dismiss this review?", L"The skill stays saved. Nothing is sent.", L"Dismiss")) || !page->current()) co_return;
            Json input; truth(input, L"confirm", true);
            auto result = co_await page->shell->service->request(L"/workspace/skill-reviews/" + escaped(id) + L"/dismiss", page->owner, L"POST", input);
            if (!page->current()) co_return; acceptState(page, result); renderSkills(page);
        });
    }
}
void buildSkills(Page const& p, StackPanel const& body) {
    words(body, L"My email skills", 24);
    words(body, L"Save reusable instructions, then run one yourself or queue a review. A schedule never sends mail or updates Email Brain. Keep at most 20 skills.");
    editor(p, L"skill", skillFields()); auto list = stack(16); body.Children().Append(list); p->skillList = make_weak(list);
    Expander skillEditor; skillEditor.Header(box_value(L"Create or edit a skill")); auto fields=stack(12);
    skillEditor.Content(fields);body.Children().Append(skillEditor);p->skillEditor=make_weak(skillEditor);
    editText(p, fields, L"skill", L"name", L"Name", 80);
    editText(p, fields, L"skill", L"instructions", L"Instructions", 4000, true);
    editCheck(p, fields, L"skill", L"enabled", L"Enable this skill");
    for (auto folder : {L"inbox", L"sent", L"drafts", L"archive", L"trash"}) editCheck(p, fields, L"skill", folder, folder);
    editCheck(p, fields, L"skill", L"autoExecute", L"Queue a review when the schedule is due");
    editCheck(p, fields, L"skill", L"scheduleEnabled", L"Schedule enabled");
    editChoice(p, fields, L"skill", L"cadence", L"Cadence", {{L"daily", L"Daily"}, {L"interval", L"Interval"}});
    editText(p, fields, L"skill", L"time", L"Time (HH:MM)", 5);
    editText(p, fields, L"skill", L"timeZone", L"IANA time zone", 100);
    editNumber(p, fields, L"skill", L"intervalHours", L"Interval hours", 1, 168);
    action(p, fields, L"Save skill", [](Page page) -> IAsyncAction {
        auto value = page->forms[L"skill"].value;
        require(!trim(text(value, L"name")).empty() && !trim(text(value, L"instructions")).empty(), L"Enter a skill name and instructions.");
        Json input, folders, schedule; for (auto key : {L"name", L"instructions"}) put(input, key, text(value, key));
        if (!text(value, L"id").empty()) put(input, L"id", text(value, L"id"));
        truth(input, L"enabled", flag(value, L"enabled"));
        truth(input, L"autoExecute", flag(value, L"autoExecute"));
        put(input, L"autoExecuteMode", L"review");
        for (auto key : {L"inbox", L"sent", L"drafts", L"archive", L"trash"}) truth(folders, key, flag(value, key));
        input.Insert(L"folders", folders);
        truth(schedule, L"enabled", flag(value, L"scheduleEnabled"));
        put(schedule, L"cadence", text(value, L"cadence", L"daily"));
        put(schedule, L"time", text(value, L"time", L"09:00"));
        put(schedule, L"timeZone", text(value, L"timeZone", L"UTC"));
        schedule.Insert(L"intervalHours", Value::CreateNumberValue(value.GetNamedNumber(L"intervalHours", 24)));
        input.Insert(L"schedule", schedule);
        auto result = co_await page->shell->service->request(L"/skills", page->owner, L"POST", input);
        if (!page->current()) co_return; acceptState(page, result); page->forms[L"skill"].accept(skillFields());
        renderSkills(page); page->dirty(); page->tell(L"Skill saved. A due schedule only joins the review queue.");
    });
    action(p, fields, L"Remove schedule…", [](Page page) -> IAsyncAction {
        auto id = text(page->forms[L"skill"].value, L"id");
        require(!id.empty(), L"Save the skill before removing its schedule.");
        if (!(co_await page->shell->confirm(L"Remove this schedule?", L"The skill stays saved. Nothing is sent.", L"Remove schedule")) || !page->current()) co_return;
        auto result = co_await page->shell->service->request(L"/skills/" + escaped(id) + L"/schedule", page->owner, L"DELETE");
        if (!page->current()) co_return; acceptState(page, result); page->forms[L"skill"].accept(skillFields());
        renderSkills(page); page->dirty(); page->tell(L"Schedule removed.");
    });
    action(p, fields, L"New skill / discard edits…", [](Page page) -> IAsyncAction {
        if (page->forms[L"skill"].dirty() && !(co_await page->shell->confirm(L"Discard skill edits?", L"The saved skill is retained. Start a blank new skill.", L"Discard edits"))) co_return;
        if (page->current()) { page->forms[L"skill"].accept(skillFields()); page->dirty(); page->tell(L"New skill editor ready."); }
    });
    renderSkills(p);
}

void renderRecords(Page const& p) {
    auto panel = p->recordList.get(); if (!panel) return; panel.Children().Clear(); auto workspace = object(p->state, L"workspace");
    words(panel, L"Local simulation records", 24);
    words(panel, L"These are local records of reviewed simulations. They have not sent notifications, created provider calendar events or unsubscribed you. Use Calendar for real provider events and Pending for your own follow-up markers.");
    for (auto collection : {L"reminders", L"events", L"unsubscribed", L"activity"}) {
        auto list = group(panel, collection); auto values = array(workspace, collection);
        if (!values.Size()) words(list, L"No records.");
        for (auto const& entry : values) {
            auto record = entry.GetObject(); auto item = group(list, text(record, L"title", L"Local workspace update"));
            words(item, flag(record, L"cancelled") ? L"Cancelled local record" : flag(record, L"done") ? L"Completed local record" : L"Local simulation");
            words(item, text(record, L"detail", text(record, L"summary")));
            if (!text(record, L"when").empty()) words(item, L"Recorded time (with offset): " + text(record, L"when"));
            words(item, text(record, L"createdAt"));
            auto id = text(record, L"id"), name = hstring(collection);
            if ((name == L"reminders" || name == L"events") && !flag(record, L"cancelled")) {
                action(p, item, flag(record, L"done") ? L"Mark incomplete" : L"Mark complete", [id, name, done = flag(record, L"done")](Page page) -> IAsyncAction {
                    Json input; truth(input, L"done", !done);
                    auto result = co_await page->shell->service->request(L"/workspace/" + name + L"/" + escaped(id), page->owner, L"PATCH", input);
                    if (page->current()) { acceptState(page, result); renderRecords(page); page->tell(L"Local record updated."); }
                });
                if (name == L"events") action(p, item, L"Cancel local event record…", [id](Page page) -> IAsyncAction {
                    if (!(co_await page->shell->confirm(L"Cancel this local record?", L"This does not cancel a real provider event; this record is a local simulation only.", L"Cancel local record")) || !page->current()) co_return;
                    Json input; truth(input, L"cancelled", true);
                    auto result = co_await page->shell->service->request(L"/workspace/events/" + escaped(id), page->owner, L"PATCH", input);
                    if (page->current()) { acceptState(page, result); renderRecords(page); page->tell(L"Local event record cancelled."); }
                });
            }
        }
    }
}

Json selectedFeature(Page const& p) {
    auto id = text(p->forms[L"tool"].value, L"action");
    for (auto const& feature : p->features) if (text(feature, L"id") == id) return feature;
    return Json();
}
hstring messageKey(Json const& message) {
    auto view = text(message, L"viewId");
    return view.empty() ? text(message, L"accountId") + L"\n" + text(message, L"id") : view;
}
Json selectedMessage(Page const& p) {
    auto id = text(p->forms[L"tool"].value, L"messageId");
    for (auto const& message : p->messages) if (messageKey(message) == id) {
        auto account = text(message, L"accountId");
        if ((p->owner == L"all" || account == p->owner) && p->shell->connected(account)) return message;
    }
    return Json();
}
bool usesDraft(Page const& p) {
    auto value = p->forms[L"tool"].value; auto name = text(value, L"action");
    return name == L"rewrite" || (name == L"translate" && text(value, L"translateSource") == L"draft");
}
bool usesSelected(Page const& p) { return text(selectedFeature(p), L"context") == L"selected" && !usesDraft(p); }
hstring selectedFlags(Json const& flags) {
    hstring result; for (auto const& value : flags) if (value.Value().ValueType() == JsonValueType::Boolean && value.Value().GetBoolean()) result = result + (result.empty() ? L"" : L", ") + value.Key();
    return result.empty() ? hstring(L"none") : result;
}
hstring simulationNote(hstring const& name) {
    if (name == L"triage") return L"Local simulation: stars matching mail only inside Morrow. No provider changes.";
    if (name == L"labels") return L"Local simulation: saves labels only inside Morrow.";
    if (name == L"memory") return L"Local simulation: review before replacing Brain voice, notes and contacts. This is not learned style or verified identity.";
    if (name == L"research") return L"Sample brief from permitted mail; no web lookup or verified company research.";
    if (name == L"meeting") return L"Mock agenda and local preparation record. No provider calendar is accessed.";
    if (name == L"followup") return L"Local reminder record only. No email or background notification will be scheduled.";
    if (name == L"schedule") return L"Local calendar simulation. No real event, invitation or availability check. Use Calendar for provider events.";
    if (name == L"cleanup") return L"Local simulation: archives matching messages inside Morrow only.";
    if (name == L"unsubscribe") return L"Records intent only. You remain subscribed; no link is opened or unsubscribe request sent.";
    if (name == L"attachments") return L"Fictional attachment examples only. No actual attachments are fetched, read or compared.";
    if (name == L"batchReplies") return L"Local simulation: creates separate editable drafts. Each send still requires review.";
    return L"Local simulation only. Review the proposed local changes before applying.";
}
hstring blockedTool(Page const& p) {
    auto feature = selectedFeature(p), value = p->forms[L"tool"].value; auto name = text(feature, L"id");
    auto settings = object(p->state, L"settings"), policy = object(settings, L"policy"), content = object(policy, L"content");
    if (!feature.Size()) return L"Select a supported tool.";
    if (p->owner == L"all" && text(feature, L"context") != L"selected") return L"Choose one mailbox tab for inbox-wide AI. A selected message still uses its own account.";
    if (p->owner == L"all" && usesDraft(p)) return L"Choose one mailbox tab for draft text.";
    if (!flag(policy, L"enabled")) return L"AI is off in saved permissions.";
    if (!flag(object(policy, L"behaviors"), name.c_str())) return L"This behavior is disabled in saved AI permissions.";
    if (!flag(feature, L"mock") && !flag(object(settings, L"ai"), L"configured")) return L"Set up AI in Settings → Advanced setup → AI connection first.";
    if ((name == L"memory" || name == L"research") && !flag(content, L"contacts")) return L"This tool requires contact-context permission.";
    if ((name == L"meeting" || name == L"schedule") && !flag(content, L"calendar")) return L"This tool requires local calendar-context permission.";
    if (name == L"attachments" && !flag(content, L"attachments")) return L"Sample attachment-context permission is disabled.";
    if (name == L"batchReplies" && (!flag(content, L"sender") || !flag(content, L"body"))) return L"Batch drafts require sender and body permissions.";
    if (usesDraft(p) && (!flag(object(policy, L"folders"), L"drafts") || !flag(content, L"body"))) return L"Enable Drafts and body access for draft actions.";
    if (usesDraft(p) && trim(text(value, L"draftText")).empty()) return L"Enter draft text to process.";
    if ((name == L"ask" || name == L"write") && trim(text(value, L"prompt")).empty()) return L"Enter your question or writing instructions.";
    if (usesSelected(p) && !selectedMessage(p).Size()) return L"Choose a message in a permitted folder from the page below.";
    if (!usesDraft(p) && text(feature, L"context") != L"none" && !flag(content, L"sender") && !flag(content, L"subject") && !flag(content, L"body")) return L"Allow sender, subject or body context first.";
    if (name == L"reply" && flag(value, L"includeHistory") && !flag(content, L"sender")) return L"Suggest with History requires sender permission.";
    if (name == L"skill") {
        bool found = false;
        for (auto const& entry : array(object(p->state, L"workspace"), L"skills")) { auto skill = entry.GetObject(); if (text(skill, L"id") == text(value, L"skillId") && flag(skill, L"enabled")) found = true; }
        if (!found) return L"Choose an enabled saved skill. Create one in My skills first.";
    }
    return {};
}
Json sourceProof(Json const& message, Json const& policy) {
    auto result = subset(message, {L"id", L"accountId", L"date", L"folder", L"read", L"starred", L"category"});
    auto content = object(policy, L"content");
    for (auto key : {L"fromName", L"fromEmail", L"to", L"cc"}) if (flag(content, L"sender")) put(result, key, text(message, key));
    if (flag(content, L"subject")) { put(result, L"subject", text(message, L"subject")); result.Insert(L"labels", array(message, L"labels")); }
    if (flag(content, L"body")) { put(result, L"body", text(message, L"body")); put(result, L"preview", text(message, L"preview")); }
    return result;
}
hstring recordedTime(DatePicker const& date, TimePicker const& time) {
    Windows::Globalization::Calendar calendar; calendar.ChangeCalendarSystem(L"GregorianCalendar"); calendar.SetDateTime(date.Date());
    auto minutes = std::chrono::duration_cast<std::chrono::minutes>(time.Time()).count();
    require(minutes >= 0 && minutes < 1440, L"Choose a local time.");
    SYSTEMTIME local{}, utc{}, roundTrip{};
    local.wYear = static_cast<WORD>(calendar.Year()); local.wMonth = static_cast<WORD>(calendar.Month()); local.wDay = static_cast<WORD>(calendar.Day());
    local.wHour = static_cast<WORD>(minutes / 60); local.wMinute = static_cast<WORD>(minutes % 60);
    require(TzSpecificLocalTimeToSystemTimeEx(nullptr, &local, &utc) && SystemTimeToTzSpecificLocalTimeEx(nullptr, &utc, &roundTrip)
        && local.wYear == roundTrip.wYear && local.wMonth == roundTrip.wMonth && local.wDay == roundTrip.wDay && local.wHour == roundTrip.wHour && local.wMinute == roundTrip.wMinute,
        L"This local time is invalid during a clock change. Choose another time.");
    FILETIME at{}, now{}; GetSystemTimeAsFileTime(&now);
    require(SystemTimeToFileTime(&utc, &at) && CompareFileTime(&at, &now) > 0, L"Choose a future date and time.");
    wchar_t result[32]{};
    swprintf_s(result, L"%04u-%02u-%02uT%02u:%02u:%02u.%03uZ", unsigned(utc.wYear), unsigned(utc.wMonth), unsigned(utc.wDay), unsigned(utc.wHour), unsigned(utc.wMinute), unsigned(utc.wSecond), unsigned(utc.wMilliseconds));
    return hstring(result);
}
void renderToolResult(Page const& p);
IAsyncAction runTool(Page p) {
    auto reason = blockedTool(p); if (!reason.empty()) throw hresult_error(E_INVALIDARG, reason);
    auto feature = selectedFeature(p), value = clone(p->forms[L"tool"].value), message = selectedMessage(p);
    auto name = text(feature, L"id"), context = p->context; bool mock = flag(feature, L"mock"), selected = usesSelected(p);
    auto mailbox = selected ? text(message, L"accountId") : p->owner;
    require(!mailbox.empty() && mailbox != L"all" && p->shell->connected(mailbox), L"Choose one mailbox for this action.");
    Json input; put(input, L"action", name);
    if (selected) put(input, L"messageId", text(message, L"id"));
    if (mock) {
        if (name == L"followup" || name == L"schedule") {
            auto date = p->date.get(); auto time = p->time.get(); require(date && time, L"Choose a future local time."); put(input, L"when", recordedTime(date, time));
        }
    } else {
        put(input, L"prompt", trim(text(value, L"prompt")));
        if (usesDraft(p)) put(input, L"draftText", text(value, L"draftText"));
        if (name == L"skill") put(input, L"skillId", text(value, L"skillId"));
        if (name == L"ask") truth(input,L"useSmartSearch",flag(value,L"useSmartSearch"));
        if (name == L"reply") truth(input, L"includeHistory", flag(value, L"includeHistory"));
        auto policy = object(object(p->state, L"settings"), L"policy"), model = object(object(p->state, L"settings"), L"ai");
        auto detail = mailbox + L"\n" + text(feature, L"label") + L"\nModel: " + text(model, L"model") + L"\nEndpoint: " + text(model, L"baseUrl") +
            L"\nAllowed folders: " + selectedFlags(object(policy, L"folders")) + L"\nAllowed fields: " + selectedFlags(object(policy, L"content")) + L"\nContext cap: " + count(policy, L"maxMessages") + L" downloaded messages." +
            (name == L"reply" && flag(value, L"includeHistory") ? L"\nIncludes permitted same-correspondent downloaded history within that cap, not all mail." : L"") +
            (usesDraft(p) ? L"\nUses the draft text entered here." : selected ? L"\nUses the selected message shown below." : L"") +
            L"\nProvider charges may apply. Email contents are untrusted; review facts and commitments. This generates text only, never sends mail.";
        if (!(co_await p->shell->confirm(L"Generate response — uses AI?", detail, L"Generate")) || !p->current()) co_return;
        validateContext(p, context);
    }
    p->clearResult(); Json proof;
    if (selected && !mock) {
        auto full = co_await p->shell->service->request(L"/messages/" + escaped(text(message, L"id")), mailbox);
        if (!p->current()) co_return; validateContext(p, context); auto source = object(full, L"message");
        require(text(source, L"accountId") == mailbox && text(source, L"id") == text(message, L"id"), L"The selected message owner changed.");
        proof = sourceProof(source, object(object(p->state, L"settings"), L"policy"));
    }
    auto result = co_await p->shell->service->request(mock ? L"/workflows/preview" : L"/ai", mailbox, L"POST", input);
    if (!p->current()) co_return; validateContext(p, context);
    if (mock) {
        require(flag(result, L"simulated"), L"The service did not identify this preview as a local simulation.");
        p->workflow = object(result, L"preview"); p->workflowContext = context; p->workflowOwner = mailbox;
        require(!text(p->workflow, L"id").empty() && text(p->workflow, L"action") == name, L"The workflow preview does not match this request.");
    } else { p->output = clone(result); p->outputAction = name; p->outputMessage = clone(message); p->outputSource = proof; p->outputContext = context; }
    renderToolResult(p); p->tell(mock ? L"Local preview ready. No provider or AI call was made. Review every proposed change before applying." : L"Response ready. Review it before using it in a draft.");
}
IAsyncAction useToolDraft(Page p) {
    auto context = p->outputContext, name = p->outputAction;
    auto output = clone(p->output), message = clone(p->outputMessage), proof = clone(p->outputSource);
    require(!text(output, L"text").empty() && (name == L"reply" || name == L"write" || name == L"rewrite" || name == L"translate"), L"No draftable result is available.");
    auto mailbox = name == L"reply" || (name == L"translate" && !text(message, L"accountId").empty()) ? text(message, L"accountId") : p->owner;
    require(!mailbox.empty() && mailbox != L"all" && p->shell->connected(mailbox), L"Choose one mailbox before creating this draft.");
    validateContext(p, context);
    auto state = co_await p->shell->service->request(L"/state", p->owner);
    if (!p->current()) co_return; acceptState(p, state); validateContext(p, context);
    if (proof.Size()) {
        auto latest = co_await p->shell->service->request(L"/messages/" + escaped(text(message, L"id")), mailbox);
        if (!p->current()) co_return; validateContext(p, context);
        require(sourceProof(object(latest, L"message"), object(object(p->state, L"settings"), L"policy")).Stringify() == proof.Stringify(), L"The source message changed. Generate a fresh response before drafting.");
    }
    Json draft;
    if (name == L"reply") {
        Json input; put(input, L"mode", L"reply"); put(input, L"messageId", text(message, L"id")); put(input, L"body", text(output, L"text"));
        auto prepared = co_await p->shell->service->request(L"/drafts/prepare", mailbox, L"POST", input);
        if (!p->current()) co_return; validateContext(p, context); draft = object(prepared, L"draft");
        require(text(draft, L"accountId") == mailbox && text(draft, L"replyToId") == text(message, L"id") && text(draft, L"body") == text(output, L"text") && text(draft, L"bcc").empty(), L"Prepared reply did not match the reviewed output.");
    } else {
        put(draft, L"accountId", mailbox); for (auto key : {L"to", L"cc", L"bcc", L"subject"}) put(draft, key, L""); put(draft, L"body", text(output, L"text"));
    }
    p->forms[L"tool"].accept(p->forms[L"tool"].value); p->shell->dirty.erase(p->key()); auto shell = p->shell; p->stop(); co_await compose(shell, draft);
}
void renderToolResult(Page const& p) {
    auto panel = p->resultPanel.get(); if (!panel) return; panel.Children().Clear();
    if (p->workflow.Size()) {
        auto preview = clone(p->workflow); words(panel, text(preview, L"title"), 22); words(panel, L"Local simulation — review before applying");
        words(panel, text(preview, L"summary"));
        for (auto const& entry : array(preview, L"items")) { auto item = entry.GetObject(); words(panel, text(item, L"title"), 16); words(panel, text(item, L"detail")); }
        words(panel, L"This one-use preview expires after 10 minutes and on relevant source or permission changes. Only the local changes shown above will be applied.");
        action(p, panel, L"Apply reviewed local simulation…", [id = text(preview, L"id")](Page page) -> IAsyncAction {
            auto context = page->workflowContext; validateContext(page, context);
            require(text(page->workflow, L"id") == id, L"This preview was replaced. Review the current one.");
            auto owner = page->workflowOwner.empty() ? page->owner : page->workflowOwner;
            require(owner != L"all" && page->shell->connected(owner), L"Choose one mailbox before applying this simulation.");
            if (!(co_await page->shell->confirm(L"Apply this local simulation?", owner + L"\n" + text(page->workflow, L"title") + L"\n" + text(page->workflow, L"summary") + L"\nApply only the changes reviewed on the page. Nothing is sent to a provider.", L"Apply local changes")) || !page->current()) co_return;
            validateContext(page, context); Json input; put(input, L"previewId", id);
            auto result = co_await page->shell->service->request(L"/workflows/apply", owner, L"POST", input);
            if (!page->current()) co_return; require(flag(result, L"simulated"), L"The applied result was not identified as a simulation.");
            acceptState(page, result); page->clearResult(); page->forms[L"tool"].accept(page->forms[L"tool"].value); page->dirty();
            co_await loadMessages(page); if (page->current()) page->tell(L"Reviewed simulation applied locally. See local records, Brain or Drafts for its results. No mail was sent.");
        });
    } else if (p->output.Size()) {
        words(panel, text(p->output, L"source") == L"demo" ? L"Illustrative demo — not a model analysis" : L"AI response — review required", 22);
        words(panel, text(p->output, L"text"));
        sourceLinks(p,panel,array(p->output,L"sources"));
        if (!text(p->output,L"retrievalWarning").empty()) words(panel,text(p->output,L"retrievalWarning"),12);
        auto history = object(p->output, L"history"); if (history.Size()) words(panel, coverage(history));
        if (p->outputAction == L"reply" || p->outputAction == L"write" || p->outputAction == L"rewrite" || p->outputAction == L"translate") action(p, panel, L"Review in a draft", useToolDraft);
    }
    if (p->workflow.Size() || p->output.Size()) action(p, panel, L"Dismiss result", [](Page page) -> IAsyncAction { page->clearResult(); page->tell(L"Result dismissed. No automatic apply or send occurred."); co_return; });
}
IAsyncAction loadMessages(Page p) {
    auto cursor = p->cursors.back(); Json input;
    put(input, L"folder", L""); put(input, L"category", L"all"); truth(input, L"unreadOnly", false);
    put(input, L"sort", L"newest"); put(input, L"cursor", cursor); input.Insert(L"pageSize", Value::CreateNumberValue(50)); put(input, L"locale", L"en");
    auto result = co_await p->shell->service->request(L"/mail/page", p->owner, L"POST", input);
    if (!p->current()) co_return;
    auto policy = object(object(p->state, L"settings"), L"policy"), folders = object(policy, L"folders"); std::vector<Json> messages;
    require(array(result, L"messages").Size() <= 50, L"The mail page exceeded its limit.");
    for (auto const& entry : array(result, L"messages")) {
        auto message = entry.GetObject(); auto account = text(message, L"accountId");
        require(p->owner == L"all" ? p->shell->connected(account) : account == p->owner, L"The mail page contains a different owner.");
        if (flag(folders, text(message, L"folder").c_str())) messages.push_back(message);
    }
    p->messages = std::move(messages); p->nextCursor = text(result, L"nextCursor");
    auto id = text(p->forms[L"tool"].value, L"messageId"); bool retained = false;
    for (auto const& message : p->messages) if (messageKey(message) == id) retained = true;
    if (!retained) { put(p->forms[L"tool"].value, L"messageId", p->messages.empty() ? hstring() : messageKey(p->messages.front())); p->clearResult(); }
    renderTool(p);
}
void renderTool(Page const& p) {
    auto panel = p->toolPanel.get(); if (!panel) return; panel.Children().Clear();
    auto feature = selectedFeature(p), value = p->forms[L"tool"].value; auto name = text(feature, L"id");
    words(panel, text(feature, L"description"));
    words(panel, flag(feature, L"mock") ? simulationNote(name) : hstring(L"Calls your configured chat model only after confirmation. Every response needs human review."));
    auto policy = object(object(p->state, L"settings"), L"policy"), content = object(policy, L"content");
    Expander scope; scope.Header(box_value(L"Mail and permissions used")); auto scopeDetails = stack(6); scope.Content(scopeDetails); panel.Children().Append(scope);
    words(scopeDetails, L"Saved scope: " + selectedFlags(object(policy, L"folders")) + L"\nSaved fields: " + selectedFlags(content) + L"\nContext cap: " + count(policy, L"maxMessages") + L" downloaded messages. The server rechecks permissions and ownership.");
    if (text(feature, L"context") == L"selected") {
        if (name == L"translate") editChoice(p, panel, L"tool", L"translateSource", L"Translate source", {{L"message", L"Selected message"}, {L"draft", L"Draft text entered below"}});
        ComboBox picker; picker.Header(box_value(L"Message from permitted folders")); picker.HorizontalAlignment(xaml::HorizontalAlignment::Stretch);
        auto selectedId = text(value, L"messageId");
        for (auto const& message : p->messages) {
            auto title = (flag(content, L"subject") ? text(message, L"subject", L"No subject") : hstring(L"Subject withheld")) +
                (flag(content, L"sender") ? L" · " + text(message, L"fromName", text(message, L"fromEmail")) : hstring()) + L" · " + text(message, L"date");
            ComboBoxItem item;             item.Content(box_value(title)); item.Tag(box_value(messageKey(message))); picker.Items().Append(item);
            if (messageKey(message) == selectedId) picker.SelectedItem(item);
        }
        std::weak_ptr<Intelligence> weak = p;
        picker.SelectionChanged([weak](auto const& sender, auto const&) { if (auto page = weak.lock(); page && page->current() && !page->busy) {
            auto item = sender.template as<ComboBox>().SelectedItem().template try_as<ComboBoxItem>();
            if (item) { put(page->forms[L"tool"].value, L"messageId", unbox_value<hstring>(item.Tag())); page->changed(L"tool"); }
        } }); panel.Children().Append(picker); p->messagePicker = make_weak(picker);
        words(panel, L"Page " + to_hstring(p->cursors.size()) + L" · " + to_hstring(p->messages.size()) + L" permitted rows on this bounded page. Pages with no permitted rows can still have a next page.");
        auto previous = action(p, panel, L"Previous mail page", [](Page page) -> IAsyncAction {
            if (page->cursors.size() <= 1) co_return; auto old = page->cursors; page->cursors.pop_back();
            try { co_await loadMessages(page); } catch (...) { page->cursors = std::move(old); throw; }
        }); previous.IsEnabled(p->cursors.size() > 1);
        auto next = action(p, panel, L"Next mail page", [](Page page) -> IAsyncAction {
            if (page->nextCursor.empty()) co_return; auto old = page->cursors; page->cursors.push_back(page->nextCursor);
            try { co_await loadMessages(page); } catch (...) { page->cursors = std::move(old); throw; }
        }); next.IsEnabled(!p->nextCursor.empty());
    }
    if (name == L"rewrite" || name == L"translate") editText(p, panel, L"tool", L"draftText", L"Draft text (translation uses this only when Draft text is selected)", 100000, true);
    if (name == L"reply") editCheck(p, panel, L"tool", L"includeHistory", L"Suggest with History — include bounded permitted downloaded correspondence with this sender");
    if (name == L"skill") {
        ComboBox picker; picker.Header(box_value(L"Saved skill")); picker.HorizontalAlignment(xaml::HorizontalAlignment::Stretch);
        auto chosen = text(value, L"skillId");
        for (auto const& entry : array(object(p->state, L"workspace"), L"skills")) {
            auto skill = entry.GetObject(); ComboBoxItem item; item.Content(box_value(text(skill, L"name") + (flag(skill, L"enabled") ? L"" : L" — disabled"))); item.Tag(box_value(text(skill, L"id"))); item.IsEnabled(flag(skill, L"enabled")); picker.Items().Append(item);
            if (text(skill, L"id") == chosen) picker.SelectedItem(item);
        }
        std::weak_ptr<Intelligence> weak = p;
        picker.SelectionChanged([weak](auto const& sender, auto const&) { if (auto page = weak.lock(); page && page->current() && !page->busy) {
            auto item = sender.template as<ComboBox>().SelectedItem().template try_as<ComboBoxItem>();
            if (item) { put(page->forms[L"tool"].value, L"skillId", unbox_value<hstring>(item.Tag())); page->changed(L"tool"); }
        } }); panel.Children().Append(picker); p->skillPicker = make_weak(picker);
    }
    if (!flag(feature, L"mock")) {
        if (name == L"ask" || name == L"write") {
            editText(p, panel, L"tool", L"prompt", name == L"ask" ? L"What would you like to know about your mail?" : L"What would you like to say?", 2000, true);
            if (name == L"ask") {
                for (auto example : {L"What did we agree about the project deadline?",L"Which questions about the proposal remain unanswered?"}) action(p,panel,example,[question=hstring(example)](Page page) -> IAsyncAction { put(page->forms[L"tool"].value,L"prompt",question); page->forms[L"tool"].show(); page->changed(L"tool"); co_return; });
                editCheck(p,panel,L"tool",L"useSmartSearch",L"Use my approved Smart Search index");
                words(panel,L"Smart retrieval uses this mailbox’s permitted indexed mail. The question may go to your embedding model and incur charges. No indexing starts here; maximum question length is 500 characters.",12);
            }
        } else {
            Expander extra; extra.Header(box_value(L"Additional instructions (optional)")); auto fields = stack(8);
            editText(p, fields, L"tool", L"prompt", L"Instructions", 2000, true); extra.Content(fields); panel.Children().Append(extra);
        }
    }
    if (name == L"followup" || name == L"schedule") {
        DatePicker date; date.Header(box_value(L"Date for local record")); date.Date(winrt::clock::now() + std::chrono::hours(24));
        TimePicker time; time.Header(box_value(L"Time on this device")); time.Time(std::chrono::hours(9));
        std::weak_ptr<Intelligence> weak = p;
        date.DateChanged([weak](auto const&, auto const&) { if (auto page = weak.lock(); page && page->current()) { page->clearResult(); ++page->revision; } });
        time.TimeChanged([weak](auto const&, auto const&) { if (auto page = weak.lock(); page && page->current()) { page->clearResult(); ++page->revision; } });
        panel.Children().Append(date); panel.Children().Append(time); p->date = make_weak(date); p->time = make_weak(time);
        words(panel, L"Uses this device’s local time zone and verifies daylight-saving gaps. This is a local record, not a scheduled notification or real event.");
    }
    action(p, panel, flag(feature, L"mock") ? L"Create local preview — no AI call" : name == L"ask" ? L"Ask my mail…" : name == L"reply" ? L"Draft reply…" : (name == L"summary" || name == L"briefing") ? L"Create summary…" : L"Create text…", runTool);
    action(p, panel, L"Discard tool inputs and result…", [](Page page) -> IAsyncAction {
        if (!(co_await page->shell->confirm(L"Discard tool inputs?", L"Clear entered instructions, draft text and the unsaved result. Saved messages remain.", L"Discard inputs")) || !page->current()) co_return;
        auto& form = page->forms[L"tool"]; put(form.value, L"prompt", L""); put(form.value, L"draftText", L""); form.accept(form.value); page->clearResult(); page->dirty(); renderTool(page);
    });
}
void renderRulePreview(Page const& p) {
    auto panel=p->resultPanel.get(); if (!panel) return; panel.Children().Clear();
    auto preview=clone(p->workflow); if (!preview.Size()) return;
    words(panel,to_hstring(array(preview,L"messages").Size()) + L" matches among " + count(preview,L"scanned") + L" downloaded Inbox messages",18);
    for (auto const& entry : array(preview,L"messages")) { auto message=entry.GetObject(); words(panel,text(message,L"fromEmail") + L" · " + text(message,L"subject")); }
    words(panel,L"Preview expires in ten minutes. Changed mail or a reconnected account requires another review.",12);
    action(p,panel,L"Apply reviewed matches & save rule",[id=text(preview,L"previewId")](Page page) -> IAsyncAction {
        require(text(page->workflow,L"previewId") == id,L"Review a new rule preview."); Json input; put(input,L"previewId",id);
        auto result=co_await page->shell->service->request(L"/workspace/rules/apply",page->owner,L"POST",input);
        if (!page->current()) co_return; require(text(result,L"accountId")==page->owner,L"Rule account changed.");
        page->forms[L"rule"].accept(page->forms[L"rule"].value); page->clearResult(); page->dirty();
        auto shell=page->shell; page->stop(); co_await intelligencePage(shell,L"rules");
    });
}
IAsyncAction previewRule(Page p) {
    auto input=clone(p->forms[L"rule"].value); p->clearResult();
    auto result=co_await p->shell->service->request(L"/workspace/rules/preview",p->owner,L"POST",input);
    if (!p->current()) co_return; require(text(result,L"accountId")==p->owner,L"Rule mailbox changed."); p->workflow=result; renderRulePreview(p);
}
void buildRules(Page const& p, StackPanel const& body) {
    words(body,L"Local Inbox Rules",24);
    words(body,L"Checks the newest 500 downloaded Inbox messages in this mailbox. Rules run only after preview and apply. Mail stays in its provider folder; Later is a local review view.");
    Json value; put(value,L"condition",L"domain"); put(value,L"value",L""); put(value,L"action",L"lowPriority"); editor(p,L"rule",value);
    editChoice(p,body,L"rule",L"condition",L"Match",{{L"sender",L"Sender address equals"},{L"domain",L"Sender domain equals"},{L"subject",L"Subject contains"}});
    editText(p,body,L"rule",L"value",L"Exact sender/domain or subject text",254);
    editChoice(p,body,L"rule",L"action",L"Local marker",{{L"lowPriority",L"Read later"},{L"pending",L"Pending"},{L"starred",L"Star"}});
    action(p,body,L"Discard rule inputs",[](Page page) -> IAsyncAction { page->forms[L"rule"].accept(page->forms[L"rule"].saved); page->clearResult(); page->dirty(); co_return; });
    action(p,body,L"Preview matches",previewRule); auto review=stack(10); body.Children().Append(review); p->resultPanel=make_weak(review);
    words(body,L"Saved rules",20);
    for (auto const& entry : array(object(p->state,L"workspace"),L"rules")) {
        auto rule=entry.GetObject(); auto row=group(body,text(rule,L"condition") + L": " + text(rule,L"value") + L" → " + (text(rule,L"action")==L"lowPriority" ? L"Later" : text(rule,L"action")));
        action(p,row,L"Review",[rule](Page page) -> IAsyncAction { auto value=subset(rule,{L"condition",L"value",L"action"}); page->forms[L"rule"].value=value; page->forms[L"rule"].show(); page->changed(L"rule"); co_await previewRule(page); });
        action(p,row,L"Remove",[id=text(rule,L"id")](Page page) -> IAsyncAction { require(!page->forms[L"rule"].dirty(),L"Apply or discard rule inputs before removing a saved rule."); co_await page->shell->service->request(L"/workspace/rules/" + escaped(id),page->owner,L"DELETE"); if (!page->current()) co_return; auto shell=page->shell; page->stop(); co_await intelligencePage(shell,L"rules"); });
    }
}
void buildTools(Page const& p, StackPanel const& body) {
    words(body, p->kind == L"simulations" ? L"Local simulations" : L"Assistant", 24); words(body, L"Choose a task, then review the result.");
    if (p->owner == L"all" && p->kind != L"simulations") words(body, L"Choose one mailbox tab for inbox-wide AI tasks. You can still select a specific email across accounts below.");
    Json value; put(value, L"action", p->kind == L"simulations" ? L"triage" : L"ask"); put(value, L"prompt", L""); put(value, L"draftText", L""); put(value, L"messageId", L""); put(value, L"skillId", L""); put(value, L"translateSource", L"message"); truth(value, L"includeHistory", false); truth(value,L"useSmartSearch",false);
    if ((p->owner == L"all" || text(p->shell->selected, L"accountId") == p->owner) && p->shell->connected(text(p->shell->selected, L"accountId"))) put(value, L"messageId", messageKey(p->shell->selected));
    for (auto const& entry : array(object(p->state, L"workspace"), L"skills")) if (flag(entry.GetObject(), L"enabled")) { put(value, L"skillId", text(entry.GetObject(), L"id")); break; }
    editor(p, L"tool", value);
    ComboBox picker; picker.Header(box_value(L"What would you like to do?")); picker.HorizontalAlignment(xaml::HorizontalAlignment::Stretch);
    for (auto const& entry : array(p->state, L"features")) {
        auto feature = entry.GetObject();
        if (text(feature, L"id") == L"memory" || flag(feature, L"mock") != (p->kind == L"simulations")) continue;
        p->features.push_back(feature); ComboBoxItem item;
        item.Content(box_value(text(feature, L"label"))); item.Tag(box_value(text(feature, L"id"))); picker.Items().Append(item);
        if (text(feature, L"id") == text(value, L"action")) picker.SelectedItem(item);
    }
    std::weak_ptr<Intelligence> weak = p;
    picker.SelectionChanged([weak](auto const& sender, auto const&) { if (auto page = weak.lock(); page && page->current() && !page->busy) {
        auto item = sender.template as<ComboBox>().SelectedItem().template try_as<ComboBoxItem>();
        if (item) { put(page->forms[L"tool"].value, L"action", unbox_value<hstring>(item.Tag())); page->changed(L"tool"); renderTool(page); }
    } }); body.Children().Append(picker); p->featurePicker = make_weak(picker);
    auto tool = stack(12), result = stack(12); body.Children().Append(tool); body.Children().Append(result); p->toolPanel = make_weak(tool); p->resultPanel = make_weak(result);
    renderTool(p);
}

fire_and_forget refreshIntelligence(Page p) {
    if (!p->current() || p->busy || p->cancelling || p->polling) co_return;
    p->polling = true; auto revision = p->revision;
    try {
        auto next = co_await p->shell->service->request(L"/state", p->owner);
        if (p->current() && !p->busy && !p->cancelling && p->revision == revision) {
            auto oldContext = p->context;
            acceptState(p, next);
            if (p->kind == L"learning") updateLearningForms(p);
            else if (p->kind == L"reply-suggestions") {
                auto suggestions = co_await p->shell->service->request(L"/reply-suggestions", p->owner);
                if (p->current() && !p->busy && !p->cancelling && p->revision == revision) acceptSuggestions(p, suggestions);
            } else if (p->kind == L"brain") {
                updateLearningForms(p);
                auto proposal = object(object(object(p->state,L"workspace"),L"brainLearning"),L"preview");
                if (text(proposal,L"id") != text(p->memoryPreview,L"id") && proposal.Size()) { p->selectedMemories.clear(); p->memoryPreview=proposal; renderMemoryPreview(p); }
            } else if ((p->kind == L"studio" || p->kind == L"simulations") && oldContext != p->context) {
                auto folders = object(object(object(p->state, L"settings"), L"policy"), L"folders");
                std::erase_if(p->messages, [&](Json const& message) { return !flag(folders, text(message, L"folder").c_str()); });
                renderTool(p); p->tell(L"Saved context changed. Previous results were cleared; review permissions and inputs before running again.");
            }
        }
    } catch (hresult_error const& error) {
        if (p->revision == revision && !p->busy) { p->clearResult(); p->tell(error.message()); }
    } catch (...) { if (p->revision == revision && !p->busy) { p->clearResult(); p->tell(L"Status could not refresh. Review current account status before continuing."); } }
    p->polling = false;
}
Json blankCategory() {
    Json value; put(value, L"id", L""); put(value, L"name", L""); put(value, L"description", L""); put(value, L"priority", L""); put(value, L"prompt", L"");
    truth(value, L"enabled", true); return value;
}
void renderCategories(Page const& p) {
    auto list = p->categoryList.get(); if (!list) return; list.Children().Clear();
    auto categories = array(object(p->state, L"workspace"), L"categories");
    if (!categories.Size()) words(list, L"No categories for this mailbox. Add one below or reset the suggested set.");
    std::vector<hstring> ids;
    for (auto const& entry : categories) ids.push_back(text(entry.GetObject(), L"id"));
    for (uint32_t index = 0; index < categories.Size(); ++index) {
        auto category = categories.GetAt(index).GetObject(); auto id = ids[index];
        auto item = group(list, text(category, L"name") + (flag(category, L"enabled") ? L"" : L" — disabled"));
        auto priority = text(category, L"priority");
        words(item, (priority.empty() ? hstring(L"No priority") : priority) + L" · " + text(category, L"description"));
        MenuFlyout management;
        menuAction(p, management, L"Edit", [category](Page page) -> IAsyncAction {
            if (page->forms[L"category"].dirty() && !(co_await page->shell->confirm(L"Discard unsaved category edits?", L"Load this saved category into the editor below.", L"Edit saved category"))) co_return;
            if (!page->current()) co_return;
            Json value = blankCategory();
            put(value, L"id", text(category, L"id")); put(value, L"name", text(category, L"name"));
            put(value, L"description", text(category, L"description")); put(value, L"priority", text(category, L"priority"));
            truth(value, L"enabled", flag(category, L"enabled"));
            page->forms[L"category"].accept(value); if(auto editor=page->categoryEditor.get())editor.Visibility(xaml::Visibility::Visible); page->dirty(); page->tell(L"Category loaded. Save to keep changes.");
            co_return;
        });
        menuAction(p, management, L"Delete…", [id, name = text(category, L"name")](Page page) -> IAsyncAction {
            auto editing = text(page->forms[L"category"].value, L"id") == id;
            auto detail = name + L"\nMail is not changed." + (editing && page->forms[L"category"].dirty() ? L" Unsaved edits to this category will be discarded." : L"");
            if (!(co_await page->shell->confirm(L"Delete this category?", detail, L"Delete category")) || !page->current()) co_return;
            auto result = co_await page->shell->service->request(L"/workspace/categories/" + escaped(id), page->owner, L"DELETE");
            if (!page->current()) co_return; acceptState(page, result);
            if (text(page->forms[L"category"].value, L"id") == id) page->forms[L"category"].accept(blankCategory());
            renderCategories(page); page->dirty(); page->tell(L"Category deleted.");
        });
        if (index > 0) menuAction(p, management, L"Move up", [ids, index](Page page) -> IAsyncAction {
            auto order = ids; auto moved = order[index - 1]; order[index - 1] = order[index]; order[index] = moved;
            Json input; Array values; for (auto const& saved : order) values.Append(Value::CreateStringValue(saved)); input.Insert(L"ids", values);
            auto result = co_await page->shell->service->request(L"/workspace/categories/reorder", page->owner, L"POST", input);
            if (!page->current()) co_return; acceptState(page, result); renderCategories(page);
        });
        if (index + 1 < ids.size()) menuAction(p, management, L"Move down", [ids, index](Page page) -> IAsyncAction {
            auto order = ids; auto moved = order[index + 1]; order[index + 1] = order[index]; order[index] = moved;
            Json input; Array values; for (auto const& saved : order) values.Append(Value::CreateStringValue(saved)); input.Insert(L"ids", values);
            auto result = co_await page->shell->service->request(L"/workspace/categories/reorder", page->owner, L"POST", input);
            if (!page->current()) co_return; acceptState(page, result); renderCategories(page);
        });
        auto more=actionMenu(L"More",management,L"More actions for category: "+text(category,L"name"));
        xaml::Automation::AutomationProperties::SetAutomationId(more,L"category.more."+id);item.Children().Append(more);
    }
}
void buildCategories(Page const& p, StackPanel const& body) {
    words(body, L"Mail categories", 24);
    words(body, L"These labels order Today suggestions for this mailbox. Saving them does not call a model, send mail, or change Email Brain.");
    auto list = stack(12); body.Children().Append(list); p->categoryList = make_weak(list);
    auto fields=stack(12);fields.Visibility(xaml::Visibility::Collapsed);p->categoryEditor=make_weak(fields);
    xaml::Automation::AutomationProperties::SetAutomationId(fields,L"category.editor");
    auto add=action(p,body,L"Add category",[](Page page) -> IAsyncAction {
        if(page->forms[L"category"].dirty() && !(co_await page->shell->confirm(L"Discard unsaved category edits?",L"Start a new category without changing the saved category.",L"Add new category")))co_return;
        if(!page->current())co_return;
        page->forms[L"category"].accept(blankCategory());
        if(auto editor=page->categoryEditor.get())editor.Visibility(xaml::Visibility::Visible);
        page->dirty();page->tell(L"New category. Save to add it to this mailbox.");
    });
    xaml::Automation::AutomationProperties::SetAutomationId(add,L"category.add");
    words(fields,L"Add or edit a category",20);body.Children().Append(fields);
    editor(p, L"category", blankCategory());
    auto name=editText(p, fields, L"category", L"name", L"Name", 80);
    xaml::Automation::AutomationProperties::SetAutomationId(name,L"category.name");
    editText(p, fields, L"category", L"description", L"Description", 240);
    editChoice(p, fields, L"category", L"priority", L"Priority", {{L"", L"None"}, {L"P0", L"P0"}, {L"P1", L"P1"}, {L"P2", L"P2"}, {L"P3", L"P3"}, {L"P4", L"P4"}});
    editCheck(p, fields, L"category", L"enabled", L"Enabled");
    editText(p, fields, L"category", L"prompt", L"Draft a name without calling a model", 80);
    auto save=action(p, fields, L"Save category", [](Page page) -> IAsyncAction {
        auto value = page->forms[L"category"].value;
        require(!trim(text(value, L"name")).empty(), L"Enter a category name.");
        Json input; put(input, L"name", trim(text(value, L"name"))); put(input, L"description", text(value, L"description")); put(input, L"priority", text(value, L"priority"));
        truth(input, L"enabled", flag(value, L"enabled"));
        auto id = text(value, L"id");
        auto path = id.empty() ? hstring(L"/workspace/categories") : L"/workspace/categories/" + escaped(id);
        auto result = co_await page->shell->service->request(path, page->owner, L"POST", input);
        if (!page->current()) co_return; acceptState(page, result); page->forms[L"category"].accept(blankCategory());
        renderCategories(page); page->dirty(); page->tell(L"Category saved for this mailbox.");
    });
    xaml::Automation::AutomationProperties::SetAutomationId(save,L"category.save");
    action(p, fields, L"Clear form", [](Page page) -> IAsyncAction {
        if (page->forms[L"category"].dirty() && !(co_await page->shell->confirm(L"Discard unsaved category edits?", L"Clear the category form without saving it.", L"Clear form"))) co_return;
        if (!page->current()) co_return;
        page->forms[L"category"].accept(blankCategory()); page->dirty(); page->tell(L"Category form cleared."); co_return;
    });
    action(p, fields, L"Draft name", [](Page page) -> IAsyncAction {
        auto prompt = trim(text(page->forms[L"category"].value, L"prompt"));
        require(!prompt.empty(), L"Enter a category name to draft.");
        auto& form = page->forms[L"category"];
        auto fields = {L"id", L"name", L"description", L"priority", L"enabled"};
        if (subset(form.value, fields).Stringify() != subset(form.saved, fields).Stringify() && !(co_await page->shell->confirm(L"Replace unsaved category edits?", L"The drafted name replaces the current category form without saving it.", L"Draft name"))) co_return;
        if (!page->current()) co_return;
        Json input; put(input, L"prompt", prompt);
        auto result = co_await page->shell->service->request(L"/workspace/categories/suggest", page->owner, L"POST", input);
        if (!page->current()) co_return;
        require(flag(result, L"stub") && !flag(result, L"saved"), L"The draft was not saved.");
        auto suggestion = object(result, L"suggestion");
        Json value = blankCategory(); put(value, L"name", text(suggestion, L"name")); put(value, L"description", text(suggestion, L"description")); put(value, L"prompt", prompt);
        form.accept(blankCategory()); form.value = value; form.show(); page->changed(L"category");
        page->tell(L"Draft only. Save the category if you want to keep it. No model was called.");
    });
    action(p, fields, L"Reset suggested categories…", [](Page page) -> IAsyncAction {
        if (!(co_await page->shell->confirm(L"Restore the suggested categories?", L"This replaces the saved list for this mailbox and discards unsaved category edits. Mail is not changed.", L"Reset categories")) || !page->current()) co_return;
        auto result = co_await page->shell->service->request(L"/workspace/categories/reset", page->owner, L"POST", Json());
        if (!page->current()) co_return; acceptState(page, result); page->forms[L"category"].accept(blankCategory());
        renderCategories(page); page->dirty(); page->tell(L"Suggested categories restored.");
    });
    renderCategories(p);
}

void agentReload(Page const& page, Json const& result, hstring expected = {}) {
    require(text(result, L"accountId") == page->owner && text(result, L"transport") == L"local-byo" && !flag(result, L"cloud"), L"Inbox Agent returned an unexpected response.");
    auto conversation = object(result, L"conversation");
    if (conversation.Size() || !expected.empty()) {
        require(text(conversation, L"accountId") == page->owner && !text(conversation, L"id").empty()
            && (expected.empty() || text(conversation, L"id") == expected), L"Conversation mailbox or identity changed.");
        page->shell->agentConversation = text(conversation, L"id");
        page->workflow = conversation;
    }
}

// Named coroutine: page is owned by the coroutine frame, including while the
// request is suspended. Stop deliberately bypasses perform's busy gate.
fire_and_forget agentStop(Page page) {
    auto id = page->shell->agentConversation;
    if (id.empty() || !page->current() || page->cancelling) co_return;
    auto owner = page->owner;
    page->cancelling = true; ++page->revision; page->dirty();
    bool stopped = false;
    try {
        Json body; put(body, L"conversationId", id);
        auto result = co_await page->shell->service->request(L"/agent/cancel", owner, L"POST", body);
        if (page->current() && page->owner == owner && page->shell->agentConversation == id) {
            agentReload(page, result, id); page->agentRecovering = false; stopped = true;
            page->tell(L"Stop requested. A model request cannot send mail.");
        }
    } catch (hresult_error const& error) { page->agentRecovering = true; if (page->current()) page->tell(error.message()); }
    catch (...) { page->agentRecovering = true; if (page->current()) page->tell(L"Inbox Agent could not be stopped. Its saved status will be checked before another request."); }
    page->cancelling = false;
    if (!page->current()) { if (!page->busy) page->shell->dirty.erase(page->key()); co_return; }
    page->dirty();
    if (stopped) { auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"agent"); }
}

hstring agentSendReviewText(Json const& preview, hstring const& owner) {
    auto truncated = preview.TryLookup(L"bodyTruncated");
    require(flag(preview, L"complete") && truncated && truncated.ValueType() == JsonValueType::Boolean && !truncated.GetBoolean()
        && !owner.empty() && text(preview, L"fromEmail") == owner, L"This send review is incomplete. Dismiss it and ask for a new review before sending.");
    for (auto key : {L"fromName", L"fromEmail", L"to", L"cc", L"bcc", L"subject", L"body"}) {
        auto value = preview.TryLookup(key); require(value && value.ValueType() == JsonValueType::String, L"This send review is incomplete.");
    }
    auto attached = preview.TryLookup(L"attachments");
    require(attached && attached.ValueType() == JsonValueType::Array, L"The attachment list is incomplete.");
    auto footer = object(preview, L"footer");
    for (auto key : {L"text", L"html"}) {
        auto value = footer.TryLookup(key); require(value && value.ValueType() == JsonValueType::String, L"The email footer review is incomplete.");
    }
    auto attachments = attached.GetArray(); hstring names;
    for (auto const& value : attachments) {
        auto item = value.GetObject(); auto size = item.GetNamedNumber(L"size", -1);
        require(!text(item, L"id").empty() && !text(item, L"name").empty() && std::isfinite(size) && size >= 0
            && size <= 50 * 1024 * 1024 && std::floor(size) == size, L"The attachment list is incomplete.");
        auto type = item.TryLookup(L"contentType"); require(type && type.ValueType() == JsonValueType::String, L"The attachment type is missing.");
        names = names + (names.empty() ? L"" : L"\n") + text(item, L"name") + L" (" + to_hstring(static_cast<uint64_t>(size)) + L" bytes; " + type.GetString() + L")\nAttachment ID: " + text(item, L"id");
    }
    // Shell::confirm uses an unbounded TextBlock in a ScrollViewer. Do not pass
    // this payload through words()/bounded(), which truncates normal chat text.
    return L"Mailbox: " + owner + L"\nFrom: " + text(preview, L"fromName") + L" <" + text(preview, L"fromEmail")
        + L">\nTo: " + text(preview, L"to") + L"\nCc: " + text(preview, L"cc") + L"\nBcc: " + text(preview, L"bcc")
        + L"\nSubject: " + text(preview, L"subject") + L"\n\nMessage\n" + text(preview, L"body")
        + L"\n\nAttachments (" + to_hstring(attachments.Size()) + L")\n" + (names.empty() ? hstring(L"None") : names)
        + L"\n\nEmail footer\n" + (text(footer, L"text").empty() ? hstring(L"None") : text(footer, L"text"))
        + L"\n\nFooter HTML (including link destinations)\n" + (text(footer, L"html").empty() ? hstring(L"None") : text(footer, L"html"));
}

IAsyncAction agentMutation(Page page, hstring path, Json input) {
    auto id = text(input, L"conversationId"), owner = page->owner;
    auto revision = page->revision;
    page->agentRecovering = true;
    hstring failure;
    try {
        auto result = co_await page->shell->service->request(path, owner, L"POST", input);
        if (!page->current() || page->shell->agentConversation != id || page->revision != revision) co_return;
        agentReload(page, result, id); page->agentRecovering = false;
    } catch (hresult_error const& error) { failure = error.message(); }
    catch (...) { failure = L"The request was interrupted. Its saved status is being checked; nothing will be resent automatically."; }
    if (!page->current() || page->shell->agentConversation != id || page->revision != revision) co_return;
    if (!failure.empty()) {
        page->tell(failure);
        try {
            auto result = co_await page->shell->service->request(L"/agent/conversations/" + escaped(id), owner);
            if (!page->current() || page->shell->agentConversation != id || page->revision != revision) co_return;
            agentReload(page, result, id); page->agentRecovering = false;
        } catch (...) {
            if (page->current() && page->shell->agentConversation == id && page->revision == revision)
                page->tell(L"The saved conversation could not be checked. Use Stop or wait for status recovery. Nothing will be resent automatically.");
        }
    }
    if (page->current() && !page->agentRecovering) {
        auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"agent");
        if (!failure.empty()) shell->error(failure);
    }
}

fire_and_forget refreshAgent(Page page) {
    auto id = page->shell->agentConversation, owner = page->owner;
    auto state = text(page->workflow, L"status");
    if (!page->current() || id.empty() || page->busy || page->cancelling || page->polling
        || !(page->agentRecovering || state == L"running" || state == L"confirming")) co_return;
    page->polling = true; auto revision = page->revision;
    try {
        auto result = co_await page->shell->service->request(L"/agent/conversations/" + escaped(id), owner);
        if (page->current() && !page->busy && !page->cancelling && page->revision == revision && page->shell->agentConversation == id) {
            auto previous = page->workflow.Stringify(); auto recovering = page->agentRecovering;
            agentReload(page, result, id); page->agentRecovering = false;
            if (recovering || previous != page->workflow.Stringify()) {
                auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"agent");
            }
        }
    } catch (...) { if (page->current() && page->revision == revision) page->tell(L"Waiting to recover this conversation. Stop remains available; no request will be resent."); }
    page->polling = false;
}
IAsyncAction buildAgent(Page p, StackPanel const& body) {
    words(body, L"Inbox Agent", 24);
    words(body, L"A local multi-turn assistant for this mailbox. It uses the model you configured and stores the chat on this device. It can read permitted cached mail and save drafts. Archive, star, trash, read and pending changes, and sending, wait until you confirm them here. This page does not contact a Morrow cloud agent or update Email Brain.");
    auto settings = object(p->state, L"settings");
    auto policy = object(settings, L"policy");
    if (!flag(object(settings, L"ai"), L"configured")) words(body, L"Set up a model before using Inbox Agent.");
    else if (!flag(policy, L"enabled") || !flag(object(policy, L"behaviors"), L"ask")) words(body, L"Inbox Agent is off. Enable Ask your inbox in AI permissions.");
    auto listed = co_await p->shell->service->request(L"/agent/recents", p->owner);
    if (!p->current()) co_return;
    agentReload(p, listed);
    action(p, body, L"New conversation", [](Page page) -> IAsyncAction {
        auto revision = page->revision;
        auto result = co_await page->shell->service->request(L"/agent/start", page->owner, L"POST", Json());
        if (!page->current() || page->revision != revision) co_return;
        agentReload(page, result);
        auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"agent");
    });
    words(body, L"Recent conversations", 20);
    auto selected = p->shell->agentConversation;
    bool found = selected.empty();
    for (auto const& entry : array(listed, L"recents")) {
        auto row = entry.GetObject(); auto id = text(row, L"id");
        if (id == selected) found = true;
        auto line=stack(6);body.Children().Append(line);auto status=text(row,L"status");
        words(line,status==L"running" ? L"Working" : status==L"awaiting" ? L"Waiting for your review" : status==L"confirming" ? L"Applying your confirmation" : L"Ready");
        action(p, line, text(row,L"title",L"New conversation"), [id](Page page) -> IAsyncAction {
            page->shell->agentConversation = id; auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"agent");
        });
        MenuFlyout management;
        menuAction(p, management, L"Delete conversation…", [id](Page page) -> IAsyncAction {
            auto revision = page->revision;
            if (!(co_await page->shell->confirm(L"Delete this conversation?", L"Saved mail stays in the mailbox. This only removes the local chat.", L"Delete"))) co_return;
            if (!page->current() || page->revision != revision) co_return;
            auto result = co_await page->shell->service->request(L"/agent/conversations/" + escaped(id), page->owner, L"DELETE");
            if (!page->current() || page->revision != revision) co_return;
            agentReload(page, result);
            if (page->shell->agentConversation == id) page->shell->agentConversation = {};
            auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"agent");
        });
        line.Children().Append(actionMenu(L"More",management,L"More actions for conversation: "+text(row,L"title",L"New conversation")));
    }
    if (!found) { p->shell->agentConversation = {}; selected = {}; }
    Json conversation;
    if (!selected.empty()) {
        auto opened = co_await p->shell->service->requestWithStatus(L"/agent/conversations/" + escaped(selected), p->owner, L"GET", Json());
        if (!p->current()) co_return;
        auto status = static_cast<int>(opened.GetNamedNumber(L"status", 0));
        if (status == 404) p->shell->agentConversation = {};
        else {
            require(status >= 200 && status < 300, L"This conversation could not be opened.");
            auto payload = object(opened, L"body");
            agentReload(p, payload);
            conversation = object(payload, L"conversation");
            require(text(conversation, L"accountId") == p->owner, L"Conversation mailbox changed.");
        }
    }
    if (!conversation.Size()) { co_return; }
    p->workflow = conversation;
    words(body, text(conversation, L"title"), 20);
    for (auto const& entry : array(conversation, L"turns")) {
        auto turn = entry.GetObject();
        words(body, text(turn, L"role") + L": " + text(turn, L"text"));
    }
    auto pending = object(conversation, L"pending");
    auto state = text(conversation, L"status");
    if (pending.Size()) {
        words(body, text(pending, L"summary"), 16);
        auto preview = object(pending, L"preview");
        auto proposal = text(pending, L"id");
        auto sending = text(pending, L"kind") == L"send";
        bool complete = !sending;
        if (sending) {
            try { (void)agentSendReviewText(preview, p->owner); complete = true; }
            catch (...) { words(body, L"This saved send review is incomplete. Dismiss it and ask for a new review."); }
            if (complete) words(body, L"Review the complete message, recipients, attachments and footer before sending.");
        }
        auto confirm = action(p, body, sending ? L"Review and send" : L"Review and apply", [proposal, sending, pending = clone(pending), id = selected](Page page) -> IAsyncAction {
            auto revision = page->revision;
            require(page->shell->agentConversation == id && text(page->workflow, L"status") == L"awaiting"
                && object(page->workflow, L"pending").Stringify() == pending.Stringify(), L"This review changed. Open the current review before continuing.");
            auto summary = text(pending, L"summary");
            auto title = sending ? L"Send this message?" : L"Apply this mailbox change?";
            auto detail = sending ? agentSendReviewText(object(pending, L"preview"), page->owner)
                + L"\n\nChoose Send to deliver this complete reviewed message. Changes to the draft or sender require a new review."
                : summary + L"\n\nMailbox: " + page->owner;
            if (!(co_await page->shell->confirm(title, detail, sending ? L"Send" : L"Apply"))) co_return;
            if (!page->current() || page->shell->agentConversation != id || page->revision != revision) co_return;
            require(object(page->workflow, L"pending").Stringify() == pending.Stringify(), L"This review changed. Review it again before continuing.");
            Json body; put(body, L"conversationId", id); put(body, L"proposalId", proposal); put(body, L"decision", L"confirm");
            co_await agentMutation(page, L"/agent/answer", body);
        });
        confirm.IsEnabled(complete && state == L"awaiting");
        auto dismiss = action(p, body, L"Dismiss review", [proposal, id = selected](Page page) -> IAsyncAction {
            require(page->shell->agentConversation == id, L"The selected conversation changed.");
            Json body; put(body, L"conversationId", id); put(body, L"proposalId", proposal); put(body, L"decision", L"deny");
            co_await agentMutation(page, L"/agent/answer", body);
        });
        dismiss.IsEnabled(state == L"awaiting");
    }
    if (state == L"running" || state == L"awaiting") {
        if (state == L"running") words(body, L"This turn is still running. Use Stop. Mail is not sent without confirmation.");
    }
    if (state != L"running" && state != L"confirming") {
        auto name = field(L"Conversation title", text(conversation, L"title"), false);
        name.MaxLength(80);auto renameFields=stack(8);renameFields.Visibility(xaml::Visibility::Collapsed);renameFields.Children().Append(name);
        MenuFlyout management;management.Items().Append(menuItem(L"Rename conversation…",[weak=std::weak_ptr<Intelligence>(p),fields=make_weak(renameFields)]{if(auto page=weak.lock();page && page->current() && !page->busy)if(auto panel=fields.get())panel.Visibility(xaml::Visibility::Visible);}));
        body.Children().Append(actionMenu(L"More",management,L"Manage this conversation"));body.Children().Append(renameFields);
        auto rename = button(L"Rename", [weak = std::weak_ptr<Intelligence>(p), name] {
            if (auto page = weak.lock()) perform(page, [title = trim(name.Text())](Page page) -> IAsyncAction {
                require(!title.empty(), L"Enter a title.");
                auto id = page->shell->agentConversation; auto revision = page->revision;
                Json body; put(body, L"conversationId", id); put(body, L"title", title);
                auto result = co_await page->shell->service->request(L"/agent/rename", page->owner, L"POST", body);
                if (!page->current() || page->shell->agentConversation != id || page->revision != revision) co_return;
                agentReload(page, result, id);
                auto shell = page->shell; page->stop(); co_await intelligencePage(shell, L"agent");
            });
        });
        renameFields.Children().Append(rename);
    }
    if (state != L"awaiting" && state != L"running" && state != L"confirming") {
        auto compose = field(L"Message to Inbox Agent", {}, true);
        compose.MaxLength(4000); compose.MinHeight(96); body.Children().Append(compose);
        auto send = button(L"Ask assistant", [weak = std::weak_ptr<Intelligence>(p), compose] {
            if (auto page = weak.lock()) perform(page, [message = trim(compose.Text())](Page page) -> IAsyncAction {
                require(!message.empty(), L"Enter a message.");
                require(!page->shell->agentConversation.empty(), L"Start or open a conversation first.");
                Json body; put(body, L"conversationId", page->shell->agentConversation); put(body, L"text", message);
                co_await agentMutation(page, L"/agent/send", body);
            });
        });
        body.Children().Append(send);
    }
}
} // namespace

// Native smoke calls the production confirmation formatter with fictional data.
void inboxAgentReviewChecks() {
    hstring owner = L"agent-owner@fixture.invalid";
    auto preview = Json::Parse(LR"({"complete":true,"bodyTruncated":false,"fromEmail":"agent-owner@fixture.invalid","fromName":"Reviewed Sender","to":"to@fixture.invalid","cc":"cc@fixture.invalid","bcc":"hidden@fixture.invalid","subject":"Complete send review","body":"","attachments":[{"id":"attachment-one","name":"same-name.pdf","size":123,"contentType":"application/pdf"},{"id":"attachment-two","name":"same-name.pdf","size":456,"contentType":"application/pdf"}],"footer":{"text":"Company","html":"<a href=\"https://footer.fixture.invalid/destination\">Company</a>"}})");
    hstring body = hstring(std::wstring(100000, L'x')) + L"BODY-TAIL-CANARY";
    put(preview, L"body", body);
    std::wstring rendered(agentSendReviewText(preview, owner));
    require(rendered.find(std::wstring(body)) != std::wstring::npos, L"Inbox Agent truncated the full message review.");
    for (auto expected : {L"agent-owner@fixture.invalid", L"Reviewed Sender", L"to@fixture.invalid", L"cc@fixture.invalid", L"hidden@fixture.invalid", L"Complete send review", L"Attachments (2)", L"attachment-one", L"attachment-two", L"123 bytes", L"456 bytes", L"https://footer.fixture.invalid/destination"}) {
        require(rendered.find(expected) != std::wstring::npos, L"Inbox Agent omitted reviewed send content.");
    }
    auto rejects = [&](Json const& value) {
        bool rejected = false;
        try { (void)agentSendReviewText(value, owner); } catch (hresult_error const&) { rejected = true; }
        require(rejected, L"Incomplete Inbox Agent preview authorized delivery.");
    };
    for (auto key : {L"complete", L"bodyTruncated", L"fromEmail", L"body", L"attachments", L"footer"}) {
        auto invalid = clone(preview); invalid.Remove(key); rejects(invalid);
    }
    auto invalid = clone(preview); truth(invalid, L"complete", false); rejects(invalid);
    invalid = clone(preview); truth(invalid, L"bodyTruncated", true); rejects(invalid);
    invalid = clone(preview); put(invalid, L"fromEmail", L"other@fixture.invalid"); rejects(invalid);
    invalid = clone(preview); object(invalid, L"footer").Remove(L"html"); rejects(invalid);
    invalid = clone(preview); array(invalid, L"attachments").GetAt(0).GetObject().Insert(L"size", Value::CreateNumberValue(-1)); rejects(invalid);
    preview.Insert(L"attachments", JsonArray());
    auto footer = Json(); put(footer, L"text", L""); put(footer, L"html", L""); preview.Insert(L"footer", footer);
    require(std::wstring(agentSendReviewText(preview, owner)).find(L"Attachments (0)\nNone") != std::wstring::npos, L"An empty reviewed attachment list was rejected.");
}

IAsyncAction intelligencePage(std::shared_ptr<Shell> shell, hstring kind) {
    if (kind == L"tools" || kind == L"ai" || kind == L"summaries") kind = L"studio";
    if (kind == L"replies") kind = L"reply-suggestions";
    if (kind == L"local-activity") kind = L"records";
    auto scopeOwner = shell->review->scope;
    if (scopeOwner != L"all" && !shell->connected(scopeOwner)) { scopeOwner = L"all"; shell->review->scope = L"all"; }
    auto p = std::make_shared<Intelligence>(); p->shell = shell; p->owner = scopeOwner; p->kind = kind; p->generation = ++shell->generation;
    shell->section = kind;
    bool agentShell = kind == L"agent" || kind == L"skills";
    bool brainShell = kind == L"brain" || kind == L"categories" || kind == L"learning";
    auto root = stack(16); root.MaxWidth(1080); root.HorizontalAlignment(xaml::HorizontalAlignment::Left); root.Margin(xaml::Thickness{24, 20, 24, 32});
    words(root, agentShell ? L"Agent" : brainShell ? L"Brain" : L"AI Studio", 28);
    words(root, agentShell ? L"Inbox Agent, Today, and reusable skills. Sending still waits for your review."
        : brainShell ? L"Persona, writing rules, and mail categories for one mailbox."
        : L"Advanced AI tools and explicitly labeled local simulations. Choose a tool and review its scope before running it.");
    auto accountTabs = stack(7); accountTabs.Orientation(Orientation::Horizontal);
    std::vector<hstring> owners{L"all"};
    for (auto const& entry : array(shell->state, L"accounts")) owners.push_back(text(entry.GetObject(), L"id"));
    std::weak_ptr<Intelligence> scope = p;
    for (auto const& owner : owners) {
        controls::Primitives::ToggleButton tab; tab.Content(box_value(owner == L"all" ? hstring(L"All accounts") : owner)); tab.IsChecked(owner == p->owner); tab.IsTabStop(owner == p->owner);
        xaml::Automation::AutomationProperties::SetAutomationId(tab, L"studio.scope." + owner);
        xaml::Automation::AutomationProperties::SetName(tab, (agentShell ? L"Agent mailbox: " : brainShell ? L"Brain mailbox: " : L"Studio mailbox: ") + owner);
        tab.Checked([scope, owner](auto const&, auto const&) -> fire_and_forget {
            auto page = scope.lock();
            if (!page || !page->current() || page->shell->review->writing || page->owner == owner) co_return;
            if (page->edited() && !(co_await page->shell->confirm(L"Discard unsaved edits?", L"Only explicitly saved settings, styles and workspace notes take effect.", L"Discard"))) co_return;
            if (!page->current()) co_return;
            auto shell = page->shell; auto next = page->kind; page->stop(); shell->review->scope = owner; co_await intelligencePage(shell, next);
        });
        tab.Unchecked([scope, owner](auto const& sender, auto const&) { if (auto page = scope.lock(); page && page->current() && page->owner == owner) sender.template as<controls::Primitives::ToggleButton>().IsChecked(true); });
        accountTabs.Children().Append(tab);
    }
    ScrollViewer accountScroll; accountScroll.HorizontalScrollBarVisibility(ScrollBarVisibility::Auto); accountScroll.VerticalScrollBarVisibility(ScrollBarVisibility::Disabled); accountScroll.Content(accountTabs); root.Children().Append(accountScroll);
    bool accountPage = kind == L"brain" || kind == L"learning" || kind == L"skills" || kind == L"categories" || kind == L"rules" || kind == L"records" || kind == L"agent";
    auto tabs = stack(6); tabs.Orientation(Orientation::Horizontal); std::weak_ptr<Intelligence> weak = p;
    bool known = agentShell || brainShell || kind == L"studio" || kind == L"rules" || kind == L"simulations" || kind == L"records";
    auto shellTab = [&](hstring id, hstring caption, bool selected) {
        auto control = button(caption, [weak, id] {
            if (auto page = weak.lock()) {
                if (!page->current() || page->kind == id) return;
                changePage(page, id);
            }
        });
        control.IsEnabled(!selected);
        xaml::Automation::AutomationProperties::SetAutomationId(control, L"shell.section." + id);
        xaml::Automation::AutomationProperties::SetName(control, selected ? caption + L", selected" : caption);
        tabs.Children().Append(control);
    };
    if (agentShell) {
        shellTab(L"agent", L"Inbox Agent", kind == L"agent");
        shellTab(L"today", L"Today", false);
        shellTab(L"skills", L"Skills", kind == L"skills");
    } else if (brainShell) {
        shellTab(L"brain", L"Persona & writing rules", kind == L"brain");
        shellTab(L"categories", L"Categories", kind == L"categories");
    } else {
    for (auto const& [id, caption] : std::initializer_list<std::pair<wchar_t const*, wchar_t const*>>{
        {L"studio", L"Assistant"}}) {
        auto control = button(caption, [weak, target = hstring(id)] { if (auto page = weak.lock()) changePage(page, target); });
        if (kind == id) { known = true; control.IsEnabled(false); } tabs.Children().Append(control);
    }
    ComboBox more; more.PlaceholderText(L"More");
    xaml::Automation::AutomationProperties::SetName(more, L"More AI Studio pages");
    for (auto const& [id, caption] : std::initializer_list<std::pair<wchar_t const*, wchar_t const*>>{
        {L"brain", L"Writing style & notes"}, {L"agent", L"Inbox Agent"}, {L"reply-suggestions", L"Reply suggestions"}, {L"rules",L"Local Inbox Rules"}, {L"skills", L"Reusable skills"}, {L"categories", L"Mail categories"}, {L"simulations", L"Local simulations"}, {L"records", L"Simulation history"}}) {
        ComboBoxItem item; item.Content(box_value(caption)); item.Tag(box_value(hstring(id))); more.Items().Append(item);
        if (kind == id) { known = true; more.SelectedItem(item); }
    }
    more.SelectionChanged([weak](auto const& sender, auto const&) { if (auto page = weak.lock(); page && page->current()) {
        auto item = sender.template as<ComboBox>().SelectedItem().template try_as<ComboBoxItem>();
        if (item) changePage(page, unbox_value<hstring>(item.Tag()));
    } }); tabs.Children().Append(more);
    }
    ScrollViewer tabScroll; tabScroll.HorizontalScrollBarVisibility(ScrollBarVisibility::Auto); tabScroll.VerticalScrollBarVisibility(ScrollBarVisibility::Disabled); tabScroll.Content(tabs); root.Children().Append(tabScroll);
    xaml::Automation::AutomationProperties::SetAutomationId(tabScroll,L"intelligence.navigation");
    auto updateTabs=[weak,control=make_weak(tabScroll),redundant=agentShell||brainShell] {if(auto page=weak.lock();page && page->current())if(auto view=control.get())view.Visibility(redundant && page->shell->navigation.IsPaneOpen() && page->shell->navigation.DisplayMode()==NavigationViewDisplayMode::Expanded ? xaml::Visibility::Collapsed : xaml::Visibility::Visible);};
    updateTabs();
    auto paneToken=shell->navigation.RegisterPropertyChangedCallback(NavigationView::IsPaneOpenProperty(),[updateTabs](auto const&,auto const&){updateTabs();});
    auto displayToken=shell->navigation.DisplayModeChanged([updateTabs](auto const&,auto const&){updateTabs();});
    root.Unloaded([weak,paneToken,displayToken](auto const&,auto const&){if(auto page=weak.lock()){page->shell->navigation.UnregisterPropertyChangedCallback(NavigationView::IsPaneOpenProperty(),paneToken);page->shell->navigation.DisplayModeChanged(displayToken);}});
    auto notice = label(L"Loading this account’s saved context…"); root.Children().Append(notice); p->notice = notice;
    xaml::Automation::AutomationProperties::SetAutomationId(notice, L"intelligence.notice");
    xaml::Automation::AutomationProperties::SetLiveSetting(notice, xaml::Automation::Peers::AutomationLiveSetting::Polite);
    if (kind == L"learning" || kind == L"brain") {
        auto cancel = button(L"Cancel current style analysis…", [weak] { if (auto page = weak.lock(); page && page->generatingStyle) revokeStyle(page); });
        cancel.IsEnabled(false); root.Children().Append(cancel); p->cancelStyle = make_weak(cancel);
    }
    ContentControl host; host.HorizontalContentAlignment(xaml::HorizontalAlignment::Stretch);
    auto body = stack(16); host.Content(body); root.Children().Append(host); p->body = make_weak(body); p->editorHost = make_weak(host);
    root.Unloaded([p](auto const&, auto const&) { p->stop(); p->notice = nullptr; }); shell->show(scroll(root));
    if ((p->owner == L"all" && accountPage) || (p->owner != L"all" && !shell->connected(p->owner))) {
        p->tell(p->owner == L"all" ? (kind == L"agent" ? L"Choose one mailbox tab. Inbox Agent keeps a separate conversation for each mailbox." : L"Choose one mailbox tab for writing style, skills, rules and simulation history. Assistant can still use a selected message while All accounts is selected.") : L"Choose one connected mailbox above.");
        co_return;
    }
    bool loaded = false;
    try {
        require(known, L"Unknown Intelligence page.");
        auto state = co_await shell->service->request(L"/state", p->owner);
        if (!p->current()) co_return; acceptState(p, state);
        if (kind == L"learning") buildLearning(p, body);
        else if (kind == L"brain") buildBrain(p, body);
        else if (kind == L"rules") buildRules(p,body);
        else if (kind == L"skills") buildSkills(p, body);
        else if (kind == L"categories") buildCategories(p, body);
        else if (kind == L"reply-suggestions") {
            auto result = co_await shell->service->request(L"/reply-suggestions", p->owner);
            if (!p->current()) co_return; require(text(result, L"owner") == p->owner, L"Suggestion mailbox changed.");
            p->suggestions = result; buildSuggestions(p, body);
        } else if (kind == L"studio" || kind == L"simulations") {
            buildTools(p, body); co_await loadMessages(p); if (!p->current()) co_return;
            p->forms[L"tool"].accept(p->forms[L"tool"].value);
        } else if (kind == L"agent") {
            // Stop stays outside the editor host so it remains clickable while Send disables that host.
            auto stop = button(L"Stop", [weak] { if (auto page = weak.lock()) agentStop(page); });
            stop.IsEnabled(!p->shell->agentConversation.empty());
            root.Children().Append(stop);
            co_await buildAgent(p, body); if (!p->current()) co_return;
        } else {
            auto list = stack(12); body.Children().Append(list); p->recordList = make_weak(list); renderRecords(p);
        }
        loaded = true; p->tell(L"Ready. Opening this page has not started an AI or provider request."); p->dirty();
    } catch (hresult_error const& error) { p->tell(error.message()); }
    catch (...) { p->tell(L"This page could not load. Refresh to retry without starting AI."); }
    if (!p->current()) co_return;
    action(p, body, loaded ? L"Refresh saved context…" : L"Retry loading this page", [](Page page) -> IAsyncAction {
        if (page->edited() && !(co_await page->shell->confirm(L"Discard edits and refresh?", L"Saved data and background jobs remain. Unsaved fields, previews displayed here and output will be cleared.", L"Refresh"))) co_return;
        if (!page->current()) co_return;
        page->shell->dirty.erase(page->key()); auto shell = page->shell; auto kind = page->kind; page->stop(); co_await intelligencePage(shell, kind);
    });
    if (loaded && (kind == L"learning" || kind == L"reply-suggestions" || kind == L"studio" || kind == L"simulations" || kind == L"brain")) {
        p->timer = xaml::DispatcherTimer(); p->timer.Interval(std::chrono::seconds(3));
        p->timer.Tick([weak](auto const&, auto const&) { if (auto page = weak.lock()) refreshIntelligence(page); }); p->timer.Start();
    }
    if (loaded && kind == L"agent") {
        p->timer = xaml::DispatcherTimer(); p->timer.Interval(std::chrono::seconds(2));
        p->timer.Tick([weak](auto const&, auto const&) { if (auto page = weak.lock()) refreshAgent(page); }); p->timer.Start();
    }
}
} // namespace morrow
