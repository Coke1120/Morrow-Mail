#include "pch.h"
#include "Ui.h"
#include <winrt/Microsoft.UI.Xaml.Automation.Peers.h>
#include <winrt/Microsoft.UI.Xaml.Automation.Provider.h>
#include <winrt/Microsoft.UI.Xaml.Input.h>
#include <winrt/Windows.ApplicationModel.DataTransfer.h>
#include <winrt/Microsoft.UI.Xaml.Media.Imaging.h>
#include <winrt/Windows.Graphics.Imaging.h>
#include <winrt/Windows.Storage.h>
#include <winrt/Windows.Storage.Streams.h>
#include <fstream>
#include <cstdio>
#include <cmath>
#include <set>

namespace morrow {
using namespace winrt;
using namespace Windows::Foundation;
using namespace Windows::Data::Json;
IAsyncAction nativeInteractionChecks(std::shared_ptr<Shell> shell);
IAsyncAction settingsNavigationChecks(std::shared_ptr<Shell> shell);
IAsyncAction composerReturnChecks(std::shared_ptr<Shell> shell);
IAsyncAction summaryActivityChecks(std::shared_ptr<Shell> shell);
// Operate the mounted native flyout and its AutomationPeer; source labels alone
// do not establish that a hidden command can actually be reached.
IAsyncAction openActionFlyout(controls::DropDownButton target) {
    apartment_context ui; auto flyout=target.Flyout(); auto opened=std::make_shared<bool>(false);
    auto token=flyout.Opened(auto_revoke,[opened](auto const&,auto const&){*opened=true;});
    auto deadline=GetTickCount64()+5000;target.StartBringIntoView();target.UpdateLayout();
    while((!target.IsLoaded() || !target.ActualWidth() || !target.ActualHeight()) && GetTickCount64()<deadline) {
        co_await resume_after(std::chrono::milliseconds(10));co_await ui;target.UpdateLayout();
    }
    if(!target.IsLoaded() || !target.ActualWidth() || !target.ActualHeight() || !target.XamlRoot())throw hresult_error(E_FAIL,L"The action menu target did not become a mounted native control.");
    if(!target.Focus(xaml::FocusState::Keyboard))throw hresult_error(E_FAIL,L"The named action menu cannot receive keyboard focus.");
    flyout.ShowAt(target);
    while(!*opened && GetTickCount64()<deadline){co_await resume_after(std::chrono::milliseconds(10));co_await ui;}
    if(!*opened || !flyout.IsOpen())throw hresult_error(E_FAIL,L"The native action flyout did not open.");
}
IAsyncAction closeActionFlyout(controls::DropDownButton target) {
    apartment_context ui;auto flyout=target.Flyout();if(!flyout.IsOpen())co_return;
    auto closed=std::make_shared<bool>(false);auto event=flyout.Closed(auto_revoke,[closed](auto const&,auto const&){*closed=true;});
    auto deadline=GetTickCount64()+5000;flyout.Hide();
    while(!*closed && GetTickCount64()<deadline){co_await resume_after(std::chrono::milliseconds(10));co_await ui;}
    if(!*closed || flyout.IsOpen())throw hresult_error(E_FAIL,L"The native action flyout did not close.");
}
void invokeNativeAction(xaml::FrameworkElement const& control) {
    auto peer=xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(control);
    peer.GetPattern(xaml::Automation::Peers::PatternInterface::Invoke).as<xaml::Automation::Provider::IInvokeProvider>().Invoke();
}
IAsyncAction invokeFlyoutAction(controls::DropDownButton target,controls::MenuFlyoutItem item) {
    apartment_context ui;auto flyout=target.Flyout();auto closed=std::make_shared<bool>(false);
    auto event=flyout.Closed(auto_revoke,[closed](auto const&,auto const&){*closed=true;});
    auto deadline=GetTickCount64()+5000;invokeNativeAction(item);
    while(!*closed && GetTickCount64()<deadline){co_await resume_after(std::chrono::milliseconds(10));co_await ui;}
    if(!*closed || flyout.IsOpen())throw hresult_error(E_FAIL,L"The invoked native action did not close its flyout.");
}
IAsyncAction returnedMailActionsChecks(std::shared_ptr<Shell> shell) {
    auto check=[](bool value,wchar_t const* message){if(!value)throw hresult_error(E_FAIL,message);};
    check(std::wstring_view(GetCommandLineW()).find(L"--native-smoke")!=std::wstring_view::npos && shell->section==L"mail" && !shell->loading,L"Returned-mail checks require the owned native fixture.");
    auto selected=std::vector<IInspectable>();for(auto const& value:shell->rows.SelectedItems())selected.push_back(value);
    struct Restore {std::shared_ptr<Shell> shell;std::vector<IInspectable> selected;bool focused;uint64_t generation;hstring owner;~Restore(){shell->generation=generation;shell->owner=owner;shell->readerFocused=focused;shell->loading=true;shell->rows.SelectedItems().Clear();for(auto const& row:selected)shell->rows.SelectedItems().Append(row);shell->loading=false;shell->updateMailSelectionActions();shell->applyMailLayout();}} restore{shell,selected,shell->readerFocused,shell->generation,shell->owner};
    shell->readerFocused=false;shell->applyMailLayout();shell->loading=true;shell->rows.SelectedItems().Clear();shell->rows.SelectedItems().Append(shell->rows.Items().GetAt(0));shell->loading=false;shell->updateMailSelectionActions();shell->root.UpdateLayout();
    auto menu=shell->mailSelectionActions.Children().GetAt(1).as<controls::StackPanel>().Children().GetAt(0).as<controls::DropDownButton>();
    co_await openActionFlyout(menu);controls::MenuFlyoutItem mark{nullptr};
    for(auto const& item:menu.Flyout().as<controls::MenuFlyout>().Items())if(auto candidate=item.try_as<controls::MenuFlyoutItem>();candidate && candidate.Text()==L"Mark read")mark=candidate;
    check(mark && mark.IsEnabled(),L"Restoring the composer left the retained Actions menu empty or disabled.");
    auto request=shell->readGeneration;auto before=shell->selected.Stringify();
    ++shell->generation;shell->owner=L"two@fixture.invalid";co_await invokeFlyoutAction(menu,mark);
    check(shell->readGeneration==request && shell->selected.Stringify()==before && !shell->navigationLocked,L"A retained selection action survived its captured page and mailbox revocation.");
}
IAsyncAction contextualMailChecks(std::shared_ptr<Shell> shell) {
    auto check=[](bool value,wchar_t const* why){if(!value)throw hresult_error(E_FAIL,why);};
    check(std::wstring_view(GetCommandLineW()).find(L"--native-smoke")!=std::wstring_view::npos && shell->rows.Items().Size()>1 && !shell->loading && !shell->dialogOpen && !shell->closing && shell->dirty.empty(),L"Contextual actions require the idle owned native fixture.");
    struct RestoreLayout {std::shared_ptr<Shell> shell;hstring layout;bool focused;~RestoreLayout(){shell->mailLayout=layout;shell->readerFocused=focused;shell->applyMailLayout();}} restoreLayout{shell,shell->mailLayout,shell->readerFocused};
    shell->mailLayout=L"right";shell->readerFocused=false;shell->applyMailLayout();shell->root.UpdateLayout();
    auto mountedReader=shell->reader.Content();auto refreshRequest=shell->readGeneration;
    co_await shell->refreshMailReader();
    check(shell->reader.Content()==mountedReader && shell->readGeneration>refreshRequest,L"The unchanged-message refresh control did not retain the mounted reader.");
    std::function<xaml::FrameworkElement(xaml::DependencyObject,hstring const&)> find;
    find=[&find](xaml::DependencyObject node,hstring const& id)->xaml::FrameworkElement {
        if(auto view=node.try_as<xaml::FrameworkElement>();view && xaml::Automation::AutomationProperties::GetAutomationId(view)==id)return view;
        for(int i=0;i<xaml::Media::VisualTreeHelper::GetChildrenCount(node);++i)if(auto value=find(xaml::Media::VisualTreeHelper::GetChild(node,i),id))return value;
        return nullptr;
    };
    auto savedSelection=std::vector<IInspectable>();for(auto const& row:shell->rows.SelectedItems())savedSelection.push_back(row);
    auto setCount=[&](unsigned count){shell->loading=true;shell->rows.SelectedItems().Clear();for(unsigned i=0;i<count;++i)shell->rows.SelectedItems().Append(shell->rows.Items().GetAt(i));shell->loading=false;shell->updateMailSelectionActions();shell->root.UpdateLayout();};
    setCount(0);check(shell->mailSelectionActions.Visibility()==xaml::Visibility::Collapsed,L"Empty selection exposes mutation controls.");
    for(unsigned count:{1u,2u}) {
        setCount(count);check(shell->mailSelectionActions.Visibility()==xaml::Visibility::Visible && shell->mailSelectionCount.Text()==to_hstring(count)+L" selected",L"The action bar does not follow native selection.");
        auto menu=find(shell->root,L"mail.selection.menu").as<controls::DropDownButton>();co_await openActionFlyout(menu);
        unsigned marks=0;bool replyAll=false;for(auto const& entry:menu.Flyout().as<controls::MenuFlyout>().Items())if(auto item=entry.try_as<controls::MenuFlyoutItem>()) {
            if(item.Text()==L"Mark read" || item.Text()==L"Mark unread" || item.Text()==L"Mark Pending")++marks;
            if(item.Text()==L"Reply all")replyAll=item.IsEnabled();
        }
        check(marks==3 && (count!=1 || replyAll),L"Selected message commands or the single-message Reply all action are not reachable in the opened native menu.");co_await closeActionFlyout(menu);
        check(menu==shell->selectionMenu && menu.IsEnabled(),L"The stored selection Actions control is not the enabled mounted button.");
        auto messages=shell->selectedMessages();
        bool canDelete=!messages.empty() && std::all_of(messages.begin(),messages.end(),[&](auto const& row){return shell->canTrash(row);});
        check(shell->selectionDelete.IsEnabled()==canDelete,L"The mounted Delete control lost its selected-message Trash eligibility.");
        {
            // Do not suspend while injecting fixture gates; always restore them on failure.
            struct RestoreGates {
                std::shared_ptr<Shell> shell; bool loading,dialogOpen,closing; std::set<std::wstring> dirty;
                ~RestoreGates() {
                    shell->loading=loading;shell->dialogOpen=dialogOpen;shell->closing=closing;shell->dirty=std::move(dirty);
                    try { shell->updateMailSelectionActions(); } catch (...) {}
                }
            } restore{shell,shell->loading,shell->dialogOpen,shell->closing,shell->dirty};
            for(auto gate:{&Shell::loading,&Shell::dialogOpen,&Shell::closing}) {
                (shell.get()->*gate)=true;shell->updateMailSelectionActions();
                check(!menu.IsEnabled() && !shell->selectionDelete.IsEnabled(),L"A busy, modal or closing selection kept an action control enabled.");
                (shell.get()->*gate)=false;shell->updateMailSelectionActions();
                check(menu.IsEnabled() && shell->selectionDelete.IsEnabled()==canDelete,L"Clearing a selection gate did not restore the eligible controls.");
            }
            shell->dirty.insert(L"contextual-selection-gate-fixture");shell->updateMailSelectionActions();
            check(!menu.IsEnabled() && !shell->selectionDelete.IsEnabled(),L"Unsaved edits kept a selection action enabled.");
        }
        check(menu.IsEnabled() && shell->selectionDelete.IsEnabled()==canDelete,L"Restoring the fixture gates did not restore the eligible selection controls.");
    }
    shell->loading=true;shell->rows.SelectedItems().Clear();for(auto const& row:savedSelection)shell->rows.SelectedItems().Append(row);shell->loading=false;shell->updateMailSelectionActions();
    auto view=find(shell->root,L"mail.view").as<controls::DropDownButton>();co_await openActionFlyout(view);
    check(shell->sorting.IsLoaded() && shell->sorting.Items().Size()==6 && shell->sorting.IsEnabled(),L"View no longer exposes the actual six-way native sort control.");co_await closeActionFlyout(view);
    {
        auto input=shell->search;auto query=input.Text();auto mountedPage=shell->page.Content();
        auto owner=shell->owner;auto generation=shell->generation;auto submittedQuery=shell->mailSearchQuery;
        auto clear=find(shell->root,L"mail.search.clear");check(bool(clear),L"The mounted Clear control is missing.");
        struct RestoreQuery {
            controls::TextBox input;hstring query;bool completed=false;
            ~RestoreQuery(){if(!completed)try{if(input.Text()!=query)input.Text(query);}catch(...) {}}
        } restore{input,query};
        auto current=[&] {
            return shell->section==L"mail" && shell->owner==owner && shell->generation==generation &&
                shell->page.Content()==mountedPage && shell->search==input &&
                find(shell->root,L"mail.search.clear")==clear && input.XamlRoot() && clear.XamlRoot()==input.XamlRoot();
        };
        auto mounted=[&] {return input.IsLoaded() && input.IsEnabled() && input.ActualWidth()>0 && input.ActualHeight()>0;};
        // Keep this coroutine lambda alive until every awaited edit has finished.
        // TextChanged is asynchronous; layout alone does not acknowledge an edit.
        auto edit=[&](hstring value,xaml::Visibility expected,wchar_t const* message)->IAsyncAction {
            apartment_context ui;shell->root.UpdateLayout();
            check(current() && mounted(),L"The captured mail search input is not the current mounted enabled control.");
            auto changed=std::make_shared<bool>(false);bool requiresEvent=input.Text()!=value;
            auto event=input.TextChanged(auto_revoke,[changed,input,value](auto const& sender,auto const&) {
                if(sender.template as<controls::TextBox>()==input && input.Text()==value)*changed=true;
            });
            auto deadline=GetTickCount64()+5000;
            if(requiresEvent)input.Text(value); // Exactly one setter; a no-op has no required change event.
            while(current() && mounted() && ((requiresEvent && !*changed) || clear.Visibility()!=expected) && GetTickCount64()<deadline) {
                co_await resume_after(std::chrono::milliseconds(10));co_await ui;shell->root.UpdateLayout();
            }
            auto same=current();auto ready=mounted();auto textMatches=input.Text()==value;auto queryUnchanged=shell->mailSearchQuery==submittedQuery;
            auto details=L" [sameControl="+to_hstring(same)+L", mounted="+to_hstring(ready)+
                L", eventRequired="+to_hstring(requiresEvent)+L", matchingEvent="+to_hstring(*changed)+
                L", textMatches="+to_hstring(textMatches)+L", clearVisible="+to_hstring(clear.Visibility()==xaml::Visibility::Visible)+
                L", queryUnchanged="+to_hstring(queryUnchanged)+L"]";
            check(same && ready,(L"The search edit lost its captured page, mailbox or mounted controls."+details).c_str());
            check(!requiresEvent || *changed,(L"The search edit did not reach its matching native TextChanged event."+details).c_str());
            check(textMatches,(L"The captured search text changed before its event settled."+details).c_str());
            check(clear.Visibility()==expected,(hstring(message)+details).c_str());
            check(queryUnchanged,(L"Editing search text submitted a query without a native search action."+details).c_str());
        };
        co_await edit(L"",xaml::Visibility::Collapsed,L"An empty query retains Clear in the tab order.");
        co_await edit(L"fictional unsent search",xaml::Visibility::Visible,L"A query cannot reach Clear.");
        co_await edit(query,query.empty()?xaml::Visibility::Collapsed:xaml::Visibility::Visible,L"Restoring search text left Clear in the wrong state.");
        restore.completed=true;
        std::fprintf(stderr,"Native smoke: search-clear-event-settlement-passed\n");std::fflush(stderr);
    }
    for(auto id:{L"reader.reply",L"reader.more",L"reader.ai"}) {
        auto target=find(shell->root,id).as<controls::DropDownButton>();co_await openActionFlyout(target);
        auto menu=target.Flyout().as<controls::MenuFlyout>();check(menu.Items().Size()>0,L"A named reader action menu is empty.");
        if(std::wstring_view(id)==L"reader.reply") {
            check(menu.Items().Size()==3 && menu.Items().GetAt(0).as<controls::MenuFlyoutItem>().Text()==L"Reply" && menu.Items().GetAt(1).as<controls::MenuFlyoutItem>().Text()==L"Reply all" && menu.Items().GetAt(2).as<controls::MenuFlyoutItem>().Text()==L"Forward",L"Reply variants are not discoverable in the same native menu.");
        }
        if(std::wstring_view(id)==L"reader.more") {
            bool local=false;for(auto const& item:menu.Items())if(auto sub=item.try_as<controls::MenuFlyoutSubItem>();sub && sub.Text()==L"On this device only")local=sub.Items().Size()>0;
            check(local,L"Local organization lost its effect disclosure.");
            auto focused=shell->readerFocused;co_await invokeFlyoutAction(target,menu.Items().GetAt(menu.Items().Size()-1).as<controls::MenuFlyoutItem>());
            check(shell->readerFocused!=focused,L"An unchanged background read disabled the mounted reader menu.");
            shell->readerFocused=focused;shell->applyMailLayout();co_await openActionFlyout(target);
            auto oldSelection=shell->selectionGeneration;auto oldRead=shell->readGeneration;auto before=shell->selected.Stringify();
            ++shell->selectionGeneration;co_await invokeFlyoutAction(target,menu.Items().GetAt(0).as<controls::MenuFlyoutItem>());
            check(shell->readGeneration==oldRead && shell->selected.Stringify()==before && !shell->navigationLocked,L"An obsolete open reader menu executed a metadata write.");shell->selectionGeneration=oldSelection;
        }
        co_await closeActionFlyout(target);
    }
}
IAsyncAction writingRuleEditingChecks(std::shared_ptr<Shell> shell) {
    auto check = [](bool condition, wchar_t const* message) { if (!condition) throw hresult_error(E_FAIL, message); };
    auto previousScope = shell->review->scope;
    hstring owner = L"one@fixture.invalid";
    std::vector<hstring> ids;
    for (auto value : {L"Fixture original rule A", L"Fixture original rule B"}) {
        Json input; put(input, L"text", value);
        auto result = co_await shell->service->request(L"/workspace/brain/writing-rules", owner, L"POST", input);
        for (auto const& item : array(object(object(result, L"workspace"), L"brain"), L"writingRules")) {
            auto rule = item.GetObject(); if (text(rule, L"text") == value) ids.push_back(text(rule, L"id"));
        }
    }
    check(ids.size() == 2, L"Writing-rule fixture setup failed.");
    shell->review->scope = owner; co_await shell->navigate(L"brain"); shell->root.UpdateLayout();
    auto mountedPage = shell->page.Content(); auto generation = shell->generation;
    std::function<xaml::FrameworkElement(xaml::DependencyObject, hstring const&)> find;
    find = [&find](xaml::DependencyObject node, hstring const& id) -> xaml::FrameworkElement {
        if (auto control = node.try_as<xaml::FrameworkElement>(); control && xaml::Automation::AutomationProperties::GetAutomationId(control) == id) return control;
        for (int i = 0; i < xaml::Media::VisualTreeHelper::GetChildrenCount(node); ++i) {
            if (auto found = find(xaml::Media::VisualTreeHelper::GetChild(node, i), id)) return found;
        }
        return nullptr;
    };
    auto control = [&](hstring const& id) { shell->root.UpdateLayout(); auto found = find(shell->root, id); check(bool(found), L"Writing-rule native control is missing."); return found; };
    auto field = [&](hstring const& id) { return control(L"writing-rule.text." + id).as<controls::TextBox>(); };
    auto invoke = [&](hstring const& id) {
        auto peer = xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(control(id));
        auto action = peer.GetPattern(xaml::Automation::Peers::PatternInterface::Invoke).as<xaml::Automation::Provider::IInvokeProvider>();
        action.Invoke();
    };
    // These coroutine lambdas remain local variables until all invocations finish.
    auto wait = [](std::function<bool()> ready) -> IAsyncAction {
        apartment_context ui; auto deadline = GetTickCount64() + 5000;
        while (!ready() && GetTickCount64() < deadline) { co_await resume_after(std::chrono::milliseconds(10)); co_await ui; }
        if (!ready()) throw hresult_error(E_FAIL, L"Writing-rule native operation did not finish.");
    };
    auto edit = [&wait](controls::TextBox box, hstring value) -> IAsyncAction {
        auto changed = std::make_shared<bool>(false);
        auto event = box.TextChanged(auto_revoke, [changed](auto const&, auto const&) { *changed = true; });
        box.Text(value); co_await wait([changed] { return *changed; });
    };
    for(auto const& id:ids) {
        auto more=control(L"writing-rule.more."+id).as<controls::DropDownButton>();
        co_await openActionFlyout(more);
        auto editRule=more.Flyout().as<controls::MenuFlyout>().Items().GetAt(0).as<controls::MenuFlyoutItem>();
        check(xaml::Automation::AutomationProperties::GetAutomationId(editRule)==L"writing-rule.edit."+id,L"The writing-rule menu points at another row.");
        co_await invokeFlyoutAction(more,editRule);
        co_await wait([&]{return bool(find(shell->root,L"writing-rule.text."+id));});
    }
    co_await edit(field(ids[0]), L"Fixture unsaved A");
    co_await edit(field(ids[1]), L"Fixture saved B");
    auto newRule = control(L"writing-rule.new").as<controls::TextBox>();
    co_await edit(newRule, L"Fixture new rule buffer");
    check(!shell->dirty.empty(), L"Rule buffers did not join navigation and quit guards.");
    auto retained = [&] {
        check(shell->page.Content() == mountedPage && shell->generation == generation, L"Rule mutation rebuilt the entire page.");
        check(field(ids[0]).Text() == L"Fixture unsaved A" && newRule.Text() == L"Fixture new rule buffer" && !shell->dirty.empty(), L"Unrelated rule/new-rule buffers or dirty guards were lost.");
    };
    auto oldB = field(ids[1]);
    auto enabled = control(L"writing-rule.enabled." + ids[1]).as<controls::CheckBox>();
    auto peer = xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(enabled);
    peer.GetPattern(xaml::Automation::Peers::PatternInterface::Toggle).as<xaml::Automation::Provider::IToggleProvider>().Toggle();
    co_await wait([&] { return field(ids[1]) != oldB; }); retained();
    check(field(ids[1]).Text() == L"Fixture saved B", L"Toggling a rule discarded its own unsaved text.");
    oldB = field(ids[1]); invoke(L"writing-rule.save." + ids[1]);
    co_await wait([&] { return field(ids[1]) != oldB; }); retained();
    auto state = co_await shell->service->request(L"/state", owner);
    for (auto const& item : array(object(object(state, L"workspace"), L"brain"), L"writingRules")) {
        auto rule = item.GetObject();
        if (text(rule, L"id") == ids[0]) check(text(rule, L"text") == L"Fixture original rule A", L"An unrelated save persisted unsaved rule A.");
        if (text(rule, L"id") == ids[1]) check(text(rule, L"text") == L"Fixture saved B" && !flag(rule, L"enabled"), L"The intended rule update was not persisted.");
    }
    co_await edit(field(ids[1]), L"Fixture original rule A"); // Duplicate text must fail without clearing either buffer.
    invoke(L"writing-rule.save." + ids[1]);
    co_await wait([&] { return std::wstring_view(control(L"intelligence.notice").as<controls::TextBlock>().Text()).find(L"already saved") != std::wstring_view::npos; });
    retained(); check(field(ids[1]).Text() == L"Fixture original rule A", L"A failed save cleared its rule input.");
    invoke(L"writing-rule.discard." + ids[1]);
    co_await wait([&] { return field(ids[1]).Text() == L"Fixture saved B"; }); retained();
    oldB = field(ids[1]); invoke(L"writing-rule.add");
    co_await wait([&] { return field(ids[1]) != oldB; });
    check(newRule.Text().empty() && field(ids[0]).Text() == L"Fixture unsaved A" && !shell->dirty.empty(), L"Adding a rule cleared another editor or left the new input dirty.");
    invoke(L"writing-rule.discard." + ids[0]); co_await wait([&] { return shell->dirty.empty(); });
    co_await edit(newRule, L"New input alone is dirty");
    check(!shell->dirty.empty(), L"New-rule-only edits do not guard navigation and quit.");
    invoke(L"writing-rule.discard-new"); co_await wait([&] { return shell->dirty.empty(); });
    // Clean only the rules created inside this marked temporary native fixture.
    state = co_await shell->service->request(L"/state", owner);
    for (auto const& item : array(object(object(state, L"workspace"), L"brain"), L"writingRules")) {
        auto rule = item.GetObject(); auto id = text(rule, L"id");
        if (id == ids[0] || id == ids[1] || text(rule, L"text") == L"Fixture new rule buffer")
            co_await shell->service->request(L"/workspace/brain/writing-rules/" + escaped(id), owner, L"DELETE", Json());
    }
    shell->review->scope = previousScope;
}
IAsyncAction categoryCreationChecks(std::shared_ptr<Shell> shell) {
    auto check=[](bool value,wchar_t const* message){if(!value)throw hresult_error(E_FAIL,message);};
    check(std::wstring_view(GetCommandLineW()).find(L"--native-smoke")!=std::wstring_view::npos && !shell->dialogOpen && shell->dirty.empty(),L"Category creation checks require the idle native fixture.");
    auto scope=shell->review->scope;hstring owner=L"one@fixture.invalid";
    Json input;put(input,L"name",L"Contextual fixture original");put(input,L"description",L"Retained saved category");put(input,L"priority",L"P2");input.Insert(L"enabled",Value::CreateBooleanValue(true));
    auto state=co_await shell->service->request(L"/workspace/categories",owner,L"POST",input);hstring originalId;Json original;
    for(auto const& value:array(object(state,L"workspace"),L"categories"))if(text(value.GetObject(),L"name")==L"Contextual fixture original"){original=value.GetObject();originalId=text(original,L"id");}
    check(!originalId.empty(),L"The fictional category setup did not return its identity.");
    shell->review->scope=owner;co_await shell->navigate(L"categories");shell->root.UpdateLayout();
    std::function<xaml::FrameworkElement(xaml::DependencyObject,hstring const&,bool)> find;
    find=[&find](xaml::DependencyObject node,hstring const& id,bool name)->xaml::FrameworkElement {
        if(!node)return nullptr;
        if(auto value=node.try_as<xaml::FrameworkElement>();value && (name ? value.Name()==id : xaml::Automation::AutomationProperties::GetAutomationId(value)==id))return value;
        for(int i=0;i<xaml::Media::VisualTreeHelper::GetChildrenCount(node);++i)if(auto result=find(xaml::Media::VisualTreeHelper::GetChild(node,i),id,name))return result;
        return nullptr;
    };
    auto wait=[](std::function<bool()> ready)->IAsyncAction {apartment_context ui;auto deadline=GetTickCount64()+5000;while(!ready() && GetTickCount64()<deadline){co_await resume_after(std::chrono::milliseconds(10));co_await ui;}if(!ready())throw hresult_error(E_FAIL,L"A native category control did not finish within its deadline.");};
    auto invoke=[shell,&wait](controls::Button control)->IAsyncAction {
        control.StartBringIntoView();shell->root.UpdateLayout();
        co_await wait([&]{shell->root.UpdateLayout();return control.IsLoaded() && control.IsEnabled() && control.ActualWidth()>0 && control.ActualHeight()>0;});
        if(!control.Focus(xaml::FocusState::Keyboard))throw hresult_error(E_FAIL,L"The category action is not keyboard reachable.");
        invokeNativeAction(control);
    };
    auto more=find(shell->root,L"category.more."+originalId,false).as<controls::DropDownButton>();co_await openActionFlyout(more);
    co_await invokeFlyoutAction(more,more.Flyout().as<controls::MenuFlyout>().Items().GetAt(0).as<controls::MenuFlyoutItem>());
    co_await wait([&]{auto view=find(shell->root,L"category.name",false).try_as<controls::TextBox>();return view && view.Text()==L"Contextual fixture original" && shell->dirty.empty();});
    auto name=find(shell->root,L"category.name",false).as<controls::TextBox>();auto add=find(shell->root,L"category.add",false).as<controls::Button>();
    name.Text(L"Unsaved original category edit");co_await wait([&]{return !shell->dirty.empty();});
    // This coroutine lambda remains in this frame until both awaited dialog
    // responses complete. It operates the real ContentDialog template buttons.
    auto respond=[shell,&find,&wait,&invoke](bool accept)->IAsyncAction {
        std::function<controls::ContentDialog(xaml::DependencyObject)> findDialog;
        findDialog=[&findDialog](xaml::DependencyObject node)->controls::ContentDialog {
            if(!node)return nullptr;
            if(auto dialog=node.try_as<controls::ContentDialog>();dialog && unbox_value_or<hstring>(dialog.Title(),L"")==L"Discard unsaved category edits?")return dialog;
            for(int i=0;i<xaml::Media::VisualTreeHelper::GetChildrenCount(node);++i)if(auto value=findDialog(xaml::Media::VisualTreeHelper::GetChild(node,i)))return value;
            return nullptr;
        };
        controls::ContentDialog dialog{nullptr};
        co_await wait([&]{for(auto const& popup:xaml::Media::VisualTreeHelper::GetOpenPopupsForXamlRoot(shell->root.XamlRoot()))if(auto found=findDialog(popup.Child()))dialog=found;return dialog && dialog.IsLoaded();});
        controls::Button choice{nullptr};
        co_await wait([&]{choice=find(dialog,accept ? hstring(L"PrimaryButton") : hstring(L"CloseButton"),true).try_as<controls::Button>();return choice && choice.IsLoaded() && choice.IsEnabled();});
        co_await invoke(choice);co_await wait([&]{return !shell->dialogOpen;});
    };
    co_await invoke(add);co_await respond(false);
    // ShowAsync finishing clears dialogOpen before perform restores its editor.
    // Observe the mounted host's effective enabled state before another click.
    co_await wait([&]{return add.IsEnabled() && name.IsEnabled();});
    check(name.Text()==L"Unsaved original category edit" && !shell->dirty.empty(),L"Cancelling Add category discarded the old category buffer.");
    co_await invoke(add);co_await respond(true);co_await wait([&]{return add.IsEnabled() && name.IsEnabled() && name.Text().empty() && shell->dirty.empty();});
    name.Text(L"Contextual fixture new");co_await wait([&]{return !shell->dirty.empty();});
    co_await invoke(find(shell->root,L"category.save",false).as<controls::Button>());co_await wait([&]{return add.IsEnabled() && name.IsEnabled() && name.Text().empty() && shell->dirty.empty();});
    state=co_await shell->service->request(L"/state",owner);hstring newId;bool originalRetained=false;
    for(auto const& value:array(object(state,L"workspace"),L"categories")) {
        auto row=value.GetObject();if(text(row,L"id")==originalId)originalRetained=row.Stringify()==original.Stringify();
        if(text(row,L"name")==L"Contextual fixture new")newId=text(row,L"id");
    }
    check(originalRetained && !newId.empty() && newId!=originalId,L"Add category reused the edited category identity or changed its saved data.");
    for(auto const& id:{originalId,newId})co_await shell->service->request(L"/workspace/categories/"+escaped(id),owner,L"DELETE",Json());
    shell->review->scope=scope;
}
IAsyncAction captureMailList(std::shared_ptr<Shell> shell, hstring name) {
    xaml::Media::Imaging::RenderTargetBitmap bitmap;
    co_await bitmap.RenderAsync(shell->root);
    if (bitmap.PixelWidth() <= 0 || bitmap.PixelHeight() <= 0) throw hresult_error(E_FAIL, L"Mail list capture is empty.");
    auto pixels = co_await bitmap.GetPixelsAsync();
    std::vector<uint8_t> bytes(pixels.Length());
    Windows::Storage::Streams::DataReader::FromBuffer(pixels).ReadBytes(bytes);
    auto folder = co_await Windows::Storage::StorageFolder::GetFolderFromPathAsync(shell->service->directory().wstring());
    auto file = co_await folder.CreateFileAsync(name, Windows::Storage::CreationCollisionOption::ReplaceExisting);
    auto stream = co_await file.OpenAsync(Windows::Storage::FileAccessMode::ReadWrite);
    using namespace Windows::Graphics::Imaging;
    auto encoder = co_await BitmapEncoder::CreateAsync(BitmapEncoder::PngEncoderId(), stream);
    encoder.SetPixelData(BitmapPixelFormat::Bgra8, BitmapAlphaMode::Premultiplied, bitmap.PixelWidth(), bitmap.PixelHeight(), 96, 96, bytes);
    co_await encoder.FlushAsync();
}
void syncStatusChecks() {
    auto check = [](bool condition, wchar_t const* message) { if (!condition) throw hresult_error(E_FAIL, message); };
    Shell shell; shell.status = controls::TextBlock(); shell.owner = L"all";
    shell.state = Json::Parse(LR"({"accounts":[{"id":"one@example.invalid"},{"id":"two@example.invalid"}],"syncErrors":[{"accountId":"one@example.invalid","error":"Reconnect this account."},{"accountId":"two@example.invalid","error":"Provider request limit.","nextRetryAt":"2030-01-01T00:00:00.000Z"},{"accountId":"off@example.invalid","error":"Disconnected account."}]})");
    auto contains = [&](wchar_t const* value) { return std::wstring_view(shell.status.Text()).find(value) != std::wstring_view::npos; };
    shell.error(L"");
    check(contains(L"one@example.invalid") && contains(L"two@example.invalid") && contains(L"Next retry:") && !contains(L"off@example.invalid"), L"Combined sync failures, retry timing or disconnected-account filtering are missing.");
    shell.error(L""); // The same status reset is used by periodic workspace refresh.
    check(contains(L"Reconnect") && contains(L"Provider request limit"), L"Workspace refresh cleared unresolved sync failures.");
    shell.owner = L"one@example.invalid"; shell.error(L"");
    check(contains(L"one@example.invalid") && !contains(L"two@example.invalid"), L"Sync status crossed the selected mailbox.");
    shell.error(L"Draft save failed.");
    check(shell.status.Text() == L"Draft save failed.", L"Sync status hid the current operation's error.");
    shell.state.Insert(L"syncErrors", JsonArray()); shell.error(L"");
    check(shell.status.Text().empty(), L"Resolved sync failures remained visible.");
}
void mailDragChecks(std::shared_ptr<Service> const& service) {
    auto check = [](bool condition, wchar_t const* message) { if (!condition) throw hresult_error(E_FAIL, message); };
    auto shell = std::make_shared<Shell>(); shell->service = service; shell->owner = L"all"; shell->rows = controls::ListView();
    JsonArray accounts;
    for (auto owner : {L"drag@example.invalid", L"other@example.invalid"}) {
        Json account, connection; put(account, L"id", owner); put(account, L"provider", L"google"); put(connection, L"connection", L"original"); account.Insert(L"settings", connection); accounts.Append(account);
        Json folder, catalog; JsonArray folders; put(folder, L"id", L"label"); put(folder, L"name", L"Work / 中文"); put(folder, L"kind", L"label"); folders.Append(folder); catalog.Insert(L"folders", folders); shell->serverFolders.Insert(owner, catalog);
        Json message; put(message, L"id", L"google:duplicate"); put(message, L"viewId", hstring(owner) + L":duplicate"); put(message, L"accountId", owner);
        controls::ListViewItem row; row.Tag(message); shell->rows.Items().Append(row);
    }
    shell->state.Insert(L"accounts", accounts);
    auto source = shell->rows.Items().GetAt(0).as<controls::ListViewItem>().Tag().as<Json>();
    auto token = shell->startMailDrag(source);
    auto valid = [&] { return shell->mailDropMessage(token, L"drag@example.invalid", L"label").Size() != 0; };
    check(!token.empty() && valid(), L"An owned message in All accounts cannot be dragged to its label.");
    check(!shell->mailDropMessage(token, L"other@example.invalid", L"label").Size() && !shell->mailDropMessage(L"external", L"drag@example.invalid", L"label").Size()
        && !shell->mailDropMessage(token, L"drag@example.invalid", L"missing").Size(), L"External, cross-owner duplicate ID or missing destination accepted.");
    check(shell->mailDropDestination(L"all", L"archive").empty() && shell->mailDropDestination(L"drag@example.invalid", L"archive") == L"__archive", L"Combined or Gmail Archive drop destination is incorrect.");
    Windows::ApplicationModel::DataTransfer::DataPackage data;
    data.SetData(L"com.morrowmail.mail-row", box_value(token)); data.Properties().Insert(L"com.morrowmail.mail-row", box_value(token));
    check(data.GetView().Contains(L"com.morrowmail.mail-row") && unbox_value<hstring>(data.GetView().Properties().Lookup(L"com.morrowmail.mail-row")) == token,
        L"The native drag DataPackage lost its opaque token.");
    for (auto field : {L"loading", L"dialog", L"dirty", L"generation", L"owner", L"connection", L"disconnected", L"hidden", L"selectable", L"row"}) {
        auto savedState = Json::Parse(shell->state.Stringify()), savedFolders = Json::Parse(shell->serverFolders.Stringify());
        if (field == std::wstring_view(L"loading")) shell->loading = true;
        if (field == std::wstring_view(L"dialog")) shell->dialogOpen = true;
        if (field == std::wstring_view(L"dirty")) shell->dirty.insert(L"fixture");
        if (field == std::wstring_view(L"generation")) ++shell->generation;
        if (field == std::wstring_view(L"owner")) shell->owner = L"other@example.invalid";
        if (field == std::wstring_view(L"connection")) put(object(accounts.GetAt(0).GetObject(), L"settings"), L"connection", L"replacement");
        if (field == std::wstring_view(L"disconnected")) shell->state.Insert(L"accounts", JsonArray());
        if (field == std::wstring_view(L"hidden") || field == std::wstring_view(L"selectable")) {
            auto folder = array(object(shell->serverFolders, L"drag@example.invalid"), L"folders").GetAt(0).GetObject();
            folder.Insert(field, Value::CreateBooleanValue(field == std::wstring_view(L"hidden")));
        }
        if (field == std::wstring_view(L"row")) shell->rows.Items().RemoveAt(0);
        check(!valid(), L"A stale or unavailable mail drop passed validation.");
        shell->loading = false; shell->dialogOpen = false; shell->dirty.clear(); shell->generation = 0; shell->owner = L"all";
        shell->state = savedState; accounts = array(shell->state, L"accounts"); shell->serverFolders = savedFolders;
        if (field == std::wstring_view(L"row")) { controls::ListViewItem row; row.Tag(source); shell->rows.Items().InsertAt(0, row); }
    }
    shell->mailDragToken = {}; check(!valid(), L"A completed drag token can be replayed.");
    Json local; put(local, L"id", L"local"); put(local, L"accountId", L"drag@example.invalid"); put(local, L"viewId", L"local");
    check(shell->startMailDrag(local).empty(), L"A local-only message can start a provider drag.");
    for (auto provider : {L"microsoft", L"imap"}) {
        auto account = array(shell->state, L"accounts").GetAt(0).GetObject(); put(account, L"provider", provider);
        auto message = Json::Parse(source.Stringify()); put(message, L"id", hstring(provider) + L":duplicate");
        shell->rows.Items().GetAt(0).as<controls::ListViewItem>().Tag(message);
        auto token = shell->startMailDrag(message);
        check(!token.empty() && shell->mailDropMessage(token, L"drag@example.invalid", L"label").Size()
            && shell->mailDropDestination(L"drag@example.invalid", L"archive").empty(), L"Outlook/IMAP drop routing or unavailable Archive failed.");
    }
}
void readerRefreshChecks(std::shared_ptr<Shell> const& shell) {
    auto check = [](bool condition, wchar_t const* message) { if (!condition) throw hresult_error(E_FAIL, message); };
    auto stored = Json::Parse(LR"({"accountId":"reader@fixture.invalid","id":"local","folder":"inbox","attachmentsLoaded":true,"body":"Inline fixture","bodyHtml":"<img src=\"cid:fixture\">","attachments":[],"read":true})");
    auto previous = Json::Parse(stored.Stringify());
    put(previous, L"bodyHtml", L"<img src=\"data:image/png;base64,fixture\">");
    previous.Insert(L"inlineImages", Value::CreateBooleanValue(true)); previous.Insert(L"read", Value::CreateBooleanValue(false));
    auto refreshed = refreshedReaderMessage(previous, stored);
    check(flag(refreshed, L"inlineImages") && flag(refreshed, L"read") && text(refreshed, L"bodyHtml") == text(previous, L"bodyHtml")
        && !flag(stored, L"inlineImages") && text(stored, L"bodyHtml") != text(previous, L"bodyHtml"),
        L"Reader refresh lost the explicit inline copy or modified stored message JSON.");
    for (auto field : {L"accountId", L"remoteId", L"providerFolderId", L"messageId", L"body", L"bodyTruncated", L"attachmentsLoaded", L"contentIncomplete", L"providerDraft", L"folder"}) {
        auto changed = Json::Parse(previous.Stringify());
        if (field == std::wstring_view(L"bodyTruncated") || field == std::wstring_view(L"contentIncomplete") || field == std::wstring_view(L"providerDraft")) changed.Insert(field, Value::CreateBooleanValue(true));
        else if (field == std::wstring_view(L"attachmentsLoaded")) changed.Insert(field, Value::CreateBooleanValue(false));
        else put(changed, field, field == std::wstring_view(L"folder") ? L"drafts" : L"changed");
        check(!flag(refreshedReaderMessage(changed, stored), L"inlineImages"), L"Reader refresh reused an inline copy after its content/owner became ineligible.");
    }
    auto incomplete = Json::Parse(LR"({"id":"local","hasAttachments":false,"attachmentsLoaded":true,"contentIncomplete":true})");
    auto panel = stack(); appendAttachmentControls(shell, panel, incomplete);
    check(panel.Children().Size() && unbox_value<hstring>(panel.Children().GetAt(0).as<controls::Button>().Content()) == L"Load message content and attachments…",
        L"Incomplete content has no explicit recovery entry when attachment metadata is empty.");
}
IAsyncAction mailSelectionMenuChecks(std::shared_ptr<Shell> shell, std::vector<Json> batch, Json evidence) {
    auto check = [](bool condition, wchar_t const* message) { if (!condition) throw hresult_error(E_FAIL, message); };
    apartment_context ui;
    auto rows = shell->rows; auto anchor = rows.Items().GetAt(0).as<controls::ListViewItem>();
    auto menu = anchor.ContextFlyout().as<controls::MenuFlyout>();
    auto owner = shell->owner; auto generation = shell->generation;
    std::set<std::wstring> expectedIds;
    for (auto const& message : batch) expectedIds.insert(std::wstring(text(message, L"viewId")));
    auto sameContext = [&] {
        if (!shell->current(generation, owner) || shell->section != L"mail" || shell->rows != rows
            || !rows.Items().Size() || rows.Items().GetAt(0) != anchor || anchor.ContextFlyout() != menu
            || shell->loading || shell->dialogOpen || shell->closing || !shell->dirty.empty() || shell->service->writing()) return false;
        std::set<std::wstring> selectedIds;
        auto messages = shell->selectedMessages();
        for (auto const& message : messages) {
            if (text(message, L"accountId") != owner) return false;
            selectedIds.insert(std::wstring(text(message, L"viewId")));
        }
        return messages.size() == 2 && selectedIds == expectedIds;
    };
    auto mounted = [&](controls::ListViewItem const& target) {
        auto ancestor = target.try_as<xaml::DependencyObject>();
        while (ancestor && ancestor != shell->root) ancestor = xaml::Media::VisualTreeHelper::GetParent(ancestor);
        return bool(ancestor);
    };
    auto liveTarget = [&](controls::ListViewItem const& target) {
        return target.IsLoaded() && target.IsEnabled() && target.Visibility() == xaml::Visibility::Visible
            && target.ActualWidth() > 0 && target.ActualHeight() > 0 && mounted(target);
    };
    struct MenuEvents { bool opening = false, opened = false, closed = false; };
    auto events = std::make_shared<MenuEvents>();
    auto opening = menu.Opening(auto_revoke, [events](auto const&, auto const&) { events->opening = true; });
    auto opened = menu.Opened(auto_revoke, [events](auto const&, auto const&) { events->opened = true; });
    auto closed = menu.Closed(auto_revoke, [events](auto const&, auto const&) { events->closed = true; });
    struct CloseMenu {
        controls::MenuFlyout menu; bool requested = false, finished = false;
        ~CloseMenu() { if (requested && !finished) try { menu.Hide(); } catch (...) {} }
    } cleanup{menu};
    unsigned showCalls = 0; bool rejectedDetached = false;
    evidence.Insert(L"initialLoaded", Value::CreateBooleanValue(anchor.IsLoaded()));
    evidence.Insert(L"initialMounted", Value::CreateBooleanValue(mounted(anchor)));
    auto showOnce = [&](controls::ListViewItem const& target) {
        if (!liveTarget(target)) return false;
        check(sameContext() && target == anchor, L"The selection menu target no longer belongs to its owned selection.");
        check(showCalls == 0, L"The selection menu fixture attempted to retry ShowAt.");
        ++showCalls; cleanup.requested = true; menu.ShowAt(target); return true;
    };
    auto diagnostic = [&] {
        for (auto const& [key, value] : {std::pair{L"loaded", anchor.IsLoaded()}, {L"mounted", mounted(anchor)},
            {L"current", sameContext()}, {L"opening", events->opening}, {L"opened", events->opened},
            {L"closed", events->closed}, {L"open", menu.IsOpen()}, {L"detachedRejected", rejectedDetached}})
            evidence.Insert(key, Value::CreateBooleanValue(value));
        evidence.Insert(L"items", Value::CreateNumberValue(menu.Items().Size()));
        evidence.Insert(L"showCalls", Value::CreateNumberValue(showCalls));
    };
    try {
        // The same guard must refuse an unmounted target, even with owned row
        // metadata. WinUI ShowAt otherwise silently ignores a non-live target;
        // sleeping afterward cannot cause that discarded request to open.
        controls::ListViewItem detached; detached.Tag(anchor.Tag());
        check(!detached.IsLoaded() && !mounted(detached), L"The negative selection menu fixture unexpectedly became live.");
        rejectedDetached = !showOnce(detached);
        check(rejectedDetached && showCalls == 0 && !events->opening && !menu.IsOpen(),
            L"The selection menu accepted an unattached fixture target.");
        // Realize this exact current row before the single ShowAt. A bounded
        // event wait observes UI completion, not an assumed 50 ms render time.
        auto deadline = GetTickCount64() + 5000;
        rows.ScrollIntoView(anchor); shell->root.UpdateLayout();
        while (sameContext() && !liveTarget(anchor) && GetTickCount64() < deadline) {
            co_await resume_after(std::chrono::milliseconds(10)); co_await ui; shell->root.UpdateLayout();
        }
        check(sameContext() && liveTarget(anchor), L"The selection menu row did not become live in its owned mailbox.");
        check(showOnce(anchor), L"The selection menu target changed before ShowAt.");
        while (!events->opened && sameContext() && GetTickCount64() < deadline) {
            co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
        }
        check(events->opening && events->opened && menu.IsOpen() && menu.Target() == anchor && sameContext(),
            L"The selection menu did not open on its current owned two-row selection.");
        check(menu.Items().Size() >= 9, L"The selection context menu has no batch actions.");
        std::vector<hstring> actions;
        for (auto const& value : menu.Items()) if (auto item = value.try_as<controls::MenuFlyoutItem>()) actions.push_back(item.Text());
        check(actions == std::vector<hstring>{L"Delete", L"Mark read", L"Mark unread", L"Star", L"Unstar", L"Mark Pending", L"Clear Pending", L"Archive locally", L"Move to local Trash"},
            L"The owned two-row selection menu lost or changed its batch actions.");
        menu.Hide();
        while (!events->closed && GetTickCount64() < deadline) {
            co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
        }
        check(events->closed && !menu.IsOpen() && sameContext(), L"The selection menu did not close while preserving its owned selection.");
        cleanup.finished = true; diagnostic();
        std::fprintf(stderr, "Native smoke: mail-selection-menu-events-passed\n"); std::fflush(stderr);
    } catch (...) { try { diagnostic(); } catch (...) {} throw; }
}
IAsyncAction mailRevisionChecks(std::shared_ptr<Shell> shell) {
    auto check = [](bool condition, wchar_t const* message) { if (!condition) throw hresult_error(E_FAIL, message); };
    auto rowMessage = [](controls::ListViewItem const& row) { return row.Tag().as<Json>(); };
    auto visible = [&](hstring const& id) {
        for (auto const& value : shell->rows.Items()) {
            auto message = rowMessage(value.as<controls::ListViewItem>());
            if (text(message, L"viewId") == id) return message;
        }
        return Json();
    };
    auto samePage = [&](Json const& expected) {
        auto messages = array(expected, L"messages");
        if (messages.Size() != shell->rows.Items().Size()) return false;
        for (uint32_t i = 0; i < messages.Size(); ++i) {
            auto actual = rowMessage(shell->rows.Items().GetAt(i).as<controls::ListViewItem>());
            if (text(actual, L"viewId") != text(messages.GetAt(i).GetObject(), L"viewId")
                || text(actual, L"accountId") != shell->owner) return false;
        }
        return true;
    };
    co_await shell->navigate(L"mail", L"one@fixture.invalid");
    auto owner = shell->owner;
    auto arrival = rowMessage(shell->rows.Items().GetAt(0).as<controls::ListViewItem>());
    auto arrivalPath = L"/messages/" + escaped(text(arrival, L"id"));
    auto arrivalOriginal = object(co_await shell->service->request(arrivalPath, owner), L"message");
    auto markRead = flag(object(object(shell->state, L"settings"), L"preferences"), L"markReadOnOpen");
    Json watchedOriginal; hstring watchedPath;
    std::exception_ptr failure;
    try {
        // Make an existing fictional row newly enter the mounted inbox using
        // the service writer. No provider operation or second DB writer runs.
        Json moved; put(moved, L"folder", L"archive");
        co_await shell->service->request(arrivalPath, owner, L"PATCH", moved);
        co_await shell->loadPage(0, false, true);
        check(!visible(text(arrival, L"viewId")).Size(), L"Background-arrival fixture did not leave the inbox.");
        put(moved, L"folder", L"inbox");
        co_await shell->service->request(arrivalPath, owner, L"PATCH", moved);
        co_await shell->refresh(false);
        check(visible(text(arrival, L"viewId")).Size() && shell->rows.Items().Size() == 50,
            L"A background revision did not refresh the mounted inbox.");

        co_await shell->loadPage(1);
        check(shell->cursors.size() == 2 && shell->rows.Items().Size() == 15,
            L"Revision checks did not reach page two.");
        auto watched = shell->rows.Items().GetAt(0).as<controls::ListViewItem>();
        auto metadata = rowMessage(watched); auto viewId = text(metadata, L"viewId");
        watchedPath = L"/messages/" + escaped(text(metadata, L"id"));
        watchedOriginal = object(co_await shell->service->request(watchedPath, owner), L"message");
        shell->loading = true; shell->rows.SelectedItem(watched); shell->loading = false;
        co_await shell->read(metadata, false);
        shell->readerFocused = false; shell->applyMailLayout();
        auto sequence = shell->selectionGeneration;
        Json preference; preference.Insert(L"markReadOnOpen", Value::CreateBooleanValue(true));
        shell->state = co_await shell->service->request(L"/settings/preferences", owner, L"POST", preference);
        Json unread; unread.Insert(L"read", Value::CreateBooleanValue(false));
        co_await shell->service->request(watchedPath, owner, L"PATCH", unread);
        co_await shell->refresh(false);
        check(shell->cursors.size() == 2 && shell->selectionGeneration == sequence
            && text(shell->selected, L"viewId") == viewId && !flag(shell->selected, L"read")
            && !flag(visible(viewId), L"read") && !shell->readerFocused,
            L"Background refresh lost page/selection/reader layout or re-marked mail read.");
        auto persisted = object(co_await shell->service->request(watchedPath, owner), L"message");
        check(!flag(persisted, L"read"), L"A revision refresh wrote mark-on-open to the service.");

        auto revision = shell->mailRevision;
        Json read; read.Insert(L"read", Value::CreateBooleanValue(true));
        co_await shell->service->request(watchedPath, owner, L"PATCH", read);
        shell->dirty.insert(L"revision-fixture"); co_await shell->refresh(false);
        check(shell->mailRevision == revision && !flag(shell->selected, L"read"), L"Refresh replaced dirty foreground work.");
        shell->dirty.erase(L"revision-fixture"); shell->dialogOpen = true;
        co_await shell->refresh(false);
        check(shell->mailRevision == revision, L"Refresh ran behind a foreground dialog.");
        shell->dialogOpen = false; shell->navigation.IsEnabled(false);
        co_await shell->refresh(false);
        check(shell->mailRevision == revision, L"Refresh ignored the foreground navigation guard.");
        shell->navigation.IsEnabled(true);
        auto firstRefresh = shell->refresh(false);
        check(shell->refreshing, L"Workspace refresh has no in-flight guard.");
        co_await shell->refresh(false); co_await firstRefresh;
        check(!shell->refreshing && flag(shell->selected, L"read") && shell->mailRevision != revision,
            L"Deferred/coalesced refresh did not apply the latest revision.");

        // Read-state updates from another client keep the active unread row in
        // place without performing mark-on-open again.
        co_await shell->service->request(watchedPath, owner, L"PATCH", unread);
        shell->unreadFilter.IsChecked(true); co_await shell->loadPage(0, false, true);
        shell->loading = true;
        for (auto const& value : shell->rows.Items())
            if (text(rowMessage(value.as<controls::ListViewItem>()), L"viewId") == viewId) shell->rows.SelectedItem(value);
        shell->loading = false;
        co_await shell->read(visible(viewId), false);
        co_await shell->service->request(watchedPath, owner, L"PATCH", read);
        co_await shell->refresh(false);
        check(flag(shell->selected, L"read") && flag(visible(viewId), L"read") && shell->retainedUnread.Size()
            && shell->rows.SelectedItem() && text(rowMessage(shell->rows.SelectedItem().as<controls::ListViewItem>()), L"viewId") == viewId,
            L"A background read-state change discarded the active unread-filter row.");
        shell->unreadFilter.IsChecked(false); co_await shell->loadPage(0, false, true); co_await shell->loadPage(1);

        // Page two's signed cursor expires after an unrelated successful write.
        co_await shell->loadPage(-1); co_await shell->loadPage(1);
        check(!shell->cursors.back().empty(), L"Cursor recovery requires a signed page-two cursor.");
        co_await shell->service->request(watchedPath, owner, L"PATCH", unread);
        Json cursorRequest; put(cursorRequest, L"folder", shell->folder); put(cursorRequest, L"cursor", shell->cursors.back());
        put(cursorRequest, L"sort", L"newest"); put(cursorRequest, L"locale", L"en");
        auto expiredResponse = co_await shell->service->requestWithStatus(L"/mail/page", owner, L"POST", cursorRequest);
        check(expiredResponse.GetNamedNumber(L"status", 0) == 409
            && text(object(expiredResponse, L"body"), L"error") == L"Mail changed or the cursor expired. Refresh the list.",
            L"The async transport lost the expired mail cursor's HTTP status/body.");
        put(cursorRequest, L"cursor", L""); cursorRequest.Insert(L"offset", Value::CreateNumberValue(50));
        auto expectedPage = co_await shell->service->request(L"/mail/page", owner, L"POST", cursorRequest);
        co_await shell->loadPage();
        check(shell->cursors.size() == 2 && shell->rows.Items().Size() == 15
            && shell->previous.IsEnabled() && !shell->next.IsEnabled() && shell->cursors.back().empty() && samePage(expectedPage),
            L"Expired current-page cursor did not recover at its numeric offset.");
        co_await shell->loadPage(-1);
        co_await shell->service->request(watchedPath, owner, L"PATCH", read);
        co_await shell->loadPage(1);
        check(shell->cursors.size() == 2 && shell->rows.Items().Size() == 15 && shell->previous.IsEnabled(),
            L"Next after a background revision left the old page or disabled recovery.");

        // An ordinary failed read must not move the committed pager state.
        auto cursors = shell->cursors; auto pageLabel = shell->pageLabel.Text(); auto firstRow = shell->rows.Items().GetAt(0);
        auto folder = shell->folder; shell->folder = L"invalid-native-fixture-folder";
        Json invalidRequest; put(invalidRequest, L"folder", shell->folder);
        auto invalidResponse = co_await shell->service->requestWithStatus(L"/mail/page", owner, L"POST", invalidRequest);
        check(invalidResponse.GetNamedNumber(L"status", 0) == 400
            && text(object(invalidResponse, L"body"), L"error") == L"Invalid mail folder, sorting or page size.",
            L"The async transport lost an ordinary HTTP error's status/body.");
        co_await shell->loadPage(-1); shell->folder = folder;
        check(shell->cursors == cursors && shell->pageLabel.Text() == pageLabel && shell->rows.Items().GetAt(0) == firstRow
            && shell->previous.IsEnabled() && shell->search.IsEnabled() && !shell->loading,
            L"A page failure changed committed position/rows or left controls disabled.");

        shell->search.Text(L"Native fixture"); co_await shell->loadPage(0, false, true);
        check(shell->rows.Items().Size() == 30 && !shell->nextCursor.empty(), L"Search cursor fixture did not produce multiple pages.");
        co_await shell->service->request(watchedPath, owner, L"PATCH", unread);
        Json searchRequest; put(searchRequest, L"folder", shell->folder); put(searchRequest, L"query", L"Native fixture");
        put(searchRequest, L"scope", L"folder"); put(searchRequest, L"sort", L"relevance"); put(searchRequest, L"locale", L"en");
        put(searchRequest, L"cursor", shell->nextCursor);
        expiredResponse = co_await shell->service->requestWithStatus(L"/search", owner, L"POST", searchRequest);
        check(expiredResponse.GetNamedNumber(L"status", 0) == 409
            && text(object(expiredResponse, L"body"), L"error") == L"Search changed or the cursor expired. Search again.",
            L"The async transport lost the expired search cursor's HTTP status/body.");
        put(searchRequest, L"cursor", L""); searchRequest.Insert(L"page", Value::CreateNumberValue(1));
        expectedPage = co_await shell->service->request(L"/search", owner, L"POST", searchRequest);
        co_await shell->loadPage(1);
        check(shell->cursors.size() == 2 && shell->rows.Items().Size() == 30 && shell->previous.IsEnabled()
            && shell->next.IsEnabled() && shell->cursors.back().empty() && samePage(expectedPage), L"Search stale cursor did not recover its numeric page.");
        revision = shell->mailRevision;
        shell->search.Text(L"Unsubmitted query");
        co_await shell->service->request(watchedPath, owner, L"PATCH", read);
        co_await shell->refresh(false);
        check(shell->mailRevision == revision && shell->cursors.size() == 2,
            L"Background refresh submitted an unfinished search edit.");
        shell->search.Text(L"Native fixture"); co_await shell->refresh(false);
        check(shell->mailRevision != revision && shell->cursors.size() == 2 && shell->rows.Items().Size() == 30,
            L"Background refresh did not retain the current search page.");
    } catch (...) { failure = std::current_exception(); }
    shell->dirty.erase(L"revision-fixture"); shell->dialogOpen = false; shell->loading = false; shell->navigation.IsEnabled(true);
    shell->unreadFilter.IsChecked(false);
    if (watchedOriginal.Size()) {
        Json restore; restore.Insert(L"read", Value::CreateBooleanValue(flag(watchedOriginal, L"read")));
        co_await shell->service->request(watchedPath, owner, L"PATCH", restore);
    }
    Json restoreFolder; put(restoreFolder, L"folder", text(arrivalOriginal, L"folder"));
    co_await shell->service->request(arrivalPath, owner, L"PATCH", restoreFolder);
    Json preference; preference.Insert(L"markReadOnOpen", Value::CreateBooleanValue(markRead));
    shell->state = co_await shell->service->request(L"/settings/preferences", owner, L"POST", preference);
    co_await shell->navigate(L"mail", owner);
    if (failure) std::rethrow_exception(failure);
}
IAsyncAction Shell::smoke() {
    auto lifetime = shared_from_this();
    auto check = [](bool condition, wchar_t const* message) { if (!condition) throw hresult_error(E_FAIL, message); };
    std::string failure, phase = "begin";
    bool fixtureVerified = false;
    auto enter = [&](std::string next) {
        phase = std::move(next);
        std::fprintf(stderr, "Native smoke: %s\n", phase.c_str()); std::fflush(stderr);
    };
    Json readerEvidence, selectionMenuEvidence;
    try {
        readerSecurityChecks();
        readerRefreshChecks(lifetime);
        check(mailDateLabel(L"2026-09-28T12:00:00.000Z") == mailDateLabel(L"2026-09-28T20:00:00+08:00")
            && std::wstring_view(mailDateLabel(L"2026-09-28T12:00:00.000Z")).find(L"T12:") == std::wstring_view::npos
            && mailDateLabel(L"invalid") == L"invalid", L"Mail dates did not preserve the instant while formatting local time.");
        auto directory = service->directory();
        check(std::filesystem::canonical(directory.parent_path()) == std::filesystem::canonical(std::filesystem::temp_directory_path()) && directory.filename().wstring().starts_with(L"morrow-native-check-"), L"Native acceptance requires an isolated temporary workspace.");
        std::ifstream marker(directory / L"disposable-native-fixture");
        std::string value((std::istreambuf_iterator<char>(marker)), {});
        check(value == "Morrow native acceptance fixture", L"Native acceptance fixture marker is missing.");
        fixtureVerified = true;
        enter("sync-status"); syncStatusChecks();
        enter("mail-drag-drop-guards"); mailDragChecks(service);
        enter("imap-move-recovery"); co_await moveRecoveryChecks(root);
        bool seeded = array(state,L"accounts").Size() > 0;
        enter("sidebar-resize-and-filter");
        check(folderFilter && sidebarDivider, L"The sidebar has no native folder filter or resize handle.");
        auto sidebarWidth = navigation.OpenPaneLength();
        resizeSidebar(sidebarWidth + 40);
        check(navigation.OpenPaneLength() > sidebarWidth && !text(service->clientState(), L"morrow.sidebar.width").empty(), L"Sidebar enlargement was not persisted.");
        resizeSidebar(0, false); check(navigation.OpenPaneLength() == 180, L"The sidebar can shrink below its accessible minimum.");
        resizeSidebar(sidebarWidth, false);
        if (seeded) {
            check(array(object(serverFolders, owner.c_str()), L"folders").Size() > 0,
                L"Startup did not restore the owning folder catalog without Browse/Refresh.");
            auto savedFolders = Json::Parse(serverFolders.Stringify()); auto savedOwner = owner; auto savedFolder = folder; auto savedGeneration = generation; auto savedSelected = selected.Stringify();
            Json catalog; JsonArray entries;
            for (auto name : {L"Projects / A very long folder name 中文", L"Other"}) { Json entry; put(entry, L"id", name); put(entry, L"name", name); entries.Append(entry); }
            catalog.Insert(L"folders", entries); serverFolders.Insert(owner, catalog);
            folderFilter.Text(L"PROJECTS"); rebuildNavigation();
            int matches = 0, managers = 0;
            for (auto const& value : navigation.MenuItems()) if (auto group=value.try_as<controls::NavigationViewItem>();group&&group.Tag()&&text(group.Tag().as<Json>(),L"owner")==owner) {
                for (auto const& child:group.MenuItems()) if(auto remote=child.try_as<controls::NavigationViewItem>();remote&&remote.MenuItems().Size()) {
                    for(auto const& entry:remote.MenuItems()) {auto item=entry.as<controls::NavigationViewItem>();auto tag=item.Tag().as<Json>();if(text(tag,L"section")==L"manage-folders")++managers;else if(text(tag,L"section")==L"mail"){++matches;check(text(tag,L"folder")==L"provider:Projects / A very long folder name 中文"&&item.ContextFlyout()&&item.AllowDrop(),L"The folder filter, context actions or native drop target failed.");}}
                }
            }
            check(matches==1&&managers==1&&owner==savedOwner&&folder==savedFolder&&generation==savedGeneration&&selected.Stringify()==savedSelected,L"Filtering folders changed the current mailbox or selection.");
            for (auto const& row : rows.Items()) check(row.as<controls::ListViewItem>().CanDrag(), L"A mail list row has no native drag gesture.");
            folderFilter.Text(L""); serverFolders=savedFolders; rebuildNavigation();
        }
        enter("macos-layout-parity");
        auto themes = xaml::Application::Current().Resources().ThemeDictionaries();
        for (auto name : {L"Light", L"Default"}) {
            auto palette = themes.Lookup(box_value(name)).as<xaml::ResourceDictionary>();
            auto color = unbox_value<Windows::UI::Color>(palette.Lookup(box_value(L"SystemAccentColor")));
            check(name == std::wstring_view(L"Light") ? color == Windows::UI::Color{255, 26, 74, 61} : color == Windows::UI::Color{255, 166, 212, 176}, L"Windows lost the shared Morrow light/dark accent.");
        }
        check(themes.Lookup(box_value(L"HighContrast")).as<xaml::ResourceDictionary>().Size() == 0, L"Brand colours override the system high-contrast palette.");
        enter("theme-background");
        auto requestedTheme = root.RequestedTheme();
        apartment_context themeUi;
        for (bool dark : {false, true}) {
            root.RequestedTheme(dark ? xaml::ElementTheme::Dark : xaml::ElementTheme::Light);
            co_await resume_after(std::chrono::milliseconds(50)); co_await themeUi;
            root.UpdateLayout();
            auto background = root.Background().try_as<xaml::Media::SolidColorBrush>();
            check(bool(background), L"The native shell has no opaque theme background.");
            auto color = background.Color();
            check(color.A == 255 && (dark ? std::max({color.R, color.G, color.B}) < 80
                : std::min({color.R, color.G, color.B}) > 220), L"Switching Light/Dark did not repaint the native shell background.");
        }
        root.RequestedTheme(requestedTheme);
        check(composeButton.IsEnabled() == seeded && syncButton.IsEnabled() == seeded, L"Compose/Sync do not reflect connected-account onboarding.");
        check(shellMail && shellAgent && shellBrain && shellMode() == L"mail" && section == L"mail" && folder == L"inbox", L"Cold start did not land on Mail with Mail, Agent, and Brain in the primary chrome.");
        check(xaml::Automation::AutomationProperties::GetAutomationId(shellMail) == L"shell.mail"
            && xaml::Automation::AutomationProperties::GetName(shellMail) == L"Mail, selected"
            && xaml::Automation::AutomationProperties::GetAutomationId(shellAgent) == L"shell.agent"
            && xaml::Automation::AutomationProperties::GetAutomationId(shellBrain) == L"shell.brain",
            L"The primary chrome does not expose Mail, Agent, and Brain.");
        bool studioPrimary = false, namedToday = false;
        for (auto const& value : navigation.MenuItems()) if (auto item = value.try_as<controls::NavigationViewItem>(); item && item.Tag()) {
            auto tag = item.Tag().as<Json>();
            if (text(tag, L"section") == L"studio" && text(tag, L"owner").empty()) studioPrimary = true;
            if (text(tag, L"section") == L"today") {
                auto caption = unbox_value_or<hstring>(item.Content(), L"");
                if (caption == L"Today") namedToday = true;
            }
        }
        bool studioAdvanced = false;
        for (auto const& value : navigation.FooterMenuItems()) if (auto item = value.try_as<controls::NavigationViewItem>(); item && item.Tag()) {
            if (text(item.Tag().as<Json>(), L"section") == L"studio") studioAdvanced = true;
        }
        check(!studioPrimary && namedToday && studioAdvanced, L"Today must retain its named entry and AI Studio its advanced footer entry.");
        check(composeButton.Parent() == syncButton.Parent() && controls::Grid::GetColumn(syncButton) == 1,
            L"Sync must sit beside Compose in the sidebar.");
        controls::NavigationViewItem combined{nullptr};
        for (auto const& value : navigation.MenuItems()) if (auto item = value.try_as<controls::NavigationViewItem>(); item && item.Tag()) {
            auto tag = item.Tag().as<Json>();
            check(text(tag, L"owner") != L"demo", L"The internal Demo account is visible.");
            if (text(tag, L"owner") == L"all") combined = item;
        }
        check(bool(combined) == seeded, L"Combined folders do not reflect the connected accounts.");
        if (combined) {
            check(combined.MenuItems().Size() == 9, L"Combined mail does not expose every mailbox folder.");
            std::set<std::wstring> folders;
            for (auto const& value : combined.MenuItems()) {
                auto tag = value.as<controls::NavigationViewItem>().Tag().as<Json>();
                check(text(tag, L"owner") == L"all" && text(tag, L"section") == L"mail", L"A combined folder is routed to an individual owner.");
                folders.insert(std::wstring(text(tag, L"folder")));
            }
            check(folders == std::set<std::wstring>{L"inbox", L"starred", L"pending", L"later", L"sent", L"drafts", L"archive", L"spam", L"trash"}, L"Combined mail folder destinations are duplicated or missing.");
        }
        enter("initial-page");
        check(page.Content() && !loading && !closing && !dialogOpen && dirty.empty(), L"The normal initial page is not ready.");
        if (seeded) {
            check(section == L"mail" && connected(owner) && rows && rows.Items().Size() >= 1,
                L"The initial owned mailbox has no ready mail rows.");
            auto firstRow = rows.Items().GetAt(0).as<controls::ListViewItem>().Content().try_as<controls::StackPanel>();
            auto quick = firstRow ? firstRow.Tag().try_as<controls::StackPanel>() : controls::StackPanel{nullptr};
            check(quick && quick.Children().Size() == 2 && quick.Children().GetAt(0).try_as<controls::Button>()
                && quick.Children().GetAt(1).try_as<controls::DropDownButton>(), L"Mail rows must expose Read and a named More menu.");
            check(mailList && mailList.RowDefinitions().Size() == 3 && mailBody.Children().Size() == 3 &&
                controls::Grid::GetRow(rows) == 1, L"Mail controls and paging are not grouped with the message list.");
            auto savedLayout = mailLayout;
            mailLayout = L"focus"; readerFocused = true; applyMailLayout();
            check(mailList.Visibility() == xaml::Visibility::Collapsed && reader.Visibility() == xaml::Visibility::Visible,
                L"Focused reading did not hide the complete mail list pane.");
            readerFocused = false; mailLayout = savedLayout; applyMailLayout();
            for (auto const& item : rows.Items())
                check(text(item.as<controls::ListViewItem>().Tag().as<Json>(), L"accountId") == owner,
                    L"The initial mail page contains another owner's rows.");
        } else {
            check(owner.empty() && section == L"mail" && page.Content() != nullptr, L"Fresh startup did not open Add account onboarding.");
        }
        // Application readiness only, not a compositor/presentation timestamp.
        std::fprintf(stderr, "Native milestone: first-page-ready\n"); std::fflush(stderr);
        apartment_context ui;
        co_await resume_after(std::chrono::seconds(2)); co_await ui;
        if (seeded) {
            enter("mail-resize");
            auto savedLayout = mailLayout;
            auto savedHeight = listHeight;
            mailLayout = L"bottom"; listHeight = 120; applyMailLayout(); mailBody.UpdateLayout();
            check(rows.ActualHeight() >= 80, L"Resizing Reader below hid the message rows behind fixed mailbox controls.");
            listHeight = savedHeight; mailLayout = savedLayout; applyMailLayout();
            // Measure the first HTML document before dialogs or the mailbox walkthrough.
            enter("reader-isolation");
            readerEvidence = co_await readerRuntimeChecks(lifetime);
        }
        enter("folder-manager-and-pickers");
        co_await folderPickerChecks(root);
        enter("selected-folder-sync");
        co_await folderSyncChecks(root);
        downloadControlsChecks();
        enter("interaction-guards");
        co_await nativeInteractionChecks(lifetime);
        enter("general-navigation-save");
        co_await settingsNavigationChecks(lifetime);
        enter("sidebar-settings-click");
        root.UpdateLayout();
        auto settingsItem = navigation.SettingsItem().as<controls::NavigationViewItem>();
        auto settingsPeer = xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(settingsItem);
        auto settingsSelect = settingsPeer.GetPattern(xaml::Automation::Peers::PatternInterface::SelectionItem).try_as<xaml::Automation::Provider::ISelectionItemProvider>();
        check(bool(settingsSelect), L"The native Settings navigation item does not expose its selection action.");
        settingsSelect.Select();
        auto navigationDeadline = GetTickCount64() + 5000;
        while (section != L"preferences" && GetTickCount64() < navigationDeadline) {
            co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
        }
        check(section == L"preferences" && page.Content() && !closing, L"Clicking the native Settings item did not safely open preferences.");
        if (!seeded) {
            enter("fresh-settings");
            check(owner.empty(), L"Fresh onboarding selected the internal Demo mailbox.");
            co_await navigate(L"settings");
            check(page.Content() != nullptr, L"Add account UI did not load.");
        } else {
            enter("window-size");
            check(array(state,L"accounts").Size() == 2, L"Expected two isolated fixture owners.");
            auto restoredSize = window.AppWindow().Size();
            auto expectedSize = mailWindowBounds(window, 1040, 760);
            auto resizeDeadline = GetTickCount64() + 1000;
            while ((restoredSize.Width != expectedSize.Width || restoredSize.Height != expectedSize.Height) && GetTickCount64() < resizeDeadline) {
                co_await resume_after(std::chrono::milliseconds(10));
                co_await ui;
                restoredSize = window.AppWindow().Size();
            }
            if (restoredSize.Width != expectedSize.Width || restoredSize.Height != expectedSize.Height) {
                auto detail = L"The previous host window size was not restored: expected " + to_hstring(expectedSize.Width) + L"x" + to_hstring(expectedSize.Height) + L", got " + to_hstring(restoredSize.Width) + L"x" + to_hstring(restoredSize.Height)
                    + L"; maximum track size " + to_hstring(GetSystemMetrics(SM_CXMAXTRACK)) + L"x" + to_hstring(GetSystemMetrics(SM_CYMAXTRACK)) + L".";
                throw hresult_error(E_FAIL, detail);
            }
            enter("composer-return-context");
            co_await composerReturnChecks(lifetime);
            enter("mail-first-page");
            co_await navigate(L"mail", L"one@fixture.invalid");
            check(rows.Items().Size() == 50 && !nextCursor.empty(), L"First mail page is incomplete.");
            std::set<std::wstring> identities;
            for (auto const& item : rows.Items()) {
                auto row = item.as<controls::ListViewItem>().Tag().as<Json>();
                check(text(row,L"accountId") == owner && !row.HasKey(L"body"), L"Metadata exposed bodies or another owner.");
                identities.insert(std::wstring(text(row,L"viewId")));
            }
            check(identities.size() == 50, L"Mail rows have duplicate UI identities.");
            enter("mail-next-page");
            cursors.push_back(nextCursor);
            auto pendingPage = loadPage();
            check(loading && !search.IsEnabled() && !sorting.IsEnabled(), L"Query and sort remained editable during pagination.");
            co_await pendingPage;
            check(!loading && search.IsEnabled() && sorting.IsEnabled(), L"Pagination did not restore query and sort controls.");
            check(rows.Items().Size() == 15 && nextCursor.empty(), L"Second page did not finish the mailbox.");
            cursors.pop_back(); co_await loadPage();
            enter("mail-sorts");
            for (int sort = 0; sort < 6; ++sort) {
                loading = true; sorting.SelectedIndex(sort); loading = false;
                cursors = {L""}; co_await loadPage();
                check(rows.Items().Size() == 50, L"A supported sort could not load.");
            }
            enter("mail-background-revision-and-cursor-recovery");
            co_await mailRevisionChecks(lifetime);
            enter("download-shared-view-refresh");
            co_await downloadRefreshChecks(lifetime);
            enter("mail-reader");
            auto response = co_await service->request(L"/messages/mail-000", owner);
            auto source = object(response,L"message");
            auto row = rows.Items().GetAt(0).as<controls::ListViewItem>();
            auto clicked = row.Tag().as<Json>();
            rows.ScrollIntoView(row);
            root.UpdateLayout();
            auto layoutDeadline = GetTickCount64() + 5000;
            while ((!row.ActualWidth() || !row.ActualHeight()) && GetTickCount64() < layoutDeadline) {
                co_await resume_after(std::chrono::milliseconds(10)); co_await ui; root.UpdateLayout();
            }
            auto peer = xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(rows)
                .as<xaml::Automation::Peers::ListViewAutomationPeer>().CreateItemAutomationPeer(row);
            auto select = peer.GetPattern(xaml::Automation::Peers::PatternInterface::SelectionItem).try_as<xaml::Automation::Provider::ISelectionItemProvider>();
            check(bool(select), L"The native mail row does not expose its selection action.");
            select.Select();
            auto clickDeadline = GetTickCount64() + 5000;
            while ((text(selected,L"viewId") != text(clicked,L"viewId") || text(selected,L"body").size() <= 20 || loading) && GetTickCount64() < clickDeadline) {
                co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
            }
            check(text(selected,L"viewId") == text(clicked,L"viewId"), L"Clicking a native mail row did not open its owned message.");
            co_await read(source);
            check(text(selected,L"accountId") == owner && text(selected,L"body").size() > 20, L"The native reader did not load full owned text.");
            auto readerLayout = reader.Content().try_as<controls::Grid>();
            check(readerLayout && readerLayout.RowDefinitions().Size() == 2,
                L"The message actions are not kept above the scrolling reader.");
            enter("contextual-reader-and-selection-actions");co_await contextualMailChecks(lifetime);
            enter("reader-load-recovery");
            auto missing = Json::Parse(source.Stringify()); put(missing, L"id", L"missing-native-fixture");
            auto mounted = reader.Content();
            co_await read(missing);
            check(reader.Content() == mounted && !reader.IsEnabled() && readerNotice.Content()
                && text(selected, L"viewId") == text(source, L"viewId"), L"Failed detail loading lost the retained message or its retry state.");
            auto staleFailure = read(missing);
            co_await read(source, false); auto currentNotice = status.Text(); co_await staleFailure;
            check(reader.IsEnabled() && !readerNotice.Content() && status.Text() == currentNotice,
                L"An obsolete detail failure replaced the newer reader status.");
            auto cancelMessage = rows.Items().GetAt(0).as<controls::ListViewItem>().Tag().as<Json>();
            auto cancelOwner = text(cancelMessage, L"accountId");
            auto cancelPath = L"/messages/" + escaped(text(cancelMessage, L"id"));
            auto originalCancel = object(co_await service->request(cancelPath, cancelOwner), L"message");
            check(cancelOwner == owner && text(originalCancel, L"accountId") == cancelOwner
                && text(originalCancel, L"viewId") == text(cancelMessage, L"viewId"), L"Back cancellation requires an owned fixture message.");
            auto preferences = object(object(state, L"settings"), L"preferences");
            bool originalMarkRead = flag(preferences, L"markReadOnOpen");
            std::exception_ptr cancellationFailure;
            try {
                Json unreadFixture; unreadFixture.Insert(L"read", Value::CreateBooleanValue(false));
                cancelMessage = object(co_await service->request(cancelPath, cancelOwner, L"PATCH", unreadFixture), L"message");
                check(!flag(cancelMessage, L"read") && text(cancelMessage, L"accountId") == cancelOwner
                    && text(cancelMessage, L"viewId") == text(originalCancel, L"viewId"),
                    L"Back cancellation could not prepare its unread fixture.");
                preferences.Insert(L"markReadOnOpen", Value::CreateBooleanValue(true));
                for (auto const& metadata : {cancelMessage, missing}) {
                    auto opening = read(metadata);
                    auto panel = readerNotice.Content().as<controls::StackPanel>();
                    auto back = panel.Children().GetAt(panel.Children().Size() - 1).as<controls::Button>();
                    root.UpdateLayout();
                    check(back.Focus(xaml::FocusState::Keyboard), L"Back cancellation could not focus its reader control.");
                    auto backPeer = xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(back);
                    auto invoke = backPeer.GetPattern(xaml::Automation::Peers::PatternInterface::Invoke).as<xaml::Automation::Provider::IInvokeProvider>();
                    invoke.Invoke(); auto noticeAfterBack = status.Text(); co_await opening;
                    auto after = object(co_await service->request(cancelPath, cancelOwner), L"message");
                    check(!readerFocused && !pendingRead.Size() && !selected.Size() && rows.SelectedItems().Size() == 0 && status.Text() == noticeAfterBack
                        && !flag(after, L"read"), L"A late read result after Back reopened the reader, marked mail or replaced status.");
                    auto focus = xaml::Input::FocusManager::GetFocusedElement(root.XamlRoot()).try_as<xaml::DependencyObject>();
                    while (focus && focus != rows) focus = xaml::Media::VisualTreeHelper::GetParent(focus);
                    check(bool(focus), L"Back cancellation did not return keyboard focus to the mail list.");
                }
            } catch (...) {
                cancellationFailure = std::current_exception();
                ++readGeneration; pendingRead = Json();
            }
            preferences.Insert(L"markReadOnOpen", Value::CreateBooleanValue(originalMarkRead));
            Json restoreCancel; restoreCancel.Insert(L"read", Value::CreateBooleanValue(flag(originalCancel, L"read")));
            auto restoredCancel = object(co_await service->request(cancelPath, cancelOwner, L"PATCH", restoreCancel), L"message");
            check(flag(restoredCancel, L"read") == flag(originalCancel, L"read"), L"Back cancellation did not restore the fixture read flag.");
            if (cancellationFailure) std::rethrow_exception(cancellationFailure);
            co_await read(source, false);
            enter("mail-patches");
            auto markerSelection = selectionGeneration;
            auto markerReadGeneration = readGeneration;
            Json pending; pending.Insert(L"pending",Value::CreateBooleanValue(true)); co_await patch(source,pending);
            check(flag(selected,L"pending") && selectionGeneration == markerSelection && readGeneration != markerReadGeneration,
                L"Pending did not update metadata while retaining selection and invalidating older reads.");
            Json later; later.Insert(L"lowPriority",Value::CreateBooleanValue(true)); co_await patch(selected,later);
            check(flag(selected,L"lowPriority") && flag(selected,L"pending"),L"Later should be independent from Pending in the native reader.");
            later.Insert(L"lowPriority",Value::CreateBooleanValue(false)); co_await patch(selected,later);
            check(!flag(selected,L"lowPriority") && flag(selected,L"pending"),L"Returning from Later cleared the Pending marker.");
            auto cursorCount = cursors.size();
            Json unread; unread.Insert(L"read",Value::CreateBooleanValue(false)); co_await patch(selected,unread);
            check(!flag(selected,L"read") && cursors.size()==cursorCount && selectionGeneration == markerSelection,
                L"Manual unread reset selection or pagination.");
            auto otherRow = rows.Items().GetAt(1).as<controls::ListViewItem>().Tag().as<Json>();
            auto selectedID = text(selected,L"viewId");
            check(text(otherRow,L"viewId") != selectedID, L"Fixture rows did not have separate identities.");
            Json otherRead; otherRead.Insert(L"read",Value::CreateBooleanValue(!flag(otherRow,L"read")));
            auto otherPatch = patch(otherRow,otherRead);
            check(loading, L"The local marker patch did not guard its in-flight update.");
            co_await read(otherRow); // A read started during the mutation must not replace the selection.
            co_await otherPatch;
            check(text(selected,L"viewId") == selectedID && selectionGeneration == markerSelection,
                L"A quick action or overlapping read on another row replaced or invalidated the open reader.");
            enter("mail-interrupted-read");
            for (auto key : {L"read", L"starred", L"pending", L"other-row"}) {
                co_await read(source);
                loading = true; rows.SelectedItems().Clear();
                for (auto const& item : rows.Items())
                    if (text(item.as<controls::ListViewItem>().Tag().as<Json>(),L"viewId") == text(otherRow,L"viewId")) rows.SelectedItems().Append(item);
                loading = false;
                auto opening = read(otherRow); // The background GET cannot complete on this UI thread before the next PATCH starts.
                check(text(pendingRead,L"viewId") == text(otherRow,L"viewId") && text(selected,L"viewId") == selectedID,
                    L"The interrupted-read fixture did not hold the new selection's detail request.");
                Json marker; marker.Insert(key == std::wstring_view(L"other-row") ? L"pending" : key,Value::CreateBooleanValue(true));
                auto mutation = patch(key == std::wstring_view(L"other-row") ? source : otherRow,marker);
                co_await opening; co_await mutation;
                auto chosen = selectedMessages();
                check(!pendingRead.Size() && chosen.size() == 1 && text(chosen[0],L"viewId") == text(otherRow,L"viewId")
                    && text(selected,L"viewId") == text(otherRow,L"viewId") && text(selected,L"accountId") == text(otherRow,L"accountId")
                    && text(selected,L"body").size() > 20,
                    L"A local patch stranded the selected row's interrupted detail read or crossed its owner.");
                if (key != std::wstring_view(L"other-row")) check(flag(selected,key), L"The resumed reader applied metadata from before the patch.");
            }
            {
                enter("mail-reader-reselection");
                auto previousSort = sorting.SelectedIndex();
                loading = true; sorting.SelectedIndex(1); loading = false; // Oldest keeps A and its peer on this page after Unstar.
                for (auto& cursor : cursors) cursor = L"";
                co_await loadPage();
                check(rows.Items().Size() >= 2, L"Reselection requires two stable owned rows.");
                auto stablePeer = rows.Items().GetAt(1).as<controls::ListViewItem>().Tag().as<Json>();
                auto originalA = object(co_await service->request(L"/messages/" + escaped(text(source,L"id")),text(source,L"accountId")),L"message");
                auto originalB = object(co_await service->request(L"/messages/" + escaped(text(stablePeer,L"id")),text(stablePeer,L"accountId")),L"message");
                check(connected(text(originalA,L"accountId")) && text(originalA,L"accountId") == owner
                    && text(originalB,L"accountId") == owner && text(originalA,L"viewId") == selectedID
                    && text(originalB,L"viewId") == text(stablePeer,L"viewId") && text(originalA,L"viewId") != text(originalB,L"viewId"),
                    L"Reselection requires two distinct owned fixture messages.");
                auto previousMarkRead = flag(object(object(state,L"settings"),L"preferences"),L"markReadOnOpen");
                Json readingPreference; readingPreference.Insert(L"markReadOnOpen",Value::CreateBooleanValue(true));
                state = co_await service->request(L"/settings/preferences",L"",L"POST",readingPreference);
                check(flag(object(object(state,L"settings"),L"preferences"),L"markReadOnOpen"),
                    L"Reselection did not enable the fixture automatic read preference.");
                for (auto key : {L"read", L"unread", L"starred", L"pending", L"no-patch", L"busy-reselect"}) {
                    enter("mail-reselect-" + to_string(key));
                    Json unreadB; unreadB.Insert(L"read",Value::CreateBooleanValue(false));
                    auto preparedB = object(co_await service->request(L"/messages/" + escaped(text(originalB,L"id")),text(originalB,L"accountId"),L"PATCH",unreadB),L"message");
                    check(!flag(preparedB,L"read") && text(preparedB,L"viewId") == text(originalB,L"viewId"),
                        L"Reselection did not prepare the owned unread B fixture.");
                    co_await read(source);
                    auto mountedA = Json::Parse(selected.Stringify());
                    auto mountedReader = reader.Content();
                    check(text(mountedA,L"viewId") == selectedID && text(mountedA,L"accountId") == owner && text(mountedA,L"body").size() > 20,
                        L"Reselection did not mount A's full owned body.");
                    for (auto& cursor : cursors) cursor = L"";
                    co_await loadPage();
                    controls::ListViewItem itemA{nullptr}, itemB{nullptr};
                    for (auto const& item : rows.Items()) {
                        auto entry = item.as<controls::ListViewItem>(); auto metadata = entry.Tag().as<Json>();
                        if (text(metadata,L"viewId") == selectedID) itemA = entry;
                        if (text(metadata,L"viewId") == text(originalB,L"viewId")) itemB = entry;
                    }
                    check(itemA && itemB, L"Reselection fixture rows disappeared from the current page.");
                    auto reselectPeer = xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(rows)
                        .as<xaml::Automation::Peers::ListViewAutomationPeer>().CreateItemAutomationPeer(itemA);
                    auto reselectA = reselectPeer.GetPattern(xaml::Automation::Peers::PatternInterface::SelectionItem)
                        .try_as<xaml::Automation::Provider::ISelectionItemProvider>();
                    check(bool(reselectA), L"A's native row does not expose its reselection action.");
                    loading = true; rows.SelectedItems().Clear(); rows.SelectedItems().Append(itemB); loading = false;
                    auto opening = read(itemB.Tag().as<Json>());
                    auto pendingGeneration = readGeneration;
                    check(text(pendingRead,L"viewId") == text(originalB,L"viewId") && text(selected,L"viewId") == selectedID,
                        L"Reselection did not hold B's detail GET while A remained mounted.");
                    bool busyReselect = key == std::wstring_view(L"busy-reselect");
                    bool patchA = key != std::wstring_view(L"no-patch");
                    auto markerKey = busyReselect ? L"pending" : key == std::wstring_view(L"unread") ? L"read" : key;
                    // The resumed GET must respect an explicit unread change, even under mark-on-open.
                    bool markerValue = key == std::wstring_view(L"read") || (markerKey != std::wstring_view(L"read") && patchA && !flag(mountedA,markerKey));
                    Json marker; if (patchA) marker.Insert(markerKey,Value::CreateBooleanValue(markerValue));
                    IAsyncAction mutation{nullptr};
                    if (busyReselect) {
                        mutation = patch(mountedA,marker);
                        check(loading && !pendingRead.Size(), L"The busy reselection fixture did not interrupt B's detail GET.");
                    }
                    // No await between B's GET, the actual SelectionChanged and the optional PATCH.
                    reselectA.Select();
                    auto reselected = selectedMessages();
                    check(reselected.size() == 1 && text(reselected[0],L"viewId") == selectedID && text(reselected[0],L"accountId") == owner
                        && readGeneration != pendingGeneration
                        && (busyReselect ? !pendingRead.Size() && loading
                            : text(pendingRead,L"viewId") == selectedID && text(pendingRead,L"accountId") == owner),
                        L"Actually reselecting A did not replace B's pending GET with A's owned detail request.");
                    if (patchA) {
                        if (!busyReselect) mutation = patch(mountedA,marker);
                        co_await opening; co_await mutation;
                    } else {
                        co_await opening;
                        // SelectionChanged owns A's new operation. Wait only for completion;
                        // B's pending state and A's reselection above never depend on a delay.
                        auto completionDeadline = GetTickCount64() + 5000;
                        while ((pendingRead.Size() || loading || reader.Content() == mountedReader) && GetTickCount64() < completionDeadline) {
                            co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
                        }
                    }
                    auto chosen = selectedMessages();
                    check(!pendingRead.Size() && chosen.size() == 1 && text(chosen[0],L"viewId") == selectedID
                        && text(chosen[0],L"accountId") == owner && text(selected,L"viewId") == selectedID
                        && text(selected,L"accountId") == owner && text(selected,L"body") == text(mountedA,L"body")
                        && reader.Content() != mountedReader && !loading,
                        L"B's completed detail GET replaced the reselected A row, reader owner or full body.");
                    if (patchA) check(flag(selected,markerKey) == markerValue && flag(chosen[0],markerKey) == markerValue,
                        L"Reselection lost A's local marker update in the reader or list.");
                    auto finishedB = object(co_await service->request(L"/messages/" + escaped(text(originalB,L"id")),text(originalB,L"accountId")),L"message");
                    check(text(finishedB,L"viewId") == text(originalB,L"viewId") && text(finishedB,L"accountId") == owner && !flag(finishedB,L"read"),
                        L"Completing the revoked B GET marked the unselected fixture message read.");
                }
                Json restoreA; for (auto key : {L"read", L"starred", L"pending"}) restoreA.Insert(key,Value::CreateBooleanValue(flag(originalA,key)));
                co_await service->request(L"/messages/" + escaped(text(originalA,L"id")),text(originalA,L"accountId"),L"PATCH",restoreA);
                Json restoreB; restoreB.Insert(L"read",Value::CreateBooleanValue(flag(originalB,L"read")));
                co_await service->request(L"/messages/" + escaped(text(originalB,L"id")),text(originalB,L"accountId"),L"PATCH",restoreB);
                readingPreference.Insert(L"markReadOnOpen",Value::CreateBooleanValue(previousMarkRead));
                state = co_await service->request(L"/settings/preferences",L"",L"POST",readingPreference);
                check(flag(object(object(state,L"settings"),L"preferences"),L"markReadOnOpen") == previousMarkRead,
                    L"Reselection did not restore the fixture reading preference.");
                loading = true; sorting.SelectedIndex(previousSort); loading = false;
                for (auto& cursor : cursors) cursor = L"";
                co_await loadPage();
            }
            co_await read(source);
            enter("mail-multi-selection");
            check(rows.SelectionMode() == controls::ListViewSelectionMode::Extended, L"Mail list does not support range/multiple selection.");
            loading = true; rows.SelectedItems().Clear();
            rows.SelectedItems().Append(rows.Items().GetAt(0)); rows.SelectedItems().Append(rows.Items().GetAt(1)); loading = false;
            auto batch = selectedMessages();
            check(batch.size() == 2 && text(batch[0],L"viewId") != text(batch[1],L"viewId"), L"Multiple selection lost owned row identities.");
            auto outside = rows.Items().GetAt(2).as<controls::ListViewItem>().Tag().as<Json>();
            check(selectedMessages(outside).size() == 1, L"Right-click outside selection acts on unrelated mail.");
            co_await mailSelectionMenuChecks(lifetime, batch, selectionMenuEvidence);
            Json stars; stars.Insert(L"starred",Value::CreateBooleanValue(true)); co_await patchMessages(batch,stars);
            for (auto const& message : batch) check(flag(object(co_await service->request(L"/messages/"+escaped(text(message,L"id")),text(message,L"accountId")),L"message"),L"starred"), L"Batch patch lost an owning mailbox.");
            check(selectedMessages().size() == 2, L"Refreshing a batch discarded multi-selection.");
            enter("mail-unread-filter");
            auto markOnOpen = flag(object(object(state,L"settings"),L"preferences"),L"markReadOnOpen");
            Json readingPreference; readingPreference.Insert(L"markReadOnOpen",Value::CreateBooleanValue(true));
            state = co_await service->request(L"/settings/preferences",L"",L"POST",readingPreference);
            unreadFilter.IsChecked(true); cursors = {L""}; co_await loadPage();
            check(rows.Items().Size() > 0, L"Unread filter lost the unread fixture message.");
            for (auto const& item : rows.Items()) check(!flag(item.as<controls::ListViewItem>().Tag().as<Json>(), L"read"), L"Unread-only view includes a read message.");
            auto firstUnread = rows.Items().GetAt(0).as<controls::ListViewItem>().Tag().as<Json>();
            co_await read(firstUnread);
            check(flag(selected,L"read") && retainedUnread.Size() && rows.Items().Size() > 0, L"Unread filtering removed the active read row.");
            auto following = rows.Items().GetAt(1).as<controls::ListViewItem>().Tag().as<Json>();
            co_await read(following);
            for (auto const& item : rows.Items()) check(text(item.as<controls::ListViewItem>().Tag().as<Json>(),L"viewId") != text(firstUnread,L"viewId"), L"Switching messages retained the previous read row.");
            co_await patch(selected,pending);
            check(flag(retainedUnread,L"pending"), L"The retained row did not update its Pending marker.");
            co_await patch(selected,unread);
            check(!flag(selected,L"read") && !retainedUnread.Size(), L"Marking retained mail unread kept a stale read marker.");
            unreadFilter.IsChecked(false);
            readingPreference.Insert(L"markReadOnOpen",Value::CreateBooleanValue(markOnOpen));
            state = co_await service->request(L"/settings/preferences",L"",L"POST",readingPreference);
            check(flag(object(object(state,L"settings"),L"preferences"),L"markReadOnOpen") == markOnOpen, L"Unread checks did not restore the fixture reading preference.");
            cursors = {L""}; co_await loadPage();
            enter("mail-combined");
            co_await navigate(L"mail",L"all");
            check(pageLabel.Text().size() && rows.Items().Size()==50, L"Combined mail did not load.");
            for (auto const& value : rows.Items()) {
                auto item = value.as<controls::ListViewItem>();
                auto row = item.Content().as<controls::StackPanel>();
                auto heading = row.Children().GetAt(0).as<controls::Grid>();
                auto identity = heading.Children().GetAt(0).as<controls::Grid>();
                auto account = identity.Children().GetAt(1).as<controls::TextBlock>();
                auto date = heading.Children().GetAt(1).as<controls::TextBlock>();
                auto message = item.Tag().as<Json>();
                check(account.Text() == text(message, L"accountId") && controls::Grid::GetColumn(account) == 1,
                    L"Combined row did not show its own mailbox beside the sender.");
                check(date.Text() == mailDateLabel(text(message, L"date")) && controls::Grid::GetColumn(date) == 1 && date.TextAlignment() == xaml::TextAlignment::Right,
                    L"Mail date is missing from the right side of the header.");
                auto subjectLine = row.Children().GetAt(1).as<controls::Grid>();
                check(subjectLine.Children().GetAt(2) == row.Tag(), L"Quick actions must not displace the sender header.");
                auto name = xaml::Automation::AutomationProperties::GetName(item);
                check(std::wstring_view(name).find(account.Text()) != std::wstring_view::npos, L"Accessible mail row lost its complete owning mailbox.");
            }
            enter("mail-list-layout");
            auto originalLayout = mailLayout; auto originalWidth = listWidth; auto originalTheme = root.RequestedTheme();
            auto originalDensity = text(object(object(state, L"settings"), L"preferences"), L"density");
            mailLayout = L"right";
            auto readerFits = [&] {
                auto origin = readerPane.TransformToVisual(mailBody).TransformPoint(Point{});
                auto windowOrigin = readerPane.TransformToVisual(root).TransformPoint(Point{});
                return readerPane.ActualWidth() >= 320 && origin.X >= 0
                    && origin.X + readerPane.ActualWidth() <= mailBody.ActualWidth() + 1
                    && windowOrigin.X + readerPane.ActualWidth() <= root.ActualWidth() + 1;
            };
            for (auto density : {L"compact", L"comfortable", L"spacious"}) {
                Json preference; put(preference, L"density", density);
                state = co_await service->request(L"/settings/preferences", L"", L"POST", preference);
                co_await loadPage();
                for (bool dark : {false, true}) for (double width : {260., 320., 500.}) {
                    root.RequestedTheme(dark ? xaml::ElementTheme::Dark : xaml::ElementTheme::Light);
                    listWidth = width; applyMailLayout(); root.UpdateLayout();
                    auto item = rows.Items().GetAt(0).as<controls::ListViewItem>(); rows.ScrollIntoView(item);
                    auto deadline = GetTickCount64() + 2000;
                    do { co_await resume_after(std::chrono::milliseconds(20)); co_await ui; root.UpdateLayout(); }
                    while ((!item.ActualHeight() || !readerFits()
                        || (width + 328 <= mailBody.ActualWidth() && std::abs(mailList.ActualWidth() - width) > 1)) && GetTickCount64() < deadline);
                    check(readerFits(), L"The reading pane extends beyond the mail page.");
                    loading=true;rows.SelectedItem(item);loading=false;updateMailSelectionActions();root.UpdateLayout();
                    auto toolbar=mailSelectionActions.Children().GetAt(1).as<controls::StackPanel>();
                    auto deleteButton=selectionDelete;
                    auto sidebarActions = syncButton.Parent().as<controls::Grid>();
                    auto deleteOrigin = deleteButton.TransformToVisual(toolbar).TransformPoint(Point{});
                    auto syncOrigin = syncButton.TransformToVisual(sidebarActions).TransformPoint(Point{});
                    auto composeOrigin = composeButton.TransformToVisual(sidebarActions).TransformPoint(Point{});
                    check(deleteButton.ActualWidth() >= 28 && deleteOrigin.X + deleteButton.ActualWidth() <= toolbar.ActualWidth() + 1
                        && syncButton.ActualWidth() >= 40 && syncOrigin.X + syncButton.ActualWidth() <= sidebarActions.ActualWidth() + 1
                        && composeOrigin.X + composeButton.ActualWidth() <= syncOrigin.X,
                        L"The sidebar actions overlap or Sync/Delete is clipped.");
                    check(unbox_value<hstring>(syncButton.Content()) == L"Sync" && xaml::Automation::AutomationProperties::GetAutomationId(syncButton) == L"mail.sync",
                        L"The sidebar lost its labeled Sync button.");
                    check(xaml::Automation::AutomationProperties::GetName(deleteButton) == L"Move selected messages to provider Trash",
                        L"The toolbar Delete icon lost its accessible action name.");
                    auto row = item.Content().as<controls::StackPanel>();
                    auto heading = row.Children().GetAt(0).as<controls::Grid>();
                    auto identity = heading.Children().GetAt(0).as<controls::Grid>();
                    auto sender = identity.Children().GetAt(0).as<controls::TextBlock>();
                    auto account = identity.Children().GetAt(1).as<controls::TextBlock>();
                    auto date = heading.Children().GetAt(1).as<controls::TextBlock>();
                    auto origin = [&](xaml::UIElement const& element) { return element.TransformToVisual(heading).TransformPoint(Point{}); };
                    check(mailList.ActualWidth() >= 260 && mailList.ActualWidth() <= width + 1
                        && (width + 328 > mailBody.ActualWidth() || std::abs(mailList.ActualWidth() - width) < 1)
                        && sender.ActualWidth() > 20 && account.ActualWidth() > 20 && date.ActualWidth() > 20,
                        L"A narrow mail header lost its sender, mailbox or date.");
                    check(origin(account).X >= origin(sender).X + sender.ActualWidth() - 1 && origin(date).X >= origin(account).X + account.ActualWidth() - 1
                        && origin(date).X + date.ActualWidth() <= heading.ActualWidth() + 1, L"Mail header fields overlap or overflow.");
                    auto before = origin(date); auto quick = row.Tag().as<controls::StackPanel>(); quick.Visibility(xaml::Visibility::Visible); root.UpdateLayout();
                    check(origin(date) == before, L"Quick actions displaced the mail date.");
                    quick.Visibility(xaml::Visibility::Collapsed);
                    if (width == 320 || density == std::wstring_view(L"comfortable"))
                        co_await captureMailList(lifetime, L"mail-list-" + hstring(density) + (dark ? L"-dark-" : L"-light-") + to_hstring(static_cast<int>(width)) + L".png");
                }
            }
            auto originalSize = window.AppWindow().Size();
            auto scale = root.XamlRoot().RasterizationScale();
            auto wideWidth = std::min(originalSize.Width + static_cast<int32_t>(std::lround(300 * scale)), GetSystemMetrics(SM_CXMAXTRACK));
            auto narrowWidth = std::min(originalSize.Width, wideWidth - static_cast<int32_t>(std::lround(100 * scale)));
            for (auto width : {wideWidth, narrowWidth, wideWidth, narrowWidth, originalSize.Width}) {
                window.AppWindow().Resize({width, originalSize.Height});
                auto deadline = GetTickCount64() + 2000;
                do { co_await resume_after(std::chrono::milliseconds(20)); co_await ui; root.UpdateLayout(); }
                while ((window.AppWindow().Size().Width != width || !readerFits()
                    || (mailBody.ActualWidth() >= 828 && std::abs(mailList.ActualWidth() - 500) > 1)) && GetTickCount64() < deadline);
                check(readerFits() && listWidth == 500
                    && window.AppWindow().Size().Width == width
                    && (mailBody.ActualWidth() < 828 || std::abs(mailList.ActualWidth() - 500) <= 1),
                    (L"Window resizing clipped the reader or lost the requested list width: requested window " + to_hstring(width)
                        + L", actual " + to_hstring(window.AppWindow().Size().Width) + L", client " + to_hstring(root.ActualWidth())
                        + L", body " + to_hstring(mailBody.ActualWidth()) + L", list " + to_hstring(mailList.ActualWidth())
                        + L", reader " + to_hstring(readerPane.ActualWidth()) + L".").c_str());
            }
            auto originalSidebar = navigation.OpenPaneLength();
            auto originalOrigin = mailBody.TransformToVisual(root).TransformPoint(Point{}).X;
            for (auto width : {originalSidebar + 60, originalSidebar, originalSidebar + 60, originalSidebar}) {
                resizeSidebar(width, false);
                auto deadline = GetTickCount64() + 2000;
                do { co_await resume_after(std::chrono::milliseconds(20)); co_await ui; root.UpdateLayout(); }
                while ((!readerFits() || std::abs(mailBody.TransformToVisual(root).TransformPoint(Point{}).X - originalOrigin - width + originalSidebar) > 1)
                    && GetTickCount64() < deadline);
                check(readerFits() && listWidth == 500 && navigation.OpenPaneLength() == width
                    && std::abs(mailBody.TransformToVisual(root).TransformPoint(Point{}).X - originalOrigin - width + originalSidebar) <= 1,
                    L"Sidebar resizing clipped the reader or lost the requested list width.");
            }
            Json preference; put(preference, L"density", originalDensity);
            state = co_await service->request(L"/settings/preferences", L"", L"POST", preference);
            mailLayout = originalLayout; listWidth = originalWidth; root.RequestedTheme(originalTheme); applyMailLayout(); co_await loadPage();
            enter("studio-combined");
            co_await navigate(L"studio",L"all");
            check(section==L"studio" && owner==L"all" && page.Content(), L"Combined AI Studio did not stay on Assistant.");
            co_await navigate(L"mail",L"all");
            auto other = object(co_await service->request(L"/messages/mail-000",L"two@fixture.invalid"),L"message");
            check(text(other,L"viewId") != text(source,L"viewId") && !flag(other,L"pending"),L"Same provider ID crossed owners.");
            enter("draft-prepare");
            Json prepare; put(prepare,L"messageId",L"provider-draft"); put(prepare,L"mode",L"copy");
            auto copy=object(co_await service->request(L"/drafts/prepare",L"one@fixture.invalid",L"POST",prepare),L"draft");
            check(text(copy,L"bcc")==L"bcc@fixture.invalid" && !copy.HasKey(L"id"),L"Provider copy lost Bcc or reused source identity.");
            enter("draft-save");
            Json draft; put(draft,L"to",L"to@fixture.invalid"); put(draft,L"bcc",L"bcc@fixture.invalid"); put(draft,L"subject",L"Native saved draft"); put(draft,L"body",L"Native saved body.");
            co_await service->request(L"/drafts",L"one@fixture.invalid",L"POST",draft);
            enter("client-state");
            auto savedState=service->clientState(); auto pendingCalendar=text(savedState,L"morrow.pendingCalendar");
            service->saveClientState(L"morrow.account.collapsed.one@fixture.invalid",L"true");
            check(text(service->clientState(),L"morrow.pendingCalendar")==pendingCalendar,L"Desktop state changed a frozen calendar retry.");
            co_await navigate(L"mail",L"one@fixture.invalid");
            enter("writing-rule-edit-retention"); co_await writingRuleEditingChecks(lifetime);
            co_await navigate(L"mail",L"one@fixture.invalid");
            enter("category-add-identity");co_await categoryCreationChecks(lifetime);
            co_await navigate(L"mail",L"one@fixture.invalid");
            for (auto const* target : {L"today", L"activity", L"scheduled", L"calendar", L"out-of-office", L"studio", L"learning", L"brain", L"reply-suggestions", L"skills", L"summaries", L"records", L"agent", L"categories"}) {
                enter("workspace-" + to_string(target));
                auto previousPage = page.Content();
                co_await navigate(target);
                check(page.Content() && page.Content() != previousPage, L"A native workspace page failed to open.");
                check(dirty.empty(), L"Opening a saved page incorrectly created unsaved edits.");
                if (std::wstring_view(target) == L"activity") { enter("activity-summary-diagnostics"); co_await summaryActivityChecks(lifetime); }
                if(std::wstring_view(target)==L"reply-suggestions"){enter("review-workspace-ownership-and-retention");co_await reviewWorkspaceChecks(lifetime);}
                if (std::wstring_view(target) == L"today") {
                    auto today = page.Content().as<controls::Grid>();
                    check(today.RowDefinitions().Size()==4,L"Today must keep account tabs and status outside the scrolling content.");
                    auto header=today.Children().GetAt(0).as<controls::StackPanel>();
                    controls::DropDownButton more{nullptr};
                    for(auto const& child:header.Children())if(auto button=child.try_as<controls::DropDownButton>();button && xaml::Automation::AutomationProperties::GetAutomationId(button)==L"review.more")more=button;
                    check(more && syncButton && syncButton.IsEnabled(),L"Today lost its explicit saved-result menu or the single global Sync action.");
                    co_await openActionFlyout(more);
                    auto choices=more.Flyout().as<controls::MenuFlyout>();controls::MenuFlyoutSubItem generate{nullptr};
                    for(auto const& item:choices.Items())if(auto sub=item.try_as<controls::MenuFlyoutSubItem>();sub && xaml::Automation::AutomationProperties::GetAutomationId(sub)==L"review.summarize")generate=sub;
                    auto expected=review->scope==L"all" ? array(state,L"accounts").Size() : 1u;
                    check(generate && generate.Items().Size()==expected,L"Today summary review must keep individual mailbox identity within the selected scope.");
                    for(auto const& item:generate.Items())check(connected(unbox_value<hstring>(item.as<controls::MenuFlyoutItem>().Tag())),L"Summary review offers an invalid writing identity.");
                    co_await closeActionFlyout(more);
                    auto tabs=today.Children().GetAt(1).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    unsigned accounts=0;for(auto const& child:tabs.Children())if(child.try_as<controls::Primitives::ToggleButton>())++accounts;
                    check(accounts==array(state,L"accounts").Size()+1,L"Today lost the shared All/account tabs.");

                }
                if (std::wstring_view(target) == L"today") check(shellMode() == L"agent", L"Today did not open inside Agent.");
                if (std::wstring_view(target) == L"agent" || std::wstring_view(target) == L"skills") {
                    auto panel = page.Content().as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    check(panel.Children().GetAt(0).as<controls::TextBlock>().Text() == L"Agent" && shellMode() == L"agent", L"Inbox Agent and Skills must use the Agent shell.");
                }
                if (std::wstring_view(target) == L"brain" || std::wstring_view(target) == L"categories" || std::wstring_view(target) == L"learning") {
                    auto panel = page.Content().as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    check(panel.Children().GetAt(0).as<controls::TextBlock>().Text() == L"Brain" && shellMode() == L"brain", L"Persona, writing rules, and categories must use the Brain shell.");
                }
                if(std::wstring_view(target)==L"agent" || std::wstring_view(target)==L"categories") {
                    auto panel=page.Content().as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    auto tabs=panel.Children().GetAt(3).as<controls::ScrollViewer>();auto open=navigation.IsPaneOpen();
                    navigation.IsPaneOpen(false);root.UpdateLayout();auto deadline=GetTickCount64()+5000;
                    while(tabs.Visibility()!=xaml::Visibility::Visible && GetTickCount64()<deadline){co_await resume_after(std::chrono::milliseconds(10));co_await ui;}
                    check(tabs.Visibility()==xaml::Visibility::Visible,L"Closing the sidebar removed the alternate named navigation.");
                    navigation.IsPaneOpen(true);root.UpdateLayout();deadline=GetTickCount64()+5000;
                    while(navigation.DisplayMode()==controls::NavigationViewDisplayMode::Expanded && tabs.Visibility()!=xaml::Visibility::Collapsed && GetTickCount64()<deadline){co_await resume_after(std::chrono::milliseconds(10));co_await ui;}
                    check(navigation.DisplayMode()!=controls::NavigationViewDisplayMode::Expanded || tabs.Visibility()==xaml::Visibility::Collapsed,L"The expanded sidebar still duplicates page navigation.");
                    navigation.IsPaneOpen(open);root.UpdateLayout();
                }
                if (std::wstring_view(target) == L"studio") {
                    auto studio = page.Content().as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    check(studio.Children().GetAt(0).as<controls::TextBlock>().Text() == L"AI Studio", L"Advanced AI Studio lost its title.");
                    auto accounts = studio.Children().GetAt(2).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    check(accounts.Children().Size() == array(state, L"accounts").Size() + 1, L"AI Studio lost the All and per-account tabs.");
                    auto tabs = studio.Children().GetAt(3).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    check(tabs.Children().Size() == 2, L"AI Studio must show Assistant and More without a Summaries page.");
                    auto more = tabs.Children().GetAt(1).as<controls::ComboBox>();
                    auto first = more.Items().GetAt(0).as<controls::ComboBoxItem>();
                    check(unbox_value<hstring>(first.Tag()) == L"brain"
                        && unbox_value<hstring>(first.Content())==L"Writing style & notes",
                        L"Writing style and notes lost its named advanced navigation entry.");
                    bool agentMoved = false, skillsMoved = false, categoriesMoved = false, rulesKept = false;
                    for (auto const& value : more.Items()) {
                        auto item = value.as<controls::ComboBoxItem>();
                        auto id = std::wstring(unbox_value<hstring>(item.Tag()));
                        auto caption = std::wstring(unbox_value<hstring>(item.Content()));
                        if (id == L"agent") agentMoved = caption==L"Inbox Agent";
                        if (id == L"skills") skillsMoved = caption==L"Reusable skills";
                        if (id == L"categories") categoriesMoved = caption==L"Mail categories";
                        if (id == L"rules") rulesKept = caption.find(L"Local Inbox Rules") != std::wstring::npos;
                    }
                    check(agentMoved && skillsMoved && categoriesMoved && rulesKept, L"Advanced navigation lost Agent, Skills, Categories, or Local Inbox Rules.");
                }
            }
            for (auto const* tab : {L"start", L"general", L"mail", L"calendar", L"model", L"search", L"policy", L"about"}) {
                enter("settings-" + to_string(tab));
                auto previousPage = page.Content();
                if (std::wstring_view(tab) == L"mail") {
                    state.Insert(L"accounts", Windows::Data::Json::JsonArray());
                    state.Insert(L"serverFolders", Json()); serverFolders = Json();
                }
                co_await settingsPage(lifetime, tab);
                check(page.Content() && page.Content() != previousPage, L"A native Settings tab failed to open.");
                auto layout = page.Content().try_as<controls::Grid>();
                check(layout && layout.ColumnDefinitions().Size() == 2 && layout.RowDefinitions().Size() == 3, L"Settings lost its fixed category sidebar and independently scrolling content.");
                auto categories = layout.Children().GetAt(1).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                check(categories.Children().GetAt(0).as<controls::ListView>().Items().Size() == 6, L"Everyday Settings must keep six primary categories.");
                auto advanced = categories.Children().GetAt(1).as<controls::Expander>();
                check(advanced.Content().as<controls::ListView>().Items().Size() == 3 &&
                    advanced.IsExpanded() == (std::wstring_view(tab) == L"model" || std::wstring_view(tab) == L"search"),
                    L"Advanced settings must open for direct setup links and stay collapsed on everyday pages.");
                if (std::wstring_view(tab) == L"model") {
                    auto body = layout.Children().GetAt(3).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    auto panel = body.Children().GetAt(2).as<controls::ContentControl>().Content().as<controls::StackPanel>();
                    auto keys = panel.Children().GetAt(3).as<controls::Expander>();
                    check(keys.IsExpanded() != flag(object(object(state, L"settings"), L"ai"), L"hasApiKey"), L"Saved model keys must keep the replacement field collapsed.");
                    auto input = panel.Children().GetAt(1).as<controls::TextBox>();
                    auto secret = keys.Content().as<controls::StackPanel>().Children().GetAt(0).as<controls::PasswordBox>();
                    root.UpdateLayout();
                    auto readyDeadline = GetTickCount64() + 5000;
                    while ((!input.IsLoaded() || !input.ActualWidth()) && GetTickCount64() < readyDeadline) {
                        co_await resume_after(std::chrono::milliseconds(10)); co_await ui; root.UpdateLayout();
                    }
                    check(input.IsLoaded() && input.ActualWidth(), L"The model endpoint control did not load for native input.");
                    input.ApplyTemplate(); secret.ApplyTemplate();
                    auto changed = std::make_shared<bool>(false);
                    auto textChanged = input.TextChanged(auto_revoke, [changed](auto const&, auto const&) { *changed = true; });
                    auto original = input.Text(); input.Text(L"http://remote.invalid/v1"); secret.Password(L"fictional-unsaved-model-key");
                    auto editDeadline = GetTickCount64() + 5000;
                    while (!*changed && GetTickCount64() < editDeadline) {
                        co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
                    }
                    check(*changed, L"The model endpoint edit did not reach its native TextChanged handler.");
                    auto test = panel.Children().GetAt(7).as<controls::Button>();
                    root.UpdateLayout();
                    auto peer = xaml::Automation::Peers::FrameworkElementAutomationPeer::CreatePeerForElement(test);
                    auto invoke = peer.GetPattern(xaml::Automation::Peers::PatternInterface::Invoke).try_as<xaml::Automation::Provider::IInvokeProvider>();
                    check(bool(invoke), L"The model connection test must expose its native action.");
                    invoke.Invoke();
                    auto notice = layout.Children().GetAt(2).as<controls::TextBlock>();
                    auto deadline = GetTickCount64() + 5000;
                    while ((!navigation.IsEnabled() || std::wstring_view(notice.Text()).find(L"Remote AI providers") == std::wstring_view::npos) && GetTickCount64() < deadline) {
                        co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
                    }
                    check(navigation.IsEnabled() && std::wstring_view(notice.Text()).find(L"Remote AI providers") != std::wstring_view::npos, L"The invalid endpoint probe did not finish without model work.");
                    check(secret.Password() == L"fictional-unsaved-model-key", L"Testing a model discarded the entered key before it could be saved or retried.");
                    *changed = false; input.Text(original); secret.Password(L"");
                    editDeadline = GetTickCount64() + 5000;
                    while (!*changed && GetTickCount64() < editDeadline) {
                        co_await resume_after(std::chrono::milliseconds(10)); co_await ui;
                    }
                    check(*changed && dirty.empty(), L"Restoring the model fixture left unsaved edits.");
                }
                if (std::wstring_view(tab) == L"search") {
                    auto body = layout.Children().GetAt(3).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    controls::ComboBox history{nullptr}; controls::Expander limits{nullptr}; bool primary = false;
                    for (auto const& child : body.Children()) if (auto container = child.try_as<controls::ContentControl>()) {
                        if (auto panel = container.Content().try_as<controls::StackPanel>()) for (auto const& control : panel.Children()) {
                            if (auto choice = control.try_as<controls::ComboBox>(); choice && unbox_value<hstring>(choice.Header()) == L"Index history") history = choice;
                            if (auto disclosure = control.try_as<controls::Expander>(); disclosure && unbox_value<hstring>(disclosure.Header()) == L"Advanced indexing options") limits = disclosure;
                            if (auto entry = control.try_as<controls::Button>(); entry && unbox_value<hstring>(entry.Content()) == L"Index downloaded mail & keep updated…") primary = true;
                            check(!control.try_as<controls::NumberBox>(), L"Technical batch limits remain in the primary indexing form.");
                        }
                    }
                    check(history && limits && !limits.IsExpanded() && primary && history.Items().Size() == 5,
                        L"Search needs an all-downloaded option, primary automatic action and collapsed advanced limits.");
                    check(unbox_value<hstring>(history.Items().GetAt(0).as<controls::ComboBoxItem>().Tag()) == L"0", L"All downloaded history has the wrong service value.");
                    auto previous = history.SelectedIndex(); history.SelectedIndex(4);
                    co_await resume_after(std::chrono::milliseconds(2300)); co_await ui;
                    check(history.SelectedIndex() == 4, L"Search status polling discarded an unsaved history-range edit.");
                    history.SelectedIndex(previous);
                }
                if (std::wstring_view(tab) == L"mail" || std::wstring_view(tab) == L"calendar") {
                    auto body = layout.Children().GetAt(3).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    bool mail = std::wstring_view(tab) == L"mail";
                    auto panel = mail ? body.Children().GetAt(2).as<controls::Expander>().Content().as<controls::StackPanel>()
                        .Children().GetAt(2).as<controls::Expander>().Content().as<controls::StackPanel>()
                        .Children().GetAt(0).as<controls::ContentControl>().Content().as<controls::StackPanel>()
                        : body.Children().GetAt(4).as<controls::ContentControl>().Content().as<controls::StackPanel>();
                    auto input = panel.Children().GetAt(mail ? 0 : 1).as<controls::TextBox>();
                    auto secret = panel.Children().GetAt(mail ? 1 : 2).as<controls::PasswordBox>();
                    auto original = input.Text(); input.Text(L"unsaved@fixture.invalid"); secret.Password(L"fictional-unsaved-secret");
                    auto edits = dirty; auto capturedOwner = owner; auto version = generation;
                    owner = L""; // Background/OAuth selection changes must keep the form current.
                    auto status = body.Children().GetAt(mail ? 5 : 3).as<controls::StackPanel>();
                    if (!mail) status.Children().GetAt(0).as<controls::TextBlock>().Text(L"Stale connection status");
                    auto deadline = GetTickCount64() + 8000;
                    while ((mail ? status.Children().Size() == 0 : status.Children().GetAt(0).as<controls::TextBlock>().Text() != L"Not connected") && GetTickCount64() < deadline) {
                        co_await resume_after(std::chrono::milliseconds(20)); co_await ui;
                    }
                    check(mail ? status.Children().Size() > 0 && array(state, L"accounts").Size() == 2
                        : status.Children().GetAt(0).as<controls::TextBlock>().Text() == L"Not connected", L"Settings did not automatically refresh local connection metadata.");
                    check(page.Content() == layout && generation == version && input.Text() == L"unsaved@fixture.invalid" && secret.Password() == L"fictional-unsaved-secret" && dirty == edits,
                        L"Automatic connection refresh replaced the page or unsaved credentials.");
                    if (mail) check(serverFolders.Size() == 2 && object(state, L"serverFolders").Size() == 2,
                        L"Settings polling omitted the saved folder catalogs.");
                    owner = capturedOwner; input.Text(original); secret.Password(L"");
                }
                if (std::wstring_view(tab) == L"policy") {
                    auto saved = object(object(state, L"settings"), L"policy").Stringify();
                    auto body = layout.Children().GetAt(3).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                    auto form = body.Children().GetAt(2).as<controls::ContentControl>().Content().as<controls::StackPanel>();
                    uint32_t optionalSections = 0;
                    for (auto const& child : form.Children()) if (auto section = child.try_as<controls::Expander>()) {
                        check(!section.IsExpanded(), L"Optional AI permission controls must start collapsed.");
                        section.IsExpanded(true); section.IsExpanded(false); ++optionalSections;
                    }
                    check(optionalSections == 3 && object(object(state, L"settings"), L"policy").Stringify() == saved,
                        L"Showing optional permission controls changed saved permissions.");
                }
                check(dirty.empty(), L"Opening a Settings tab incorrectly created unsaved edits.");
            }
            enter("composer-layout");
            co_await compose(lifetime);
            auto editor = page.Content().try_as<controls::Grid>();
            check(section == L"compose" && editor && editor.RowDefinitions().Size() == 2 && dirty.empty(),
                L"The composer did not keep its actions outside the scrolling form.");
            auto reviewControls = [&](controls::Grid const& layout, bool visible) {
                auto panes = layout.Children().GetAt(layout.Children().Size() - 1).as<controls::Grid>();
                auto form = panes.Children().GetAt(0).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                int choices = 0;
                for (auto const& child : form.Children()) if (auto button = child.try_as<controls::Button>()) {
                    auto title = unbox_value_or<hstring>(button.Content(), L"");
                    if (title == L"I found it in Sent…" || title == L"Close without retrying…") {
                        ++choices;
                        check((button.Visibility() == xaml::Visibility::Visible) == visible && button.IsEnabled() == visible,
                            L"Delivery resolution controls do not reflect the owned uncertain draft.");
                    }
                }
                check(choices == 2, L"Both delivery resolution decisions must be available.");
            };
            reviewControls(editor, false);
            Json unresolved; put(unresolved, L"id", L"fictional-uncertain-draft"); put(unresolved, L"accountId", L"one@fixture.invalid");
            put(unresolved, L"deliveryStatus", L"unconfirmed"); put(unresolved, L"deliveryRequestId", L"fictional-resolution-request");
            put(unresolved, L"to", L"recipient@fixture.invalid"); put(unresolved, L"body", L"Fictional retained delivery text.");
            co_await compose(lifetime, unresolved);
            reviewControls(page.Content().as<controls::Grid>(), true);
            controls::StackPanel limitedReader; Json limited;
            put(limited, L"body", L"Fictional partial text"); limited.Insert(L"bodyTruncated", Value::CreateBooleanValue(true));
            appendReader(lifetime, limitedReader, limited);
            bool truncationWarning = false, partialBody = false;
            for (auto const& child : limitedReader.Children()) if (auto textBlock = child.try_as<controls::TextBlock>()) {
                truncationWarning |= std::wstring_view(textBlock.Text()).find(L"truncated") != std::wstring_view::npos;
                partialBody |= textBlock.Text() == text(limited, L"body");
            }
            check(truncationWarning && partialBody, L"Partial downloaded text must retain its body and truncation warning.");
            co_await navigate(L"mail", L"one@fixture.invalid");
            for (auto mode : {L"reply", L"replyAll", L"savedReply"}) {
                enter(std::wstring_view(mode) == L"replyAll" ? "reply-history-reply-all" : std::wstring_view(mode) == L"savedReply" ? "reply-history-saved-reply" : "reply-history-reply");
                Json input; put(input, L"messageId", text(source, L"id")); put(input, L"mode", std::wstring_view(mode) == L"reply" ? L"reply" : L"replyAll");
                auto reply = object(co_await service->request(L"/drafts/prepare", L"one@fixture.invalid", L"POST", input), L"draft");
                if (std::wstring_view(mode) == L"savedReply") reply = object(co_await service->request(L"/drafts", L"one@fixture.invalid", L"POST", reply), L"message");
                co_await compose(lifetime, reply);
                auto layout = page.Content().as<controls::Grid>();
                auto panes = layout.Children().GetAt(layout.Children().Size() - 1).as<controls::Grid>();
                check(layout.MaxWidth() == 1180 && panes.Children().Size() == 2
                    && panes.Children().GetAt(0).try_as<controls::ScrollViewer>() && panes.Children().GetAt(1).try_as<controls::ScrollViewer>(),
                    L"Reply and saved-reply panes must scroll independently.");
                auto context = panes.Children().GetAt(1).as<controls::ScrollViewer>().Content().as<controls::StackPanel>();
                auto messages = context.Children().GetAt(2).as<controls::StackPanel>();
                check(messages.Children().Size() > 0 && messages.Children().GetAt(0).try_as<controls::StackPanel>(), L"Owned original reply history did not load.");
                auto original = messages.Children().GetAt(0).as<controls::StackPanel>();
                check(original.Children().GetAt(3).as<controls::TextBlock>().Text() == text(source, L"body"), L"Reply history displayed another mailbox's duplicate-ID body.");
                panes.Width(1100); panes.UpdateLayout();
                co_await resume_after(std::chrono::milliseconds(50)); co_await ui; panes.UpdateLayout();
                check(panes.RowDefinitions().Size() == 1 && controls::Grid::GetColumn(panes.Children().GetAt(1).as<xaml::FrameworkElement>()) == 1, L"Wide reply history must be on the right.");
                panes.Width(780); panes.UpdateLayout();
                co_await resume_after(std::chrono::milliseconds(50)); co_await ui; panes.UpdateLayout();
                check(panes.RowDefinitions().Size() == 2 && controls::Grid::GetRow(panes.Children().GetAt(1).as<xaml::FrameworkElement>()) == 1, L"Narrow reply panes must remain readable.");
                dirty.clear(); // Discard this known fictional, never-saved reply without a dialog.
                co_await navigate(L"mail", L"one@fixture.invalid");
            }
            check(text(service->clientState(),L"morrow.pendingCalendar")==pendingCalendar,L"Opening Calendar changed its immutable recovery record.");
        }
        enter("shutdown");
        auto draining = shutdown();
        check(closing && !closeReady, L"Shutdown did not wait for the private service.");
        HWND handle{}; check_hresult(window.as<::IWindowNative>()->get_WindowHandle(&handle));
        // Window.Close destroys directly; SC_CLOSE exercises the user's title-bar close request.
        SendMessageW(handle, WM_SYSCOMMAND, SC_CLOSE, 0);
        check(!closeReady && IsWindow(handle), L"A second close destroyed the window before the service drained.");
        Json result; result.Insert(L"ok", Value::CreateBooleanValue(true)); put(result, L"mode", seeded ? L"owned" : L"fresh");
        if (seeded) result.Insert(L"reader", readerEvidence);
        if (selectionMenuEvidence.Size()) result.Insert(L"selectionMenu", selectionMenuEvidence);
        std::ofstream(service->directory()/L"native-smoke-result.json",std::ios::binary) << to_string(result.Stringify());
        co_await draining;
        co_return;
    } catch (hresult_error const& error) { failure=to_string(error.message()); }
    catch (...) { failure="Native acceptance failed."; }
    if (!failure.empty()) {
        Json result; result.Insert(L"ok",Value::CreateBooleanValue(false)); put(result,L"error",to_hstring(failure)); put(result,L"phase",to_hstring(phase));
        if (selectionMenuEvidence.Size()) result.Insert(L"selectionMenu", selectionMenuEvidence);
        std::ofstream(service->directory()/L"native-smoke-result.json",std::ios::binary) << to_string(result.Stringify());
    }
    // Failed fixture assertions must not wait for an unsaved-edit confirmation.
    if (fixtureVerified) dirty.clear();
    co_await shutdown();
}
}
