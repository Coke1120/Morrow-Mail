#requires -Version 7.2
[CmdletBinding()]
param([switch] $SelfTest)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'native-process-identity.ps1')
. (Join-Path $PSScriptRoot 'native-process-inventory.ps1')

# Fixture-only observer, never packaged. The caller owns the UI and this child.
# No CIM, sampler pipe or sampler wait runs in the UI stderr drain loop.
function New-NativeSampleFile([string] $Fixture) {
    $directory = Get-Item -LiteralPath $Fixture
    if (-not $directory.PSIsContainer -or ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        [IO.Path]::GetDirectoryName($directory.FullName).TrimEnd('\', '/') -ine [IO.Path]::GetTempPath().TrimEnd('\', '/') -or
        $directory.Name -cnotmatch '^morrow-native-check-[0-9a-f]{32}$') { throw 'Invalid observation fixture.' }
    $marker = Get-Item -LiteralPath (Join-Path $Fixture 'disposable-native-fixture')
    if (($marker.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $marker.Length -gt 64 -or
        [IO.File]::ReadAllText($marker.FullName) -cne 'Morrow native acceptance fixture') { throw 'Invalid observation marker.' }
    $path = Join-Path $Fixture ('native-resources-' + [Guid]::NewGuid().ToString('N') + '.jsonl')
    $acl = [Security.AccessControl.FileSecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User, [Security.Principal.SecurityIdentifier]::new('S-1-5-18'))) {
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'Allow'))
    }
    # Apply the DACL atomically at creation. An ordinary FileAccess.Write handle
    # lacks WRITE_DAC and cannot be passed to FileStream.SetAccessControl.
    $rights = [Security.AccessControl.FileSystemRights]::Write -bor [Security.AccessControl.FileSystemRights]::Synchronize
    $stream = [IO.FileSystemAclExtensions]::Create([IO.FileInfo]::new($path), [IO.FileMode]::CreateNew,
        $rights, [IO.FileShare]::Read, 4096, [IO.FileOptions]::None, $acl)
    $stream.Dispose()
    return $path
}

function Start-NativeResourceCollector([Diagnostics.Process] $Ui, [string] $Path, [long] $LaunchTimestamp) {
    $start = [Diagnostics.ProcessStartInfo]::new([Environment]::ProcessPath)
    $start.UseShellExecute = $false; $start.CreateNoWindow = $true
    foreach ($argument in @('-NoLogo', '-NoProfile', '-NonInteractive', '-File', (Join-Path $PSScriptRoot 'measure-native-processes.ps1'))) {
        $start.ArgumentList.Add($argument)
    }
    Isolate-NativeEnvironment $start
    $start.Environment['MORROW_SAMPLE_PID'] = $Ui.Id.ToString([Globalization.CultureInfo]::InvariantCulture)
    $start.Environment['MORROW_SAMPLE_START'] = $Ui.StartTime.ToUniversalTime().Ticks.ToString([Globalization.CultureInfo]::InvariantCulture)
    $start.Environment['MORROW_SAMPLE_LAUNCH'] = $LaunchTimestamp.ToString([Globalization.CultureInfo]::InvariantCulture)
    $start.Environment['MORROW_SAMPLE_FILE'] = $Path
    return [Diagnostics.Process]::Start($start)
}

function Stop-NativeResourceCollector([Diagnostics.Process] $Collector) {
    $forced = $false; $reaped = $true; $exitCode = $null
    if ($Collector) {
        try {
            if (-not $Collector.WaitForExit(2000)) {
                $forced = $true
                $Collector.Kill() # This process handle only, never Kill(true)/name/tree.
                $reaped = $Collector.WaitForExit(2000)
            }
            if ($reaped) { $exitCode = $Collector.ExitCode }
        } catch { $reaped = $false }
        finally { $Collector.Dispose() }
    }
    return @{ forced = $forced; reaped = $reaped; exitCode = $exitCode }
}

function Test-NativeCreation([long] $Actual, [long] $Expected, [long] $CimTicks) {
    # WMI dates have microsecond precision; Process.StartTime is the persisted
    # identity in 100 ns UTC ticks. Never convert these large integers to double.
    return $Actual -eq $Expected -and ($Actual - $Actual % 10L) -eq ($CimTicks - $CimTicks % 10L)
}

function Get-NativeTree([object[]] $Rows, [uint32] $Root, [long] $RootTicks) {
    if ($Rows.Count -gt 8192) { throw 'Process inventory limit.' }
    $byId = @{}; $children = @{}
    foreach ($row in $Rows) {
        $id = [uint32] $row.ProcessId; $parentId = [uint32] $row.ParentProcessId
        if ($byId.ContainsKey($id)) { throw 'Duplicate process identity.' }
        $byId[$id] = $row
        if (-not $children.ContainsKey($parentId)) { $children[$parentId] = [Collections.Generic.List[object]]::new() }
        $children[$parentId].Add($row)
    }
    if (-not $byId.ContainsKey($Root)) { return }
    $rootRow = $byId[$Root]
    if ($null -eq $rootRow.CreationDate -or -not (Test-NativeCreation $RootTicks $RootTicks $rootRow.CreationDate.ToUniversalTime().Ticks)) { throw 'Root identity changed.' }
    $queue = [Collections.Generic.Queue[object]]::new(); $queue.Enqueue($rootRow)
    $seen = @{}
    while ($queue.Count) {
        $row = $queue.Dequeue(); $id = [uint32] $row.ProcessId
        if ($seen.ContainsKey($id) -or $seen.Count -eq 64) { throw 'Descendant limit or cycle.' }
        $seen[$id] = $true
        $row
        if ($children.ContainsKey($id)) {
            foreach ($child in $children[$id]) {
                if ($child.CreationDate -and $child.CreationDate.ToUniversalTime().Ticks -ge $row.CreationDate.ToUniversalTime().Ticks) { $queue.Enqueue($child) }
            }
        }
    }
}

function Write-NativeSample([IO.Stream] $Stream, $Value) {
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Value | ConvertTo-Json -Compress -Depth 5) + "`n")
    $limit = if ($Value.kind -eq 0) { 2MB - 512 } else { 2MB }
    if ($bytes.Length -gt 32KB -or $Stream.Position + $bytes.Length -gt $limit) { return $false }
    $Stream.Write($bytes, 0, $bytes.Length); $Stream.Flush()
    return $true
}

function New-NativeSkipReasonCounts {
    # Fixed vocabulary only. An unavailable handle is not proof of process exit.
    return @{ parentUnavailable = 0L; parentExited = 0L; processUnavailable = 0L; processExited = 0L
        identityMismatch = 0L; counterReadFailed = 0L; unclassified = 0L }
}

function Read-NativeProcessCounters([Diagnostics.Process] $Process) {
    return @{ workingSetBytes = $Process.WorkingSet64; privateBytes = $Process.PrivateMemorySize64
        cpuMs = $Process.TotalProcessorTime.TotalMilliseconds }
}

function New-NativeObservationState([uint32] $Root, [long] $RootTicks) {
    return @{ root = $Root; rootTicks = $RootTicks; handles = @{} }
}

function Close-NativeObservationState([Collections.IDictionary] $State) {
    foreach ($entry in $State.handles.Values) { $entry.process.Dispose() }
    $State.handles.Clear()
}

function Add-NativeObservationFailure($Sample, $Row, [uint32] $Root, [string] $Source,
    [string] $Reason, [string] $Stage, $Failure = $null, $ExitCode = $null, $NativeProof = $null, $Acquisition = $null) {
    $kind = 'none'; $code = $null
    if ($Failure) {
        while ($Failure.InnerException) { $Failure = $Failure.InnerException }
        if ($Failure -is [ComponentModel.Win32Exception]) {
            $code = $Failure.NativeErrorCode
            $kind = if ($code -eq 5) { 'accessDenied' } else { 'native' }
        } elseif ($Failure -is [UnauthorizedAccessException]) { $kind = 'accessDenied'; $code = 5 }
        elseif ($Failure -is [ArgumentException]) { $kind = 'argument' }
        elseif ($Failure -is [InvalidOperationException]) { $kind = 'invalidOperation' }
        else { $kind = 'other' }
    }
    $Sample.skipped++; $Sample.skipReasonCounts[$Reason]++
    if ([uint32] $Row.ProcessId -eq $Root) { $Sample.rootSkipped++ }
    $record = [ordered]@{ pid = [uint32] $Row.ProcessId; parentPid = [uint32] $Row.ParentProcessId
        cimStartUtcTicks = $Row.CreationDate.ToUniversalTime().Ticks; source = $Source
        reason = $Reason; stage = $Stage; errorKind = $kind; errorCode = $code; exitCode = $ExitCode }
    if ($null -ne $NativeProof) { $record.nativeProof = $NativeProof }
    # Bound additional diagnostics independently of the unchanged 64 failures,
    # 32 KiB record and 2 MiB file limits. Later failures still retain every
    # original reason/code; absent provenance never implies a successful open.
    if ($null -ne $Acquisition -and $Stage -eq 'nativeAcquire' -and $Sample.failedRecords.Count -lt 8) {
        $record.acquisition = ConvertTo-NativeAcquisition $Acquisition
    }
    $Sample.failedRecords.Add($record)
}

function ConvertTo-NativeAcquisition($Value) {
    return [ordered]@{ version = 1L; source = $Value.Source; nativeError = $Value.NativeError; clockFrequency = [Diagnostics.Stopwatch]::Frequency
        windowStartedAtQpc = $Value.WindowStartedAtQpc; windowStoppedAtQpc = $Value.WindowStoppedAtQpc
        windowUtcTicks = $Value.WindowUtcTicks; windowUtcReadCompletedAtQpc = $Value.WindowUtcReadCompletedAtQpc
        scan = $Value.Scan; scanStartedAtQpc = $Value.ScanStartedAtQpc; snapshotReadyAtQpc = $Value.SnapshotReadyAtQpc
        priorScan = $Value.PriorScan; priorScanCompletedAtQpc = $Value.PriorScanCompletedAtQpc
        openStartedAtQpc = $Value.OpenStartedAtQpc; openCompletedAtQpc = $Value.OpenCompletedAtQpc
        cimReceivedAtQpc = $Value.CimReceivedAtQpc }
}

function Invoke-NativeAcquisition([uint32] $Id, [scriptblock] $AcquireIdentity, [string] $Source, [long] $CimReceivedAtQpc = 0) {
    $trace = @{ Source = $Source; NativeError = $null; WindowStartedAtQpc = 0L; WindowStoppedAtQpc = 0L; Scan = 0L
        WindowUtcTicks = 0L; WindowUtcReadCompletedAtQpc = 0L; PriorScan = 0L; PriorScanCompletedAtQpc = 0L
        ScanStartedAtQpc = 0L; SnapshotReadyAtQpc = 0L; CimReceivedAtQpc = $CimReceivedAtQpc
        OpenStartedAtQpc = [Diagnostics.Stopwatch]::GetTimestamp(); OpenCompletedAtQpc = 0L }
    $handle = $null; $failure = $null
    try { $handle = if ($AcquireIdentity) { & $AcquireIdentity $Id } else { [MorrowObservationIdentity.ExitProof]::Acquire($Id) } }
    catch {
        $failure = $_.Exception; $cause = $failure
        while ($cause.InnerException) { $cause = $cause.InnerException }
        if ($cause -is [ComponentModel.Win32Exception]) { $trace.NativeError = $cause.NativeErrorCode }
    }
    finally { $trace.OpenCompletedAtQpc = [Diagnostics.Stopwatch]::GetTimestamp() }
    return @{ handle = $handle; failure = $failure; provenance = $trace }
}

function ConvertTo-NativeProofRead($Result) {
    if ($null -eq $Result) { return $null }
    return [ordered]@{ actualPid = $Result.ActualPid; startUtcTicks = $Result.StartUtcTicks
        identityMatched = $Result.IdentityMatched; signaled = $Result.Signaled; waitStatus = $Result.WaitStatus
        exitCode = $Result.ExitCode; nativeError = $Result.NativeError; stage = $Result.Stage; outcome = $Result.Outcome }
}

function ConvertTo-NativeLookupProof($Result, [long] $ParentTicks, [long] $SampleAt,
    [long] $AdmissionAt, [long] $CollectorDeadline) {
    return [ordered]@{ pinnedStartUtcTicks = $Result.PinnedStartUtcTicks; parentStartUtcTicks = $ParentTicks
        parentBefore = 'valid'; parentAfter = 'parentUnavailable'; clockFrequency = $Result.ClockFrequency
        sampleStartedAtQpc = $SampleAt; admissionStartedAtQpc = $AdmissionAt; collectorDeadlineAtQpc = $CollectorDeadline
        startedAtQpc = $Result.StartedAtQpc; completedAtQpc = $Result.CompletedAtQpc; deadlineAtQpc = $Result.DeadlineAtQpc
        durationMs = $Result.DurationMs; waitAttempted = $Result.WaitAttempted; settlingWait = $Result.SettlingWait
        settlingError = $Result.SettlingError; deadlineExceeded = $Result.DeadlineExceeded; outcome = $Result.Outcome
        projection = $Result.Projection; initial = (ConvertTo-NativeProofRead $Result.Initial); final = (ConvertTo-NativeProofRead $Result.Final) }
}

function Get-NativeProofParentState($Parent, [uint32] $ParentId, [long] $ParentTicks,
    [Collections.IDictionary] $Cache, [Collections.IDictionary] $Rejected, [Collections.IDictionary] $Rows,
    [uint32] $UnseenRoot = 0) {
    if (-not $Cache.ContainsKey($ParentId) -or -not [object]::ReferenceEquals($Cache[$ParentId], $Parent) -or
        (-not $Parent.seen -and $ParentId -ne $UnseenRoot) -or
        $Rejected.ContainsKey($ParentId) -or -not $Rows.ContainsKey($ParentId)) { return 'parentUnavailable' }
    $parentRow = $Rows[$ParentId]
    if ($Parent.ticks -ne $ParentTicks -or $Parent.process.Id -ne $ParentId -or
        (($Parent.seen -or $ParentId -ne $UnseenRoot) -and $Parent.parentPid -ne [uint32] $parentRow.ParentProcessId) -or
        -not (Test-NativeCreation $Parent.process.StartTime.ToUniversalTime().Ticks $ParentTicks $parentRow.CreationDate.ToUniversalTime().Ticks)) { return 'identityMismatch' }
    if ($Parent.process.HasExited) { return 'parentExited' }
    return 'valid'
}

function Add-NativeInventoryPin($Row, [uint32] $Root, [Collections.IDictionary] $Cache,
    [Collections.IDictionary] $Pins, [scriptblock] $AcquireIdentity, $NativeWindow = $null, [long] $CimReceivedAtQpc = 0) {
    $id = [uint32] $Row.ProcessId; $parentId = [uint32] $Row.ParentProcessId
    if ($id -le 1 -or $Cache.ContainsKey($id) -or $Pins.ContainsKey($id) -or
        -not $Cache.ContainsKey($parentId)) { return $false }
    $parent = $Cache[$parentId]
    if (-not $parent.seen -and $parentId -ne $Root) { return $false }
    # Provisional read-only pin: this retained, owned parent is exact and live.
    # Its current CIM row is still mandatory at ordinary admission below.
    try {
        if ($parent.process.Id -ne $parentId -or $parent.process.StartTime.ToUniversalTime().Ticks -ne $parent.ticks -or
            $parent.process.HasExited -or $null -eq $Row.CreationDate -or
            $Row.CreationDate.ToUniversalTime().Ticks -lt $parent.ticks) { return $false }
    } catch { return $false }
    if ($Cache.Count + $Pins.Count -ge 64) { throw 'Pin inventory limit.' }
    $trace = $null
    try {
        if ($NativeWindow) {
            $item = $NativeWindow.AcquireForRow($id, $parentId, $CimReceivedAtQpc)
            $trace = $item.Provenance
            if ($null -ne $item.NativeError) { throw [ComponentModel.Win32Exception]::new($item.NativeError) }
            $Pins[$id] = @{ handle = $item.Handle; failure = $null; provenance = $trace }
        } else { $Pins[$id] = Invoke-NativeAcquisition $id $AcquireIdentity 'cim-row' $CimReceivedAtQpc }
        return $null -eq $Pins[$id].failure
    } catch {
        # Store the FIRST result even while inventory is arriving. Nothing in
        # tree building or admission may reopen it or infer a normal exit.
        $Pins[$id] = @{ handle = $null; failure = $_.Exception; provenance = $trace }
        return $false
    }
}

function New-NativeAdmissionPins($Candidates, [uint32] $Root, [Collections.IDictionary] $Cache,
    [Collections.IDictionary] $Rejected, [Collections.IDictionary] $Rows, [scriptblock] $AcquireIdentity,
    [Collections.IDictionary] $Pins) {
    $pins = $Pins; $parents = @{}; $wanted = [Collections.Generic.List[uint32]]::new()
    foreach ($candidate in $Candidates) {
        $id = [uint32] $candidate.row.ProcessId; $parentId = [uint32] $candidate.row.ParentProcessId
        if ($candidate.source -ne 'cim' -or $Cache.ContainsKey($id) -or $pins.ContainsKey($id) -or -not $Cache.ContainsKey($parentId)) { continue }
        if (-not $parents.ContainsKey($parentId)) {
            $parent = $Cache[$parentId]
            # The root's original managed pin is already exact. It need not
            # have counter samples yet to permit provisional pinning. Actual
            # admission still uses the original, stricter parent checks below.
            try { $parents[$parentId] = (Get-NativeProofParentState $parent $parentId $parent.ticks $Cache $Rejected $Rows $Root) -eq 'valid' }
            catch { $parents[$parentId] = $false }
        }
        if ($parents[$parentId]) { $wanted.Add($id) }
    }
    try {
        if ($AcquireIdentity) {
            foreach ($id in $wanted) {
                $pins[$id] = Invoke-NativeAcquisition $id $AcquireIdentity 'admission'
            }
        } else {
            foreach ($item in [MorrowObservationIdentity.ExitProof]::AcquireMany($wanted.ToArray())) {
                $pins[$item.Pid] = @{ handle = $item.Handle; provenance = $item.Provenance; failure = $(if ($null -ne $item.NativeError) {
                    [ComponentModel.Win32Exception]::new($item.NativeError)
                } else { $null }) }
            }
        }
        return $pins
    } catch {
        foreach ($pin in $pins.Values) { if ($pin.handle) { $pin.handle.Dispose() } }
        throw
    }
}

function Get-NativeProcessSnapshot([uint32] $Root, [long] $RootTicks, [object[]] $SnapshotRows = $null,
    [scriptblock] $ObservationBarrier = $null, [scriptblock] $ReadCounters = $null,
    [Collections.IDictionary] $State = $null, [scriptblock] $AcquireIdentity = $null,
    [long] $CollectorDeadlineAtQpc = 0, [scriptblock] $LookupProcess = $null, [scriptblock] $ReadLookupProof = $null,
    [scriptblock] $InventoryWindowFactory = $null) {
    # A collector owns this bounded cache until its finally block. Retaining the
    # original handle preserves exit evidence; a missing PID is never that proof.
    # Fixture faults/projections are direct arguments, never environment/app switches.
    $sampleAt = [Diagnostics.Stopwatch]::GetTimestamp(); $frequency = [Diagnostics.Stopwatch]::Frequency
    if ($CollectorDeadlineAtQpc -eq 0) { $CollectorDeadlineAtQpc = $sampleAt + 180L * $frequency }
    $ownsState = $null -eq $State
    if ($ownsState) { $State = New-NativeObservationState $Root $RootTicks }
    $cache = $State.handles; $entries = [Collections.Generic.List[object]]::new(); $stage = 'root'; $earlyPins = @{}; $nativeWindow = $null
    $sample = [ordered]@{ terminalReason = $null; failureStage = 'none'; hasSnapshot = $false; skipped = 0; rootSkipped = 0
        rootExitedDuringSample = $null; skipReasonCounts = (New-NativeSkipReasonCounts); processes = @()
        lifecycleEvents = [Collections.Generic.List[object]]::new(); failedRecords = [Collections.Generic.List[object]]::new() }
    try {
        if ($State.root -ne $Root -or $State.rootTicks -ne $RootTicks) { throw 'Observation owner changed.' }
        if (-not $cache.ContainsKey($Root)) {
            $rootProcess = [Diagnostics.Process]::GetProcessById($Root)
            try {
                [void] $rootProcess.Handle
                if ($rootProcess.StartTime.ToUniversalTime().Ticks -ne $RootTicks) { throw 'Root identity changed.' }
                $cache[$Root] = @{ process = $rootProcess; ticks = $RootTicks; parentPid = 0; parentTicks = 0
                    cimTicks = $RootTicks; role = 'ui'; exitRecorded = $false; seen = $false }
            } catch { $rootProcess.Dispose(); throw }
        }
        $rootEntry = $cache[$Root]; $rootExited = $rootEntry.process.HasExited
        $rootIdentitySource = if ($rootEntry.seen) { 'priorSnapshot' } else { 'currentSnapshot' }
        $stage = 'cim'
        if (-not $rootExited -and ($null -eq $SnapshotRows -or $InventoryWindowFactory)) {
            $nativeWindow = if ($InventoryWindowFactory) { & $InventoryWindowFactory $Root $cache } else { Start-NativeInventoryWindow $Root $cache }
        }
        $inventory = [Collections.Generic.List[object]]::new()
        $receive = {
            param($Row)
            $receivedAt = [Diagnostics.Stopwatch]::GetTimestamp()
            if ($inventory.Count -ge 8192) { throw 'Process inventory limit.' }
            $inventory.Add($Row)
            if ($nativeWindow -and [uint32] $Row.ProcessId -gt 1) {
                # Same-sample new parents may preserve descendant handles only
                # after their own original native pin matches this CIM identity.
                # The window queues child-before-parent rows without admitting
                # anything to the managed cache or changing later proof gates.
                $cimTicks = if ($null -eq $Row.CreationDate) { 0L } else { $Row.CreationDate.ToUniversalTime().Ticks }
                $nativeWindow.ObserveRow([uint32] $Row.ProcessId, [uint32] $Row.ParentProcessId, $cimTicks, $receivedAt)
            }
            if (Add-NativeInventoryPin $Row $Root $cache $earlyPins $AcquireIdentity $nativeWindow $receivedAt) {
                if ($ObservationBarrier) { [void] (& $ObservationBarrier 'inventoryPinned' ([uint32] $Row.ProcessId)) }
            }
        }
        if (-not $rootExited) {
            if ($null -eq $SnapshotRows) {
                # Pin at row delivery, before collecting the remaining global
                # inventory, tree construction or any managed sibling reads.
                Get-CimInstance Win32_Process -Property ProcessId, ParentProcessId, CreationDate -OperationTimeoutSec 2 -ErrorAction Stop |
                    ForEach-Object { [void] (& $receive $_) }
            } else { foreach ($row in $SnapshotRows) { [void] (& $receive $row) } }
        }
        if ($nativeWindow) {
            # Stop before tree/admission. This bounded join cannot extend the
            # original sample/collector deadline or create later exit grace.
            $stopDeadline = [Math]::Min($sampleAt + $frequency, $CollectorDeadlineAtQpc)
            $remaining = [Math]::Max(0L, $stopDeadline - [Diagnostics.Stopwatch]::GetTimestamp())
            $budget = [int] [Math]::Min(250L, [long] [Math]::Floor($remaining * 1000.0 / $frequency))
            foreach ($item in $nativeWindow.Complete($budget)) {
                if (-not $earlyPins.ContainsKey($item.Pid)) {
                    $earlyPins[$item.Pid] = @{ handle = $item.Handle; provenance = $item.Provenance; failure = $(if ($null -ne $item.NativeError) {
                        [ComponentModel.Win32Exception]::new($item.NativeError)
                    } else { $null }) }
                }
            }
        }
        $rows = @($inventory.ToArray())
        $stage = 'tree'; $byId = @{}
        if (@($rows).Count -gt 8192) { throw 'Process inventory limit.' }
        foreach ($row in $rows) {
            $id = [uint32] $row.ProcessId
            if ($byId.ContainsKey($id)) { throw 'Duplicate process identity.' }
            $byId[$id] = $row
        }
        $tree = if ($byId.ContainsKey($Root)) { @(Get-NativeTree $rows $Root $RootTicks) } else { @() }
        # Previously verified descendants remain owned after a parent exits.
        # New descendants still need a current, live, verified parent admission.
        $candidates = [Collections.Generic.List[object]]::new(); $selected = @{}
        foreach ($row in $tree) { $candidates.Add(@{ row = $row; source = 'cim' }); $selected[[uint32] $row.ProcessId] = $true }
        # A verified child may outlive its parent and then launch another child.
        # Seed discovery from that child's current identity and retained live
        # handle; a missing/reused PID or exited handle cannot authorize a tree.
        foreach ($id in @($cache.Keys)) {
            if ($selected.ContainsKey($id) -or -not $byId.ContainsKey($id)) { continue }
            $known = $cache[$id]; $row = $byId[$id]; $parentId = [uint32] $row.ParentProcessId
            if (-not $known.seen -or $known.parentPid -ne $parentId -or
                -not (Test-NativeCreation $known.ticks $known.ticks $row.CreationDate.ToUniversalTime().Ticks) -or
                ($id -ne $Root -and $byId.ContainsKey($parentId) -and
                    -not (Test-NativeCreation $known.parentTicks $known.parentTicks $byId[$parentId].CreationDate.ToUniversalTime().Ticks)) -or
                $known.process.HasExited) { continue }
            foreach ($descendant in @(Get-NativeTree $rows $id $known.ticks)) {
                $descendantId = [uint32] $descendant.ProcessId
                if ($selected.ContainsKey($descendantId)) { continue }
                if ($candidates.Count -ge 64) { throw 'Descendant limit.' }
                $candidates.Add(@{ row = $descendant; source = 'cim' }); $selected[$descendantId] = $true
            }
        }
        foreach ($id in @($cache.Keys)) {
            if ($selected.ContainsKey($id)) { continue }
            $known = $cache[$id]
            $row = if ($byId.ContainsKey($id)) { $byId[$id] } else {
                @{ ProcessId = $id; ParentProcessId = $known.parentPid; CreationDate = [DateTime]::new($known.cimTicks, [DateTimeKind]::Utc) }
            }
            $candidates.Add(@{ row = $row; source = $(if ($byId.ContainsKey($id)) { 'cim' } else { 'retained' }) })
        }
        if ($candidates.Count -gt 64) { throw 'Descendant limit.' }
        $sample.hasSnapshot = $true; $rejected = @{}
        if (-not $rootExited -and -not $byId.ContainsKey($Root)) {
            $row = @{ ProcessId = $Root; ParentProcessId = $rootEntry.parentPid; CreationDate = [DateTime]::new($rootEntry.cimTicks, [DateTimeKind]::Utc) }
            Add-NativeObservationFailure $sample $row $Root retained processUnavailable inventory
            $rejected[$Root] = $true
        }
        if ($ObservationBarrier) { [void] (& $ObservationBarrier 'snapshot' $null) }
        # Preserve handles for current children of already-verified live parents
        # before any sibling's managed admission. A failed first open is retained
        # verbatim; it is never reopened or inferred to be a normal exit.
        $earlyPins = New-NativeAdmissionPins $candidates $Root $cache $rejected $byId $AcquireIdentity $earlyPins
        if ($ObservationBarrier) { [void] (& $ObservationBarrier 'admissionPinned' $null) }
        $admitted = [Collections.Generic.List[object]]::new()
        # Fixed once for the whole admission loop, never reset per PID. Pending
        # exit-zero settling is clipped to this sample and original collector.
        $admissionAt = [Diagnostics.Stopwatch]::GetTimestamp()
        $admissionDeadline = [Math]::Min($admissionAt + [long] [Math]::Floor($frequency / 4.0),
            [Math]::Min($sampleAt + $frequency, $CollectorDeadlineAtQpc))
        # Admit every handle before reading any counters, reducing the CIM-to-
        # handle race without weakening failures for a first-seen missing child.
        foreach ($candidate in $candidates) {
            $row = $candidate.row; $id = [uint32] $row.ProcessId; $parentId = [uint32] $row.ParentProcessId
            if ($rejected.ContainsKey($id)) { continue }
            $skipReason = 'counterReadFailed'; $failureStage = 'identity'; $newProcess = $null; $identityHandle = $null
            $proofDiagnostics = $null; $proofExitCode = $null; $acquisition = $null
            try {
                if ($cache.ContainsKey($id)) {
                    $known = $cache[$id]
                    if (-not (Test-NativeCreation $known.ticks $known.ticks $row.CreationDate.ToUniversalTime().Ticks) -or
                        ($known.seen -and $known.parentPid -ne $parentId)) {
                        $skipReason = 'identityMismatch'; throw 'Changed cached identity.'
                    }
                    if ($id -eq $Root -and -not $known.seen) { $known.parentPid = $parentId }
                } else {
                    $failureStage = 'parent'; $skipReason = 'parentUnavailable'
                    if (-not $cache.ContainsKey($parentId) -or $rejected.ContainsKey($parentId)) { throw 'Parent was not verified.' }
                    $parent = $cache[$parentId]; $skipReason = 'parentExited'
                    if ($parent.process.HasExited) { throw 'Parent exited before child admission.' }
                    if ($cache.Count -ge 64) { $failureStage = 'inventory'; $skipReason = 'counterReadFailed'; throw 'Handle cache limit.' }
                    $failureStage = 'parent'; $skipReason = 'parentUnavailable'; $parentTicks = [long] $parent.ticks
                    if ($candidate.source -ne 'cim') { throw 'New child requires current inventory.' }
                    $parentState = Get-NativeProofParentState $parent $parentId $parentTicks $cache $rejected $byId
                    if ($parentState -ne 'valid') { $skipReason = $parentState; throw 'Acquisition parent is not live and verified.' }
                    # Pin once before .NET's temporary IsProcessRunning handle.
                    # The first native open failure stays a gap, with no retry.
                    $failureStage = 'nativeAcquire'; $skipReason = 'processUnavailable'
                    if ($earlyPins.ContainsKey($id)) {
                        $earlyPin = $earlyPins[$id]; [void] $earlyPins.Remove($id)
                        $acquisition = $earlyPin.provenance
                        $identityHandle = $earlyPin.handle
                        if ($earlyPin.failure) { throw $earlyPin.failure }
                    } else {
                        $first = Invoke-NativeAcquisition $id $AcquireIdentity 'admission'
                        $acquisition = $first.provenance; $identityHandle = $first.handle
                        if ($first.failure) { throw $first.failure }
                    }
                    if ($ObservationBarrier) { [void] (& $ObservationBarrier 'identityProof' $id) }
                    $pin = [MorrowObservationIdentity.ExitProof]::ReadHandle($identityHandle, $id, $row.CreationDate.ToUniversalTime().Ticks, $parentTicks)
                    if (-not $pin.IdentityMatched -or $pin.Outcome -notin @('alive', 'zeroExit', 'nonzeroExit')) {
                        $failureStage = switch ($pin.Stage) {
                            'pid' { 'nativePid' }; 'creation' { 'nativeCreation' }; 'wait' { 'nativeWait' }; 'exit' { 'nativeExit' }; default { 'nativeProof' }
                        }
                        $skipReason = if ($pin.Outcome -eq 'identityMismatch') { 'identityMismatch' } else { 'processUnavailable' }
                        $nativeFailure = if ($null -ne $pin.NativeError) { [ComponentModel.Win32Exception]::new($pin.NativeError) } else { $null }
                        $rejected[$id] = $true
                        Add-NativeObservationFailure $sample $row $Root $candidate.source $skipReason $failureStage $nativeFailure $pin.ExitCode
                        continue
                    }
                    $failureStage = 'parent'; $skipReason = 'parentUnavailable'
                    $parentState = Get-NativeProofParentState $parent $parentId $parentTicks $cache $rejected $byId
                    if ($parentState -ne 'valid') { $skipReason = $parentState; throw 'Acquisition parent changed during identity proof.' }
                    if ($ObservationBarrier) { [void] (& $ObservationBarrier 'nativePinned' $id) }
                    $failureStage = 'lookup'; $skipReason = 'processUnavailable'
                    if ($ObservationBarrier) { [void] (& $ObservationBarrier 'beforeLookup' $id) }
                    try { $newProcess = if ($LookupProcess) { & $LookupProcess $id } else { [Diagnostics.Process]::GetProcessById($id) } }
                    catch {
                        $lookupFailure = $_.Exception
                        while ($lookupFailure.InnerException) { $lookupFailure = $lookupFailure.InnerException }
                        if ($lookupFailure -isnot [ArgumentException] -or $candidate.source -ne 'cim' -or $id -eq $Root) { throw }
                        # .NET can reject an exit-zero process before its native
                        # handle signals. Only initial native code zero permits
                        # bounded settling through the same original pin.
                        # This narrow fallback never hides handle/counter errors.
                        $failureStage = 'parent'; $skipReason = 'parentUnavailable'
                        $parentState = Get-NativeProofParentState $parent $parentId $parentTicks $cache $rejected $byId
                        if ($parentState -ne 'valid') { $skipReason = $parentState; throw 'Exit proof parent is not live and verified.' }
                        $failureStage = 'nativeProof'; $skipReason = 'processUnavailable'
                        $proof = if ($ReadLookupProof) {
                            & $ReadLookupProof $identityHandle $id $row.CreationDate.ToUniversalTime().Ticks $parentTicks $pin.StartUtcTicks $admissionDeadline
                        } else {
                            [MorrowObservationIdentity.ExitProof]::ReadLookupHandle($identityHandle, $id,
                                $row.CreationDate.ToUniversalTime().Ticks, $parentTicks, $pin.StartUtcTicks, $admissionDeadline)
                        }
                        $proofExitCode = $proof.ExitCode
                        $proofDiagnostics = ConvertTo-NativeLookupProof $proof $parentTicks $sampleAt $admissionAt $CollectorDeadlineAtQpc
                        if ($ObservationBarrier) { [void] (& $ObservationBarrier 'exitProof' $parent.process) }
                        $parentState = Get-NativeProofParentState $parent $parentId $parentTicks $cache $rejected $byId
                        $proofDiagnostics.parentAfter = $parentState
                        if ($proof.WaitAttempted) {
                            # The parent recheck belongs to the same admission,
                            # and cannot extend its absolute settling budget.
                            $proofDiagnostics.completedAtQpc = [Math]::Max($proof.CompletedAtQpc, [Diagnostics.Stopwatch]::GetTimestamp())
                            $proofDiagnostics.durationMs = ($proofDiagnostics.completedAtQpc - $proof.StartedAtQpc) * 1000.0 / $frequency
                            $proofDiagnostics.deadlineExceeded = $proofDiagnostics.completedAtQpc -ge $admissionDeadline
                            if ($proofDiagnostics.deadlineExceeded -and $proof.ProvenZero) { $proofDiagnostics.outcome = 'deadlineExpired' }
                        }
                        if ($parentState -ne 'valid') {
                            $failureStage = 'parent'; $skipReason = $parentState
                            throw 'Exit proof parent changed during proof.'
                        }
                        if ($proof.ProvenZero -and -not $proofDiagnostics.deadlineExceeded) {
                            $sample.lifecycleEvents.Add([ordered]@{ pid = $id; parentPid = $parentId; startUtcTicks = [long] $proof.Final.StartUtcTicks
                                role = 'other'; exitCode = 0; phase = 'beforeCounters'; source = 'cim'; identitySource = 'nativeLookupFallback'
                                nativeProof = $proofDiagnostics })
                            # No live cache entry, counter, or descendant-root
                            # authority is created for this already-exited PID.
                            continue
                        }
                        $failureStage = switch ($(if ($proofDiagnostics.outcome -eq 'deadlineExpired') { 'wait' } else { $proof.Stage })) {
                            'open' { 'nativeOpen' }; 'pid' { 'nativePid' }; 'creation' { 'nativeCreation' }
                            'wait' { 'nativeWait' }; 'exit' { 'nativeExit' }; default { 'nativeProof' }
                        }
                        $skipReason = if ($proofDiagnostics.outcome -eq 'identityMismatch') { 'identityMismatch' }
                            elseif ($proofDiagnostics.outcome -eq 'nonzeroExit') { 'processExited' } else { 'processUnavailable' }
                        $nativeFailure = if ($null -ne $proof.NativeError) { [ComponentModel.Win32Exception]::new($proof.NativeError) } else { $null }
                        $rejected[$id] = $true
                        Add-NativeObservationFailure $sample $row $Root $candidate.source $skipReason $failureStage $nativeFailure $proof.ExitCode $proofDiagnostics
                        continue
                    }
                    $failureStage = 'handle'; [void] $newProcess.Handle
                    $failureStage = 'identity'; $skipReason = 'counterReadFailed'
                    $ticks = $newProcess.StartTime.ToUniversalTime().Ticks
                    if ($ticks -ne $pin.StartUtcTicks -or -not (Test-NativeCreation $ticks $ticks $row.CreationDate.ToUniversalTime().Ticks) -or $ticks -lt $parentTicks) {
                        $skipReason = 'identityMismatch'; throw 'Changed process identity.'
                    }
                    $failureStage = 'role'
                    $role = if ($newProcess.ProcessName -ieq 'morrow-service') { 'service' } elseif ($newProcess.ProcessName -ieq 'msedgewebview2') { 'webview' } else { 'other' }
                    $known = @{ process = $newProcess; ticks = $ticks; parentPid = $parentId; parentTicks = $parent.ticks
                        cimTicks = $row.CreationDate.ToUniversalTime().Ticks; role = $role; exitRecorded = $false; seen = $false }
                    $cache[$id] = $known; $newProcess = $null
                }
                if ($id -ne $Root -and $byId.ContainsKey($parentId) -and
                    -not (Test-NativeCreation $known.parentTicks $known.parentTicks $byId[$parentId].CreationDate.ToUniversalTime().Ticks)) {
                    $skipReason = 'identityMismatch'; throw 'Changed parent identity.'
                }
                if ($ObservationBarrier) { [void] (& $ObservationBarrier 'identified' $known.process) }
                $identitySource = if ($known.seen) { 'priorSnapshot' } else { 'currentSnapshot' }
                if ($candidate.source -eq 'cim') { $known.cimTicks = $row.CreationDate.ToUniversalTime().Ticks }
                $known.seen = $true; $admitted.Add(@{ row = $row; source = $candidate.source; identitySource = $identitySource; entry = $known })
            } catch {
                $rejected[$id] = $true
                Add-NativeObservationFailure $sample $row $Root $candidate.source $skipReason $failureStage $_.Exception $proofExitCode $proofDiagnostics $acquisition
            } finally {
                try { if ($newProcess) { $newProcess.Dispose() } }
                finally { if ($identityHandle) { $identityHandle.Dispose() } }
            }
        }
        foreach ($item in $admitted) {
            $known = $item.entry; $process = $known.process; $row = $item.row; $id = [uint32] $row.ProcessId
            $failureStage = 'exit'; $skipReason = 'counterReadFailed'; $exitCode = $null
            try {
                $phase = 'beforeCounters'; $exited = $process.HasExited
                if (-not $exited) {
                    $failureStage = 'counters'; $process.Refresh()
                    $counters = if ($ReadCounters) { & $ReadCounters $process } else { Read-NativeProcessCounters $process }
                    $entries.Add([ordered]@{ pid = $id; parentPid = [uint32] $known.parentPid; startUtcTicks = $known.ticks; role = $known.role
                        workingSetBytes = $counters.workingSetBytes; privateBytes = $counters.privateBytes; cpuMs = $counters.cpuMs })
                    $failureStage = 'exit'; $phase = 'afterCounters'; $exited = $process.HasExited
                }
                if ($exited) {
                    $exitCode = $process.ExitCode; $skipReason = 'processExited'
                    if ($exitCode -ne 0) { throw 'Process exited unsuccessfully.' }
                    $sample.lifecycleEvents.Add([ordered]@{ pid = $id; parentPid = [uint32] $known.parentPid; startUtcTicks = $known.ticks
                        role = $known.role; exitCode = 0; phase = $phase; source = $item.source; identitySource = $item.identitySource })
                    $known.exitRecorded = $true
                }
            } catch {
                # Preserve the failing operation even if the same process exits
                # later. In particular an access denial never becomes normal.
                if ($null -eq $exitCode) { try { if ($process.HasExited) { $exitCode = $process.ExitCode } } catch { } }
                Add-NativeObservationFailure $sample $row $Root $item.source $skipReason $failureStage $_.Exception $exitCode
            }
        }
        $sample.rootExitedDuringSample = $rootEntry.process.HasExited
        if ($sample.rootExitedDuringSample) {
            $sample.terminalReason = if ($rootEntry.process.ExitCode -eq 0) { 0 } else { 3 }
            if ($sample.terminalReason -ne 0) { $sample.failureStage = 'root' }
            elseif (-not $sample.rootSkipped -and -not @($sample.lifecycleEvents | Where-Object { $_.pid -eq $Root }).Count) {
                $sample.lifecycleEvents.Add([ordered]@{ pid = $Root; parentPid = [uint32] $rootEntry.parentPid; startUtcTicks = $RootTicks
                    role = 'ui'; exitCode = 0; phase = 'afterSnapshot'; source = 'retained'; identitySource = $rootIdentitySource })
            }
        }
        foreach ($id in @($cache.Keys)) {
            if ($id -ne $Root -and $cache[$id].exitRecorded -and -not $byId.ContainsKey($id)) {
                $cache[$id].process.Dispose(); [void] $cache.Remove($id)
            }
        }
        $sample.processes = @($entries.ToArray())
    } catch { $sample.terminalReason = 3; $sample.failureStage = $stage }
    finally {
        if ($nativeWindow) { $nativeWindow.Dispose() }
        foreach ($pin in $earlyPins.Values) { if ($pin.handle) { $pin.handle.Dispose() } }
        $sample.lifecycleEvents = @($sample.lifecycleEvents.ToArray()); $sample.failedRecords = @($sample.failedRecords.ToArray())
        if ($ownsState) { Close-NativeObservationState $State }
    }
    return $sample
}

function Invoke-NativeResourceCollector {
    if (-not $IsWindows) { throw 'Windows observation only.' }
    $root = [uint32]::Parse($env:MORROW_SAMPLE_PID, [Globalization.CultureInfo]::InvariantCulture)
    $rootTicks = [long]::Parse($env:MORROW_SAMPLE_START, [Globalization.CultureInfo]::InvariantCulture)
    $launch = [long]::Parse($env:MORROW_SAMPLE_LAUNCH, [Globalization.CultureInfo]::InvariantCulture)
    if ($root -le 1 -or $rootTicks -le 0 -or $launch -le 0 -or $launch -gt [Diagnostics.Stopwatch]::GetTimestamp()) { throw 'Invalid observation identity.' }
    $file = Get-Item -LiteralPath $env:MORROW_SAMPLE_FILE
    $parent = $file.Directory
    if ($file.PSIsContainer -or $file.Length -ne 0 -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Name -cnotmatch '^native-resources-[0-9a-f]{32}\.jsonl$' -or
        $parent.Name -cnotmatch '^morrow-native-check-[0-9a-f]{32}$' -or
        $parent.Parent.FullName.TrimEnd('\', '/') -ine [IO.Path]::GetTempPath().TrimEnd('\', '/')) { throw 'Invalid observation file.' }
    # Existing caller-created protected file; no Create/Append/truncation fallback.
    $stream = [IO.File]::Open($file.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    $count = 0; $reason = 1; $failureStage = 'none'; $state = New-NativeObservationState $root $rootTicks
    try {
        while ($count -lt 180) {
            $at = [Diagnostics.Stopwatch]::GetTimestamp()
            $elapsed = ($at - $launch) * 1000.0 / [Diagnostics.Stopwatch]::Frequency
            if ($elapsed -ge 180000) { break }
            $stage = 'sample'
            try {
                $snapshot = Get-NativeProcessSnapshot $root $rootTicks -State $state -CollectorDeadlineAtQpc ($launch + 180L * [Diagnostics.Stopwatch]::Frequency)
                if (-not $snapshot.hasSnapshot) { $reason = $snapshot.terminalReason; $failureStage = $snapshot.failureStage; break }
                $finished = [Diagnostics.Stopwatch]::GetTimestamp()
                if (($finished - $launch) * 1000.0 / [Diagnostics.Stopwatch]::Frequency -ge 180000) { break }
                $sample = [ordered]@{ kind = 0; nativeProofVersion = 1; elapsedMs = $elapsed; queryMs = ($finished - $at) * 1000.0 / [Diagnostics.Stopwatch]::Frequency
                    skipped = $snapshot.skipped; rootSkipped = $snapshot.rootSkipped; rootExitedDuringSample = $snapshot.rootExitedDuringSample
                    skipReasonCounts = $snapshot.skipReasonCounts; processes = $snapshot.processes
                    lifecycleEvents = $snapshot.lifecycleEvents; failedRecords = $snapshot.failedRecords }
                if (-not (Write-NativeSample $stream $sample)) { $reason = 2; break }
                $count++
                if ($null -ne $snapshot.terminalReason) { $reason = $snapshot.terminalReason; $failureStage = $snapshot.failureStage; break }
            } catch { $reason = 3; $failureStage = $stage; break }
            # Best effort, no overlapping queries or catch-up burst. A query's
            # operation timeout is not a wall deadline; the parent owns final kill.
            $delay = 1000 - ([Diagnostics.Stopwatch]::GetTimestamp() - $at) * 1000.0 / [Diagnostics.Stopwatch]::Frequency
            if ($delay -gt 0) { Start-Sleep -Milliseconds ([int] $delay) }
        }
        [void] (Write-NativeSample $stream @{ kind = 1; reason = $reason; samples = $count; failureStage = $failureStage })
    } finally { Close-NativeObservationState $state; $stream.Dispose() }
}

function Assert-NativeLookupProof($Proof, $Record, [bool] $IsExitEvent) {
    $proofKeys = 'admissionStartedAtQpc,clockFrequency,collectorDeadlineAtQpc,completedAtQpc,deadlineAtQpc,deadlineExceeded,durationMs,final,initial,outcome,parentAfter,parentBefore,parentStartUtcTicks,pinnedStartUtcTicks,projection,sampleStartedAtQpc,settlingError,settlingWait,startedAtQpc,waitAttempted'
    if ($Proof -isnot [Collections.IDictionary] -or (($Proof.Keys | Sort-Object) -join ',') -cne $proofKeys -or
        $Record.source -cne 'cim' -or $Record.parentPid -le 1 -or $Record.parentPid -eq $Record.pid -or
        $Proof.parentBefore -cne 'valid' -or $Proof.parentAfter -cnotin @('valid', 'parentUnavailable', 'parentExited', 'identityMismatch')) { throw 'Invalid native proof fields.' }
    foreach ($key in @('pinnedStartUtcTicks', 'parentStartUtcTicks', 'clockFrequency', 'sampleStartedAtQpc',
            'admissionStartedAtQpc', 'collectorDeadlineAtQpc', 'startedAtQpc', 'completedAtQpc', 'deadlineAtQpc')) {
        if ($Proof[$key] -isnot [long] -or $Proof[$key] -le 0) { throw 'Invalid native proof integer.' }
    }
    foreach ($key in @('waitAttempted', 'deadlineExceeded', 'projection')) {
        if ($Proof[$key] -isnot [bool]) { throw 'Invalid native proof boolean.' }
    }
    # A fixture projection demonstrates the validator, never native collector
    # acceptance. Production has no switch that can produce this flag.
    if ($Proof.projection -or $Proof.clockFrequency -gt 10000000000L -or
        $Proof.parentStartUtcTicks -gt $Proof.pinnedStartUtcTicks -or $Proof.pinnedStartUtcTicks -gt [DateTime]::MaxValue.Ticks -or
        $Proof.sampleStartedAtQpc -gt $Proof.admissionStartedAtQpc -or $Proof.admissionStartedAtQpc -gt $Proof.startedAtQpc -or
        $Proof.startedAtQpc -gt $Proof.completedAtQpc) { throw 'Invalid native proof identity or clock.' }
    $frequency = [decimal] $Proof.clockFrequency
    $deadlineLimit = [Math]::Min([decimal] $Proof.admissionStartedAtQpc + [decimal]::Floor($frequency / 4),
        [Math]::Min([decimal] $Proof.sampleStartedAtQpc + $frequency, [decimal] $Proof.collectorDeadlineAtQpc))
    if ($Proof.deadlineAtQpc -gt $deadlineLimit -or
        [decimal] $Proof.collectorDeadlineAtQpc - $Proof.sampleStartedAtQpc -gt 180 * $frequency -or
        $Proof.durationMs -isnot [ValueType] -or $Proof.durationMs -is [bool] -or -not [double]::IsFinite($Proof.durationMs) -or
        $Proof.durationMs -lt 0 -or $Proof.durationMs -gt 180000 -or
        [Math]::Abs($Proof.durationMs - [double](1000 * ([decimal] $Proof.completedAtQpc - $Proof.startedAtQpc) / $frequency)) -gt 0.001) { throw 'Invalid native proof deadline.' }
    foreach ($key in @('settlingWait', 'settlingError')) {
        if ($null -ne $Proof[$key] -and ($Proof[$key] -isnot [long] -or $Proof[$key] -lt 0 -or
            $Proof[$key] -gt $(if ($key -eq 'settlingWait') { [uint32]::MaxValue } else { [int]::MaxValue }))) { throw 'Invalid native settling status.' }
    }
    $reads = @($Proof.initial)
    if ($null -ne $Proof.final) { $reads += $Proof.final }
    foreach ($read in $reads) {
        if ($read -isnot [Collections.IDictionary] -or (($read.Keys | Sort-Object) -join ',') -cne
            'actualPid,exitCode,identityMatched,nativeError,outcome,signaled,stage,startUtcTicks,waitStatus' -or
            $read.identityMatched -isnot [bool] -or $read.signaled -isnot [bool] -or
            $read.stage -cnotin @('input', 'handle', 'pid', 'creation', 'wait', 'exit') -or
            $read.outcome -cnotin @('invalidInput', 'unavailable', 'accessDenied', 'identityMismatch', 'invalidIdentity',
                'alive', 'invalidWait', 'pendingZero', 'zeroExit', 'nonzeroExit')) { throw 'Invalid native proof read.' }
        foreach ($key in @('actualPid', 'startUtcTicks', 'waitStatus', 'nativeError', 'exitCode')) {
            if ($null -ne $read[$key] -and $read[$key] -isnot [long]) { throw 'Invalid native proof read integer.' }
        }
        if (($null -ne $read.actualPid -and ($read.actualPid -le 1 -or $read.actualPid -gt [uint32]::MaxValue)) -or
            ($null -ne $read.startUtcTicks -and ($read.startUtcTicks -le 0 -or $read.startUtcTicks -gt [DateTime]::MaxValue.Ticks)) -or
            ($null -ne $read.waitStatus -and ($read.waitStatus -lt 0 -or $read.waitStatus -gt [uint32]::MaxValue)) -or
            ($null -ne $read.nativeError -and ($read.nativeError -lt 0 -or $read.nativeError -gt [int]::MaxValue)) -or
            ($null -ne $read.exitCode -and ($read.exitCode -lt [int]::MinValue -or $read.exitCode -gt [int]::MaxValue))) { throw 'Invalid native proof read range.' }
        if ($read.identityMatched -and ($read.actualPid -ne $Record.pid -or $read.startUtcTicks -ne $Proof.pinnedStartUtcTicks)) { throw 'Native pin changed.' }
        if (($read.signaled -and $read.waitStatus -ne 0) -or
            ($null -ne $read.waitStatus -and (($read.waitStatus -eq 0) -ne $read.signaled))) { throw 'Native wait and signal disagree.' }
        if ($read.waitStatus -eq 4294967295L -and ($null -eq $read.nativeError -or $read.stage -ne 'wait' -or $null -ne $read.exitCode)) { throw 'Missing WAIT_FAILED error.' }
        if ($null -ne $read.nativeError -and ($read.outcome -notin @('accessDenied', 'unavailable') -or
            $read.stage -notin @('pid', 'creation', 'wait', 'exit') -or $null -ne $read.exitCode -or
            (($read.nativeError -eq 5) -ne ($read.outcome -eq 'accessDenied')) -or
            ($read.stage -eq 'wait' -and $read.waitStatus -ne 4294967295L) -or
            ($read.stage -eq 'exit' -and $read.waitStatus -notin @(0L, 258L)))) { throw 'Invalid native API error.' }
        switch ($read.outcome) {
            'zeroExit' { if (-not $read.identityMatched -or $read.waitStatus -ne 0 -or $read.exitCode -ne 0 -or $null -ne $read.nativeError) { throw 'Invalid native zero exit.' } }
            'pendingZero' { if (-not $read.identityMatched -or $read.waitStatus -ne 258 -or $read.exitCode -ne 0 -or $null -ne $read.nativeError) { throw 'Invalid native pending zero.' } }
            'nonzeroExit' { if ($read.waitStatus -notin @(0L, 258L) -or $null -eq $read.exitCode -or $read.exitCode -eq 0 -or $null -ne $read.nativeError) { throw 'Invalid native nonzero exit.' } }
            'alive' { if ($read.waitStatus -ne 258 -or ($null -ne $read.exitCode -and $read.exitCode -ne 259) -or $null -ne $read.nativeError) { throw 'Invalid native live status.' } }
            'invalidWait' { if ($null -eq $read.waitStatus -or $read.waitStatus -in @(0L, 258L, 4294967295L) -or $null -ne $read.exitCode -or $null -ne $read.nativeError) { throw 'Invalid unexpected wait.' } }
        }
    }
    $initial = $Proof.initial; $final = $Proof.final
    if ($null -ne $final -and ($final.outcome -eq 'pendingZero' -or ($final.waitStatus -eq 258 -and $null -ne $final.exitCode))) { throw 'Final proof must be a native read.' }
    if ($Proof.waitAttempted) {
        if ($initial.outcome -ne 'pendingZero' -or $initial.waitStatus -ne 258 -or $initial.exitCode -ne 0 -or
            $null -ne $initial.nativeError -or $null -eq $Proof.settlingWait -or $Proof.startedAtQpc -ge $Proof.deadlineAtQpc -or
            (($Proof.settlingWait -eq 4294967295L) -ne ($null -ne $Proof.settlingError)) -or
            (($Proof.settlingWait -eq 0) -ne ($null -ne $final)) -or
            ($Proof.deadlineExceeded -ne ($Proof.completedAtQpc -ge $Proof.deadlineAtQpc))) { throw 'Invalid settling qualification.' }
    } elseif ($null -ne $Proof.settlingWait -or $null -ne $Proof.settlingError -or
        ($null -ne $final -and $initial.outcome -ne 'zeroExit') -or
        ($Proof.deadlineExceeded -and ($initial.outcome -ne 'pendingZero' -or $Proof.completedAtQpc -lt $Proof.deadlineAtQpc))) { throw 'Invalid no-wait proof.' }
    if ($Proof.outcome -cnotin @('invalidInput', 'unavailable', 'accessDenied', 'identityMismatch', 'invalidIdentity',
        'alive', 'invalidWait', 'zeroExit', 'nonzeroExit', 'deadlineExpired')) { throw 'Invalid native lookup outcome.' }
    $expectedOutcome = if ($null -ne $final) {
        if ($final.outcome -eq 'zeroExit' -and $Proof.deadlineExceeded) { 'deadlineExpired' } else { $final.outcome }
    } elseif ($Proof.waitAttempted) {
        if ($Proof.settlingWait -eq 258) { 'alive' } elseif ($Proof.settlingWait -eq 4294967295L) {
            if ($Proof.settlingError -eq 5) { 'accessDenied' } else { 'unavailable' }
        } else { 'invalidWait' }
    } elseif ($initial.outcome -eq 'pendingZero') { 'deadlineExpired' } else { $initial.outcome }
    if ($Proof.outcome -cne $expectedOutcome) { throw 'Native lookup outcome does not match raw evidence.' }
    $childZero = $null -ne $final -and $final.outcome -eq 'zeroExit' -and $final.identityMatched -and
        $final.actualPid -eq $Record.pid -and $final.startUtcTicks -eq $Proof.pinnedStartUtcTicks -and
        $final.waitStatus -eq 0 -and $final.exitCode -eq 0 -and $null -eq $final.nativeError
    if ($Proof.outcome -eq 'zeroExit' -and (-not $childZero -or $Proof.deadlineExceeded -or
        ($Proof.waitAttempted -and ($Proof.settlingWait -ne 0 -or $Proof.completedAtQpc -ge $Proof.deadlineAtQpc)))) { throw 'Unproven native zero exit.' }
    if ($Proof.outcome -eq 'deadlineExpired' -and (-not $Proof.deadlineExceeded -or
        ($null -ne $final -and -not $childZero) -or $initial.outcome -ne 'pendingZero')) { throw 'Invalid expired native proof.' }
    $accepted = $Proof.outcome -eq 'zeroExit' -and $childZero -and $Proof.parentAfter -eq 'valid'
    if ($IsExitEvent) {
        if (-not $accepted -or $Record.identitySource -ne 'nativeLookupFallback' -or $Record.startUtcTicks -ne $Proof.pinnedStartUtcTicks) { throw 'Invalid native proof event.' }
    } else {
        if ($accepted -or -not [MorrowObservationIdentity.ExitProof]::MatchesCreation($Proof.pinnedStartUtcTicks,
            $Record.cimStartUtcTicks, $Proof.parentStartUtcTicks) -or $Record.stage -notin @('parent', 'nativeProof', 'nativePid', 'nativeCreation', 'nativeWait', 'nativeExit')) { throw 'Invalid native proof failure.' }
        $expectedExit = if ($null -ne $final) { $final.exitCode } elseif (-not $Proof.waitAttempted -and $Proof.outcome -ne 'deadlineExpired') { $initial.exitCode } else { $null }
        if ($Record.exitCode -ne $expectedExit) { throw 'Native failure exit does not match.' }
        if ($Record.stage -ne 'parent') {
            $expectedError = if ($null -ne $Proof.settlingError) { $Proof.settlingError } elseif ($null -ne $final) { $final.nativeError } else { $initial.nativeError }
            if ($Record.errorCode -ne $expectedError -or
                ($null -eq $expectedError -and $Record.errorKind -ne 'none') -or
                ($null -ne $expectedError -and $Record.errorKind -ne $(if ($expectedError -eq 5) { 'accessDenied' } else { 'native' }))) { throw 'Native failure error does not match.' }
        }
    }
}

function Get-NativeProofClock($Proof) {
    # Called only after strict Int64 validation. These values are fixed before
    # admission and must be identical across successes AND failures in a sample.
    return (@('clockFrequency', 'sampleStartedAtQpc', 'admissionStartedAtQpc', 'collectorDeadlineAtQpc', 'deadlineAtQpc') |
        ForEach-Object { $Proof[$_].ToString([Globalization.CultureInfo]::InvariantCulture) }) -join ','
}

function Assert-NativeAcquisition($Value, $Failure) {
    $keys = 'cimReceivedAtQpc,clockFrequency,nativeError,openCompletedAtQpc,openStartedAtQpc,priorScan,priorScanCompletedAtQpc,scan,scanStartedAtQpc,snapshotReadyAtQpc,source,version,windowStartedAtQpc,windowStoppedAtQpc,windowUtcReadCompletedAtQpc,windowUtcTicks'
    if ($Value -isnot [Collections.IDictionary] -or (($Value.Keys | Sort-Object) -join ',') -cne $keys -or
        $Value.version -isnot [long] -or $Value.version -ne 1 -or
        $Value.source -cnotin @('initial-scan', 'worker-scan', 'cim-row', 'admission') -or
        $Failure.source -cne 'cim' -or $Failure.stage -cne 'nativeAcquire' -or
        $Failure.reason -cne 'processUnavailable' -or $null -ne $Failure.exitCode -or $Failure.ContainsKey('nativeProof')) {
        throw 'Invalid acquisition provenance fields.'
    }
    foreach ($key in @('clockFrequency', 'windowStartedAtQpc', 'windowStoppedAtQpc', 'scan', 'scanStartedAtQpc',
            'snapshotReadyAtQpc', 'openStartedAtQpc', 'openCompletedAtQpc', 'cimReceivedAtQpc',
            'windowUtcTicks', 'windowUtcReadCompletedAtQpc', 'priorScan', 'priorScanCompletedAtQpc')) {
        if ($Value[$key] -isnot [long] -or $Value[$key] -lt 0) { throw 'Invalid acquisition provenance integer.' }
    }
    if (($null -ne $Value.nativeError -and ($Value.nativeError -isnot [long] -or $Value.nativeError -le 0 -or $Value.nativeError -gt [int]::MaxValue)) -or
        $Value.nativeError -ne $Failure.errorCode) { throw 'Acquisition error changed.' }
    if ($Value.clockFrequency -le 0 -or $Value.clockFrequency -gt 10000000000L -or
        $Value.openStartedAtQpc -le 0 -or $Value.openCompletedAtQpc -lt $Value.openStartedAtQpc -or
        [decimal] $Value.openCompletedAtQpc - $Value.openStartedAtQpc -gt 180 * [decimal] $Value.clockFrequency -or
        $Value.scan -gt 180000 -or $Value.priorScan -gt 180000) { throw 'Invalid acquisition provenance clock.' }
    if ($Value.windowStartedAtQpc -eq 0) {
        if ($Value.windowStoppedAtQpc -ne 0 -or $Value.scan -ne 0 -or $Value.scanStartedAtQpc -ne 0 -or
            $Value.snapshotReadyAtQpc -ne 0 -or $Value.windowUtcTicks -ne 0 -or $Value.windowUtcReadCompletedAtQpc -ne 0 -or
            $Value.priorScan -ne 0 -or $Value.priorScanCompletedAtQpc -ne 0 -or $Value.source -notin @('cim-row', 'admission')) { throw 'Invalid acquisition window.' }
    } else {
        if ($Value.source -eq 'admission' -or $Value.windowStoppedAtQpc -lt $Value.openCompletedAtQpc -or
            $Value.openStartedAtQpc -lt $Value.windowStartedAtQpc -or
            $Value.windowUtcTicks -le 0 -or $Value.windowUtcTicks -gt [DateTime]::MaxValue.Ticks -or
            $Value.windowUtcReadCompletedAtQpc -lt $Value.windowStartedAtQpc -or $Value.windowUtcReadCompletedAtQpc -gt $Value.openStartedAtQpc -or
            [decimal] $Value.windowStoppedAtQpc - $Value.windowStartedAtQpc -gt 180 * [decimal] $Value.clockFrequency -or
            ($Value.cimReceivedAtQpc -ne 0 -and ($Value.cimReceivedAtQpc -lt $Value.windowStartedAtQpc -or
                $Value.cimReceivedAtQpc -gt $Value.windowStoppedAtQpc))) { throw 'Invalid acquisition window clocks.' }
        if ($Value.source -in @('initial-scan', 'worker-scan')) {
            if ($Value.scan -lt 1 -or ($Value.source -eq 'initial-scan' -and $Value.scan -ne 1) -or
                ($Value.source -eq 'worker-scan' -and $Value.scan -lt 2) -or
                $Value.scanStartedAtQpc -lt $Value.windowUtcReadCompletedAtQpc -or $Value.snapshotReadyAtQpc -lt $Value.scanStartedAtQpc -or
                $Value.openStartedAtQpc -lt $Value.snapshotReadyAtQpc) { throw 'Invalid acquisition scan clocks.' }
        } elseif ($Value.scan -ne 0 -or $Value.scanStartedAtQpc -ne 0 -or $Value.snapshotReadyAtQpc -ne 0) { throw 'Invalid row acquisition scan.' }
    }
    if (($Value.priorScan -eq 0 -and $Value.priorScanCompletedAtQpc -ne 0) -or
        ($Value.priorScan -gt 0 -and ($Value.priorScanCompletedAtQpc -lt $Value.windowUtcReadCompletedAtQpc -or
            $Value.priorScanCompletedAtQpc -gt $Value.openStartedAtQpc -or
            ($Value.scan -gt 0 -and ($Value.priorScan -ge $Value.scan -or
                $Value.priorScanCompletedAtQpc -gt $Value.scanStartedAtQpc))))) { throw 'Invalid preceding scan clock.' }
    if (($Value.source -eq 'cim-row' -and ($Value.cimReceivedAtQpc -le 0 -or $Value.cimReceivedAtQpc -gt $Value.openStartedAtQpc)) -or
        ($Value.source -eq 'admission' -and $Value.cimReceivedAtQpc -ne 0)) { throw 'Invalid acquisition row clock.' }
}

function Read-NativeResourceReport([string] $Path, $Stop, $Milestones) {
    $samples = [Collections.Generic.List[object]]::new(); $footer = $null; $invalid = $false; $partial = $false
    $peakWs = 0L; $peakPrivate = 0L; $lastElapsed = -1.0; $gaps = $false
    $skipTotals = New-NativeSkipReasonCounts; $rootSkippedTotal = 0L; $unknownRootSkips = $false
    $normalExitObservations = 0L; $modernRecords = $false; $measuredRoot = $false
    $uiPids = @{}; $nativeLookupPids = @{}
    $extendedSampleKeys = (@('elapsedMs', 'kind', 'processes', 'queryMs', 'rootExitedDuringSample', 'rootSkipped', 'skipped', 'skipReasonCounts') | Sort-Object) -join ','
    $lifecycleSampleKeys = (@('elapsedMs', 'failedRecords', 'kind', 'lifecycleEvents', 'processes', 'queryMs', 'rootExitedDuringSample', 'rootSkipped', 'skipped', 'skipReasonCounts') | Sort-Object) -join ','
    $pinnedSampleKeys = (@('elapsedMs', 'failedRecords', 'kind', 'lifecycleEvents', 'nativeProofVersion', 'processes', 'queryMs', 'rootExitedDuringSample', 'rootSkipped', 'skipped', 'skipReasonCounts') | Sort-Object) -join ','
    try {
        $file = Get-Item -LiteralPath $Path
        if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Invalid observation file.' }
        $reader = [IO.BinaryReader]::new([IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read))
        try { $bytes = $reader.ReadBytes(2MB + 1) } finally { $reader.Dispose() }
        if ($bytes.Length -gt 2MB) { throw 'Observation limit.' }
        $end = [Array]::LastIndexOf($bytes, [byte] 10)
        $partial = $end -ne $bytes.Length - 1
        if ($end -ge 0) {
            $text = [Text.UTF8Encoding]::new($false, $true).GetString($bytes, 0, $end + 1)
            foreach ($line in $text.Split([char] 10)) {
                if (-not $line.Length) { continue }
                if ([Text.Encoding]::UTF8.GetByteCount($line) -gt 32KB -or $null -ne $footer) { throw 'Observation record limit.' }
                $row = ConvertFrom-Json -InputObject $line -AsHashtable
                if ($row.kind -eq 1) {
                    $keys = ($row.Keys | Sort-Object) -join ','
                    if ($keys -cnotin @('kind,reason,samples', 'failureStage,kind,reason,samples') -or $row.reason -isnot [long] -or $row.reason -lt 0 -or $row.reason -gt 4 -or $row.samples -ne $samples.Count) { throw 'Invalid observation footer.' }
                    $failureStage = if ($row.ContainsKey('failureStage')) { $row.failureStage } else { 'unclassified' }
                    if ($failureStage -cnotin @('none', 'root', 'cim', 'tree', 'sample', 'unclassified')) { throw 'Invalid observation stage.' }
                    $footer = @{ reason = $row.reason; samples = $row.samples; failureStage = $failureStage }; continue
                }
                $keys = ($row.Keys | Sort-Object) -join ','
                if ($samples.Count -eq 180 -or $row.kind -ne 0 -or $keys -cnotin @('elapsedMs,kind,processes,queryMs,skipped', $extendedSampleKeys, $lifecycleSampleKeys, $pinnedSampleKeys) -or
                    ($row.ContainsKey('nativeProofVersion') -and ($row.nativeProofVersion -isnot [long] -or $row.nativeProofVersion -ne 1))) { throw 'Invalid observation sample.' }
                foreach ($key in @('elapsedMs', 'queryMs', 'skipped')) {
                    if ($row[$key] -isnot [ValueType] -or $row[$key] -is [bool] -or -not [double]::IsFinite($row[$key]) -or $row[$key] -lt 0 -or $row[$key] -gt 180000) { throw 'Invalid observation number.' }
                }
                $skipCounts = New-NativeSkipReasonCounts; $rootSkipped = 0L; $rootExited = $null
                if ($row.skipped -isnot [long] -or $row.skipped -gt 64) { throw 'Invalid skipped count.' }
                if ($row.ContainsKey('skipReasonCounts')) {
                    if ($row.rootSkipped -isnot [long] -or $row.rootSkipped -lt 0 -or $row.rootSkipped -gt 1 -or $row.rootSkipped -gt $row.skipped -or
                        ($null -ne $row.rootExitedDuringSample -and $row.rootExitedDuringSample -isnot [bool]) -or
                        $row.skipReasonCounts -isnot [Collections.IDictionary] -or
                        (($row.skipReasonCounts.Keys | Sort-Object) -join ',') -cne (($skipCounts.Keys | Sort-Object) -join ',')) { throw 'Invalid skip reasons.' }
                    $sum = 0L
                    foreach ($key in @($skipCounts.Keys)) {
                        $value = $row.skipReasonCounts[$key]
                        if ($value -isnot [long] -or $value -lt 0 -or $value -gt 64) { throw 'Invalid skip reason count.' }
                        $skipCounts[$key] = $value; $sum += $value
                    }
                    if ($sum -ne $row.skipped) { throw 'Skip reasons do not match skipped count.' }
                    $rootSkipped = $row.rootSkipped
                    $rootExited = $row.rootExitedDuringSample
                } else {
                    $skipCounts.unclassified = $row.skipped
                    if ($row.skipped) { $rootSkipped = $null; $unknownRootSkips = $true }
                }
                if ($row.elapsedMs -lt $lastElapsed -or $row.processes -isnot [array] -or $row.processes.Count -gt 64) { throw 'Invalid observation sequence.' }
                $identities = @{}; $sumWs = 0L; $sumPrivate = 0L
                foreach ($item in $row.processes) {
                    if (($item.Keys | Sort-Object) -join ',' -cne 'cpuMs,parentPid,pid,privateBytes,role,startUtcTicks,workingSetBytes' -or $item.role -cnotin @('ui', 'service', 'webview', 'other')) { throw 'Invalid observation fields.' }
                    foreach ($key in @('pid', 'parentPid', 'startUtcTicks', 'workingSetBytes', 'privateBytes')) {
                        if ($item[$key] -isnot [long] -or $item[$key] -lt 0) { throw 'Invalid observation integer.' }
                    }
                    if ($item.pid -le 1 -or $item.pid -gt [uint32]::MaxValue -or $item.parentPid -gt [uint32]::MaxValue -or $item.startUtcTicks -le 0 -or $item.startUtcTicks -gt [DateTime]::MaxValue.Ticks -or
                        $item.workingSetBytes -gt 1PB -or $item.privateBytes -gt 1PB -or $item.cpuMs -isnot [ValueType] -or $item.cpuMs -is [bool] -or -not [double]::IsFinite($item.cpuMs) -or $item.cpuMs -lt 0 -or $item.cpuMs -gt 1e15 -or $identities.ContainsKey($item.pid)) { throw 'Invalid process observation.' }
                    $identities[$item.pid] = $item.startUtcTicks; $sumWs += $item.workingSetBytes; $sumPrivate += $item.privateBytes
                    if ($item.role -eq 'ui') { $measuredRoot = $true; $uiPids[$item.pid] = $true }
                }
                $events = @(); $failures = @()
                if ($row.ContainsKey('lifecycleEvents')) {
                    $modernRecords = $true; $events = $row.lifecycleEvents; $failures = $row.failedRecords
                    if ($events -isnot [array] -or $events.Count -gt 64 -or $failures -isnot [array] -or $failures.Count -ne $row.skipped) { throw 'Invalid lifecycle records.' }
                    $exited = @{}; $failed = @{}; $recordReasons = New-NativeSkipReasonCounts; $proofClock = $null
                    foreach ($event in $events) {
                        if (($event.Keys | Sort-Object) -join ',' -cnotin @('exitCode,identitySource,parentPid,phase,pid,role,source,startUtcTicks',
                                'exitCode,identitySource,nativeProof,parentPid,phase,pid,role,source,startUtcTicks') -or
                            $event.role -cnotin @('ui', 'service', 'webview', 'other') -or
                            $event.source -cnotin @('cim', 'retained') -or $event.identitySource -cnotin @('currentSnapshot', 'priorSnapshot', 'nativeLookupFallback') -or
                            $event.phase -cnotin @('beforeCounters', 'afterCounters', 'afterSnapshot') -or
                            $event.exitCode -isnot [long] -or $event.exitCode -ne 0) { throw 'Invalid lifecycle event.' }
                        if ($event.identitySource -eq 'nativeLookupFallback' -and
                            ($event.source -ne 'cim' -or $event.role -ne 'other' -or $event.phase -ne 'beforeCounters')) { throw 'Invalid native lookup proof event.' }
                        foreach ($key in @('pid', 'parentPid', 'startUtcTicks')) {
                            if ($event[$key] -isnot [long] -or $event[$key] -lt 0) { throw 'Invalid lifecycle identity.' }
                        }
                        if ($event.pid -le 1 -or $event.pid -gt [uint32]::MaxValue -or $event.parentPid -gt [uint32]::MaxValue -or
                            $event.startUtcTicks -le 0 -or $event.startUtcTicks -gt [DateTime]::MaxValue.Ticks -or $exited.ContainsKey($event.pid)) { throw 'Invalid lifecycle identity.' }
                        if ($event.role -eq 'ui') { $uiPids[$event.pid] = $true }
                        if ($event.identitySource -eq 'nativeLookupFallback') {
                            if ($event.parentPid -le 1 -or $event.pid -eq $event.parentPid) { throw 'Invalid lookup parent.' }
                            if ($row.ContainsKey('nativeProofVersion') -and -not $event.ContainsKey('nativeProof')) { throw 'Missing native lookup metadata.' }
                            $nativeLookupPids[$event.pid] = $true
                        }
                        if ($event.ContainsKey('nativeProof')) {
                            Assert-NativeLookupProof $event.nativeProof $event $true
                            $clock = Get-NativeProofClock $event.nativeProof
                            if ($null -ne $proofClock -and $proofClock -cne $clock) { throw 'Native admission deadline changed within a sample.' }
                            $proofClock = $clock
                        }
                        if ($event.phase -eq 'beforeCounters') {
                            if ($identities.ContainsKey($event.pid)) { throw 'Exited process has unexpected counters.' }
                        } elseif (-not $identities.ContainsKey($event.pid) -or $identities[$event.pid] -ne $event.startUtcTicks -or
                            ($event.phase -eq 'afterSnapshot' -and $event.role -ne 'ui')) { throw 'Lifecycle counters do not match.' }
                        $exited[$event.pid] = $true
                    }
                    $failureIndex = 0
                    foreach ($failure in $failures) {
                        if (($failure.Keys | Sort-Object) -join ',' -cnotin @('cimStartUtcTicks,errorCode,errorKind,exitCode,parentPid,pid,reason,source,stage',
                                'acquisition,cimStartUtcTicks,errorCode,errorKind,exitCode,parentPid,pid,reason,source,stage',
                                'cimStartUtcTicks,errorCode,errorKind,exitCode,nativeProof,parentPid,pid,reason,source,stage') -or
                            $failure.source -cnotin @('cim', 'retained') -or -not $recordReasons.ContainsKey($failure.reason) -or
                            $failure.stage -cnotin @('inventory', 'parent', 'lookup', 'handle', 'identity', 'role', 'counters', 'exit',
                                'nativeProof', 'nativeOpen', 'nativeAcquire', 'nativePid', 'nativeCreation', 'nativeWait', 'nativeExit') -or
                            $failure.errorKind -cnotin @('none', 'accessDenied', 'native', 'argument', 'invalidOperation', 'other')) { throw 'Invalid failure record.' }
                        foreach ($key in @('pid', 'parentPid', 'cimStartUtcTicks')) {
                            if ($failure[$key] -isnot [long] -or $failure[$key] -lt 0) { throw 'Invalid failure identity.' }
                        }
                        foreach ($key in @('errorCode', 'exitCode')) {
                            if ($null -ne $failure[$key] -and ($failure[$key] -isnot [long] -or $failure[$key] -lt [int]::MinValue -or $failure[$key] -gt [int]::MaxValue)) { throw 'Invalid failure code.' }
                        }
                        if ($failure.pid -le 1 -or $failure.pid -gt [uint32]::MaxValue -or $failure.parentPid -gt [uint32]::MaxValue -or
                            $failure.cimStartUtcTicks -le 0 -or $failure.cimStartUtcTicks -gt [DateTime]::MaxValue.Ticks -or
                            $failed.ContainsKey($failure.pid) -or $exited.ContainsKey($failure.pid) -or
                            ($failure.errorKind -eq 'accessDenied' -and $failure.errorCode -ne 5) -or
                            ($failure.errorKind -eq 'native' -and $null -eq $failure.errorCode) -or
                            ($failure.errorKind -in @('none', 'argument', 'invalidOperation', 'other') -and $null -ne $failure.errorCode)) { throw 'Invalid failure evidence.' }
                        if ($failure.ContainsKey('nativeProof')) {
                            Assert-NativeLookupProof $failure.nativeProof $failure $false
                            $clock = Get-NativeProofClock $failure.nativeProof
                            if ($null -ne $proofClock -and $proofClock -cne $clock) { throw 'Native admission deadline changed within a sample.' }
                            $proofClock = $clock
                        }
                        if ($failure.ContainsKey('acquisition')) {
                            if ($failureIndex -ge 8) { throw 'Acquisition provenance limit.' }
                            Assert-NativeAcquisition $failure.acquisition $failure
                        }
                        $failureIndex++
                        $failed[$failure.pid] = $true; $recordReasons[$failure.reason]++
                    }
                    foreach ($key in @($skipCounts.Keys)) {
                        if ($recordReasons[$key] -ne $skipCounts[$key]) { throw 'Failure reasons do not match.' }
                    }
                    $normalExitObservations += $events.Count
                }
                $lastElapsed = $row.elapsedMs; $gaps = $gaps -or $row.skipped -gt 0
                foreach ($key in @($skipTotals.Keys)) { $skipTotals[$key] += $skipCounts[$key] }
                if ($null -ne $rootSkipped) { $rootSkippedTotal += $rootSkipped }
                $peakWs = [Math]::Max($peakWs, $sumWs); $peakPrivate = [Math]::Max($peakPrivate, $sumPrivate)
                $row['skipReasonCounts'] = $skipCounts; $row['rootSkipped'] = $rootSkipped; $row['rootExitedDuringSample'] = $rootExited
                $row['lifecycleEvents'] = $events; $row['failedRecords'] = $failures
                [void] $row.Remove('kind'); $row['workingSetSumBytes'] = $sumWs; $row['privateBytesSum'] = $sumPrivate
                $samples.Add($row)
            }
        }
        foreach ($id in $nativeLookupPids.Keys) { if ($uiPids.ContainsKey($id)) { throw 'A root cannot use a lookup fallback.' } }
    } catch { $invalid = $true } # Fixed status only; never retain raw CIM/JSON errors.
    return [ordered]@{ schemaVersion = 3; incomplete = ($invalid -or $partial -or $gaps -or $Stop.forced -or -not $Stop.reaped -or $Stop.exitCode -ne 0 -or $null -eq $footer -or $footer.reason -ne 0 -or $samples.Count -eq 0 -or ($modernRecords -and -not $measuredRoot))
        collector = $Stop; invalidRecords = $invalid; partialLine = $partial; sampleGaps = $gaps; footer = $footer
        skipReasonCounts = $skipTotals; rootSkipped = $(if ($unknownRootSkips) { $null } else { $rootSkippedTotal }); normalExitObservations = $normalExitObservations
        firstSampleLagMs = $(if ($samples.Count) { $samples[0].elapsedMs + $samples[0].queryMs } else { $null }); milestonesMs = $Milestones
        sampledPeakWorkingSetSumBytes = $peakWs; sampledPeakPrivateBytesSum = $peakPrivate; samples = @($samples.ToArray())
        method = 'Approximately one snapshot/second during the owned UI lifetime; verified descendants retain their original process handles and UTC creation identities. A first-seen .NET lookup rejection can also be proved by a limited native handle, with the current parent verified and live before and after that proof. Explicit zero exits without an earlier read failure are lifecycle events, not fabricated zero counters or live descendant roots. Unverified/acquisition/read failures remain gaps. The observer is excluded from these sums, but its CPU/query overhead can affect the run. Working-set sums can double-count shared pages; they are not private working set. Private bytes are process-private committed memory, not macOS footprint. CPU is cumulative per process identity, not a whole-run total. Sampled maxima can miss startup peaks and short-lived processes. First-sample lag runs from before Process.Start to completion of the first snapshot; elapsedMs and queryMs retain its acquisition interval. Milestones are launch-to-stderr-receipt, not first paint. No beta16 comparison, steady-idle or complete N0 claim.' }
}

function Get-NativeObservationSummary([Collections.IDictionary] $Report, [ValidateRange(1, 3)] [int] $Run,
    [ValidateSet('fresh', 'owned')] [string] $Mode, [bool] $UiCompleted, [bool] $CollectorStarted) {
    # Only validated numeric fields and fixed names reach the CI log. Keep the
    # full report artifact, but never print paths, names or raw exceptions.
    $milestones = @{}; $missing = [Collections.Generic.List[string]]::new()
    $required = @('first-page-ready'); if ($Mode -eq 'owned') { $required += 'html-ready' }
    foreach ($key in $required) {
        if ($Report.milestonesMs.ContainsKey($key)) { $milestones[$key] = [double] $Report.milestonesMs[$key] }
        else { $missing.Add($key) }
    }
    $samples = @($Report.samples); $indices = [Collections.Generic.SortedSet[int]]::new()
    $acquisitionFailures = 0L; $acquisitionRecorded = 0L
    foreach ($sample in $samples) {
        foreach ($failure in $sample.failedRecords) {
            if ($failure.stage -eq 'nativeAcquire') {
                $acquisitionFailures++
                if ($failure.ContainsKey('acquisition')) { $acquisitionRecorded++ }
            }
        }
    }
    if ($samples.Count) {
        [void] $indices.Add(0)
        foreach ($i in @(([Math]::Max(0, $samples.Count - 2)), ($samples.Count - 1))) { [void] $indices.Add($i) }
        for ($i = 0; $i -lt $samples.Count; $i++) {
            if ($samples[$i].skipped -gt 0 -or $samples[$i].lifecycleEvents.Count -gt 0) {
                foreach ($j in @(([Math]::Max(0, $i - 1)), $i, ([Math]::Min($samples.Count - 1, $i + 1)))) { [void] $indices.Add($j) }
                break
            }
        }
    }
    $timeline = @(
        foreach ($i in $indices) {
            $sample = $samples[$i]; $roles = @{ ui = 0; service = 0; webview = 0; other = 0 }
            foreach ($process in $sample.processes) { $roles[$process.role]++ }
            [ordered]@{ sample = $i; elapsedMs = $sample.elapsedMs; queryMs = $sample.queryMs; observedRoles = $roles
                skipped = $sample.skipped; rootSkipped = $sample.rootSkipped; rootExitedDuringSample = $sample.rootExitedDuringSample
                skipReasonCounts = $sample.skipReasonCounts; lifecycleEvents = $sample.lifecycleEvents; failedRecords = $sample.failedRecords }
        }
    )
    return [ordered]@{ schemaVersion = 2; run = $Run; mode = $Mode; uiCompleted = $UiCompleted; collectorStarted = $CollectorStarted
        incomplete = ($Report.incomplete -or $missing.Count -gt 0); invalidRecords = $Report.invalidRecords; partialLine = $Report.partialLine; sampleGaps = $Report.sampleGaps
        collector = @{ forced = [bool] $Report.collector.forced; reaped = [bool] $Report.collector.reaped; exitCode = $Report.collector.exitCode }
        footer = $Report.footer; sampleCount = $samples.Count; skipReasonCounts = $Report.skipReasonCounts; rootSkipped = $Report.rootSkipped
        normalExitObservations = $Report.normalExitObservations
        acquisitionProvenance = @{ version = 1; failureRecordLimit = 8; nativeAcquireFailures = $acquisitionFailures
            recorded = $acquisitionRecorded; unavailable = ($acquisitionFailures - $acquisitionRecorded) }
        milestonesMs = $milestones; missingMilestones = @($missing.ToArray()); timeline = $timeline }
}

function Get-NativeObservationSamples([Collections.IDictionary] $Report, [ValidateRange(1, 3)] [int] $Run,
    [ValidateSet('fresh', 'owned')] [string] $Mode) {
    # Each source sample passed the strict parser (32 KiB/record, 180 records,
    # 2 MiB file). Export event/gap neighborhoods and the edges, explicitly as a
    # selection, not a complete trace. Full validated JSON stays in the artifact.
    $samples = @($Report.samples); $indices = [Collections.Generic.SortedSet[int]]::new()
    if ($samples.Count) {
        [void] $indices.Add(0); [void] $indices.Add($samples.Count - 1)
        for ($i = 0; $i -lt $samples.Count; $i++) {
            if ($samples[$i].skipped -gt 0 -or $samples[$i].lifecycleEvents.Count -gt 0) {
                foreach ($j in @(([Math]::Max(0, $i - 1)), $i, ([Math]::Min($samples.Count - 1, $i + 1)))) { [void] $indices.Add($j) }
            }
        }
    }
    foreach ($i in $indices) {
        $sample = $samples[$i]
        [ordered]@{ run = $Run; mode = $Mode; selection = 'all-event-and-gap-neighbors-and-edges'; selectedSamples = $indices.Count
            totalSamples = $samples.Count; sample = $i; elapsedMs = $sample.elapsedMs; queryMs = $sample.queryMs
            skipped = $sample.skipped; rootSkipped = $sample.rootSkipped; rootExitedDuringSample = $sample.rootExitedDuringSample
            skipReasonCounts = $sample.skipReasonCounts; processes = $sample.processes
            lifecycleEvents = $sample.lifecycleEvents; failedRecords = $sample.failedRecords
            workingSetSumBytes = $sample.workingSetSumBytes; privateBytesSum = $sample.privateBytesSum }
    }
}

function Test-NativeResourceObservation {
    function Check([bool] $Value) { if (-not $Value) { throw 'Native observation self-check failed.' } }
    $ticks = 638999000000000007L
    Check (Test-NativeCreation $ticks $ticks ($ticks - 7))
    Check (-not (Test-NativeCreation ($ticks + 10) $ticks ($ticks - 7)))
    $date = [DateTime]::new($ticks - 7, [DateTimeKind]::Utc)
    $rows = @(@{ ProcessId = 20; ParentProcessId = 10; CreationDate = $date }, @{ ProcessId = 21; ParentProcessId = 20; CreationDate = $date.AddSeconds(1) },
        @{ ProcessId = 22; ParentProcessId = 20; CreationDate = $date.AddSeconds(-1) }, @{ ProcessId = 23; ParentProcessId = 999; CreationDate = $date.AddSeconds(1) })
    $tree = @(Get-NativeTree $rows 20 $ticks)
    Check ($tree.Count -eq 2 -and $tree[1].ProcessId -eq 21)
    $rejected = $false; try { [void] (Get-NativeTree $rows 20 ($ticks + 10)) } catch { $rejected = $true }; Check $rejected
    $tooMany = @($rows[0]) + @(1..64 | ForEach-Object { @{ ProcessId = 30 + $_; ParentProcessId = 20; CreationDate = $date.AddSeconds(1) } })
    $rejected = $false; try { [void] (Get-NativeTree $tooMany 20 $ticks) } catch { $rejected = $true }; Check $rejected
    $path = Join-Path ([IO.Path]::GetTempPath()) ('morrow-resource-self-check-' + [Guid]::NewGuid().ToString('N'))
    $stream = [IO.File]::Open($path, [IO.FileMode]::CreateNew, [IO.FileAccess]::ReadWrite, [IO.FileShare]::Read)
    $sample = @{ kind = 0; elapsedMs = 12.5; queryMs = 3.0; skipped = 0; processes = @(@{ pid = 20L; parentPid = 10L; startUtcTicks = $ticks; role = 'ui'; workingSetBytes = 5000000000L; privateBytes = 3000000000L; cpuMs = 12.0 }) }
    $stop = @{ forced = $false; reaped = $true; exitCode = 0 }
    function Read-ObservationFixture([object[]] $Records, $CollectorStop = $stop, $Milestones = @{}) {
        $lines = @($Records | ForEach-Object { $_ | ConvertTo-Json -Compress -Depth 6 })
        [IO.File]::WriteAllText($path, (($lines -join "`n") + "`n"), [Text.UTF8Encoding]::new($false))
        return Read-NativeResourceReport $path $CollectorStop $Milestones
    }
    try {
        Check (Write-NativeSample $stream $sample)
        Check (Write-NativeSample $stream @{ kind = 1; reason = 0; samples = 1 })
        $stream.Dispose(); $stream = $null
        $projection = @(Read-NativeResourceReport $path $stop @{})
        Check ($projection.Count -eq 1) # No accidental Remove()/collection output.
        $report = $projection[0]
        Check (-not $report.incomplete -and $report.sampledPeakWorkingSetSumBytes -eq 5000000000L -and $report.firstSampleLagMs -eq 15.5)
        Check ($report.samples[0].processes[0].startUtcTicks -eq $ticks)

        # Old records remain readable, with unknown reasons explicitly retained.
        $legacyGap = $sample.Clone(); $legacyGap.skipped = 1
        $report = Read-ObservationFixture @($legacyGap, @{ kind = 1; reason = 0; samples = 1 })
        Check ($report.incomplete -and $report.skipReasonCounts.unclassified -eq 1 -and $null -eq $report.rootSkipped)
        Check ($report.footer.failureStage -ceq 'unclassified')

        $detailed = $sample.Clone(); $detailed['rootSkipped'] = 0L; $detailed['rootExitedDuringSample'] = $false
        $detailed['skipReasonCounts'] = New-NativeSkipReasonCounts
        $footer = @{ kind = 1; reason = 0; samples = 1; failureStage = 'none' }
        $markers = @{ 'first-page-ready' = 15.0; 'html-ready' = 25.0; 'secret-token' = 30.0 }
        $report = Read-ObservationFixture @($detailed, $footer) $stop $markers
        Check (-not $report.incomplete -and $report.footer.failureStage -ceq 'none')
        $summary = Get-NativeObservationSummary $report 1 fresh $true $true
        Check (-not $summary.incomplete -and $summary.missingMilestones.Count -eq 0 -and $summary.sampleCount -eq 1)
        Check (@(Get-NativeObservationSamples $report 1 fresh).Count -eq 1)

        $modern = $detailed.Clone(); $modern.lifecycleEvents = @(); $modern.failedRecords = @()
        $exit = @{ pid = 21L; parentPid = 20L; startUtcTicks = $ticks + 10L; role = 'other'
            exitCode = 0L; phase = 'beforeCounters'; source = 'retained'; identitySource = 'priorSnapshot' }
        $modern.lifecycleEvents = @($exit)
        $report = Read-ObservationFixture @($modern, $footer) $stop $markers
        Check (-not $report.incomplete -and $report.normalExitObservations -eq 1 -and -not $report.sampleGaps)
        Check ($report.samples[0].lifecycleEvents[0].startUtcTicks -eq $ticks + 10L)
        $nativeExit = $exit.Clone(); $nativeExit.source = 'cim'; $nativeExit.identitySource = 'nativeLookupFallback'
        $nativeSample = $modern.Clone(); $nativeSample.lifecycleEvents = @($nativeExit)
        $report = Read-ObservationFixture @($nativeSample, $footer)
        Check (-not $report.incomplete -and $report.normalExitObservations -eq 1 -and -not $report.invalidRecords)
        $nativeOnly = $nativeSample.Clone(); $nativeOnly.processes = @()
        $report = Read-ObservationFixture @($nativeOnly, $footer)
        Check ($report.incomplete -and -not $report.invalidRecords) # An exit proof is not a measured UI sample.
        foreach ($case in @('source', 'role', 'phase', 'counter', 'root', 'parent')) {
            $bad = $nativeSample.Clone(); $bad.lifecycleEvents = @($nativeExit.Clone())
            switch ($case) {
                'source' { $bad.lifecycleEvents[0].source = 'retained' }
                'role' { $bad.lifecycleEvents[0].role = 'ui' }
                'phase' { $bad.lifecycleEvents[0].phase = 'afterCounters' }
                'counter' { $extra = $sample.processes[0].Clone(); $extra.pid = 21L; $extra.role = 'other'; $extra.startUtcTicks = $ticks + 10L; $bad.processes = @($sample.processes[0], $extra) }
                'root' { $bad.lifecycleEvents[0].pid = 20L; $bad.lifecycleEvents[0].parentPid = 19L; $bad.processes = @() }
                'parent' { $bad.lifecycleEvents[0].parentPid = 21L }
            }
            $prior = $detailed.Clone(); $prior.elapsedMs = 0.0
            $two = $footer.Clone(); $two.samples = 2
            $report = Read-ObservationFixture @($prior, $bad, $two)
            Check ($report.incomplete -and $report.invalidRecords)
        }
        $failure = @{ pid = 21L; parentPid = 20L; cimStartUtcTicks = $ticks + 3L; source = 'cim'
            reason = 'processUnavailable'; stage = 'lookup'; errorKind = 'argument'; errorCode = $null; exitCode = $null }
        $modernGap = $modern.Clone(); $modernGap.lifecycleEvents = @(); $modernGap.failedRecords = @($failure)
        $modernGap.skipped = 1L; $modernGap.skipReasonCounts = New-NativeSkipReasonCounts; $modernGap.skipReasonCounts.processUnavailable = 1L
        $report = Read-ObservationFixture @($modernGap, $footer) $stop $markers
        Check ($report.incomplete -and -not $report.invalidRecords -and $report.normalExitObservations -eq 0)
        $nativeDenied = $failure.Clone(); $nativeDenied.stage = 'nativeOpen'; $nativeDenied.errorKind = 'accessDenied'; $nativeDenied.errorCode = 5L
        $nativeGap = $modernGap.Clone(); $nativeGap.failedRecords = @($nativeDenied)
        $report = Read-ObservationFixture @($nativeGap, $footer)
        Check ($report.incomplete -and -not $report.invalidRecords -and $report.skipReasonCounts.processUnavailable -eq 1)
        $nativeMissing = $nativeDenied.Clone(); $nativeMissing.errorKind = 'native'; $nativeMissing.errorCode = 87L
        $nativeGap.failedRecords = @($nativeMissing)
        $report = Read-ObservationFixture @($nativeGap, $footer)
        Check ($report.incomplete -and -not $report.invalidRecords -and $report.normalExitObservations -eq 0)
        foreach ($openFailure in @($nativeDenied, $nativeMissing)) {
            $firstOpen = $openFailure.Clone(); $firstOpen.stage = 'nativeAcquire'; $nativeGap.failedRecords = @($firstOpen)
            $report = Read-ObservationFixture @($nativeGap, $footer)
            Check ($report.incomplete -and -not $report.invalidRecords -and $report.skipReasonCounts.processUnavailable -eq 1 -and $report.normalExitObservations -eq 0)
        }
        $provenance = @{ version = 1L; source = 'worker-scan'; nativeError = 87L; clockFrequency = 1000L
            windowStartedAtQpc = 100000L; windowStoppedAtQpc = 100020L; scan = 2L; scanStartedAtQpc = 100001L
            windowUtcTicks = $ticks; windowUtcReadCompletedAtQpc = 100000L; priorScan = 1L; priorScanCompletedAtQpc = 100001L
            snapshotReadyAtQpc = 100002L; openStartedAtQpc = 100003L; openCompletedAtQpc = 100004L; cimReceivedAtQpc = 100010L }
        foreach ($origin in @('worker-scan', 'initial-scan', 'cim-row', 'admission')) {
            $value = $provenance.Clone(); $value.source = $origin
            if ($origin -eq 'initial-scan') { $value.scan = 1L; $value.priorScan = 0L; $value.priorScanCompletedAtQpc = 0L }
            if ($origin -in @('cim-row', 'admission')) {
                $value.scan = 0L; $value.scanStartedAtQpc = 0L; $value.snapshotReadyAtQpc = 0L
                $value.cimReceivedAtQpc = 100001L
            }
            if ($origin -eq 'admission') {
                $value.windowStartedAtQpc = 0L; $value.windowStoppedAtQpc = 0L; $value.cimReceivedAtQpc = 0L
                $value.windowUtcTicks = 0L; $value.windowUtcReadCompletedAtQpc = 0L; $value.priorScan = 0L; $value.priorScanCompletedAtQpc = 0L
            }
            $firstOpen.acquisition = $value
            $report = Read-ObservationFixture @($nativeGap, $footer)
            Check ($report.incomplete -and -not $report.invalidRecords -and $report.normalExitObservations -eq 0 -and
                $report.samples[0].failedRecords[0].acquisition.source -ceq $origin -and
                $report.samples[0].failedRecords[0].acquisition.openStartedAtQpc -eq 100003L)
        }
        foreach ($case in @('extra-field', 'missing-field', 'source', 'version', 'fractional', 'string', 'boolean', 'negative',
            'frequency', 'open-order', 'window-order', 'scan-order', 'snapshot-order', 'initial-sequence', 'worker-sequence',
            'row-before-window', 'row-after-window', 'row-after-open', 'no-window-scan', 'duration', 'code', 'exit', 'stage',
            'utc-range', 'utc-bracket', 'scan-before-bracket', 'prior-scan', 'prior-time', 'prior-after-scan', 'prior-before-bracket')) {
            $value = $provenance.Clone(); $bad = $nativeGap.Clone(); $bad.failedRecords = @($firstOpen.Clone()); $bad.failedRecords[0].acquisition = $value
            switch ($case) {
                'extra-field' { $value['secret-token'] = 'secret-token' }
                'missing-field' { [void] $value.Remove('scan') }
                'source' { $value.source = 'secret-token' }
                'version' { $value.version = 2L }
                'fractional' { $value.scan = 2.5 }
                'string' { $value.openStartedAtQpc = '100003' }
                'boolean' { $value.openStartedAtQpc = $true }
                'negative' { $value.openStartedAtQpc = -1L }
                'frequency' { $value.clockFrequency = 10000000001L }
                'open-order' { $value.openCompletedAtQpc = 100002L }
                'window-order' { $value.windowStoppedAtQpc = 100003L }
                'scan-order' { $value.scanStartedAtQpc = 99999L }
                'snapshot-order' { $value.snapshotReadyAtQpc = 100004L }
                'initial-sequence' { $value.source = 'initial-scan' }
                'worker-sequence' { $value.scan = 1L }
                'row-before-window' { $value.cimReceivedAtQpc = 99999L }
                'row-after-window' { $value.cimReceivedAtQpc = 100021L }
                'row-after-open' { $value.source = 'cim-row'; $value.scan = 0L; $value.scanStartedAtQpc = 0L; $value.snapshotReadyAtQpc = 0L }
                'no-window-scan' { $value.windowStartedAtQpc = 0L; $value.windowStoppedAtQpc = 0L }
                'duration' { $value.windowStoppedAtQpc = 280001L }
                'code' { $value.nativeError = 5L }
                'exit' { $bad.failedRecords[0].exitCode = 0L }
                'stage' { $bad.failedRecords[0].stage = 'lookup' }
                'utc-range' { $value.windowUtcTicks = [long]::MaxValue }
                'utc-bracket' { $value.windowUtcReadCompletedAtQpc = 100004L }
                'scan-before-bracket' { $value.windowUtcReadCompletedAtQpc = 100002L }
                'prior-scan' { $value.priorScan = 2L }
                'prior-time' { $value.priorScanCompletedAtQpc = 100004L }
                'prior-after-scan' { $value.priorScanCompletedAtQpc = 100002L }
                'prior-before-bracket' { $value.priorScanCompletedAtQpc = 99999L }
            }
            $report = Read-ObservationFixture @($bad, $footer)
            Check ($report.incomplete -and $report.invalidRecords)
            Check ((Get-NativeObservationSummary $report 2 owned $true $true | ConvertTo-Json -Depth 8) -cnotmatch 'secret-token')
        }
        # All 64 failure records survive; only the first eight carry optional
        # provenance. Use large Int64 clocks to exercise the actual byte bound.
        $bounded = $modernGap.Clone(); $bounded.processes = @(); $bounded.skipped = 0L; $bounded.rootSkipped = 0L
        $bounded.skipReasonCounts = New-NativeSkipReasonCounts; $bounded.failedRecords = [Collections.Generic.List[object]]::new()
        $trace = @{ Source = 'worker-scan'; NativeError = 87; WindowStartedAtQpc = 9223372036854000000L
            WindowStoppedAtQpc = 9223372036854000020L; Scan = 2L; ScanStartedAtQpc = 9223372036854000001L
            WindowUtcTicks = $ticks; WindowUtcReadCompletedAtQpc = 9223372036854000000L
            PriorScan = 1L; PriorScanCompletedAtQpc = 9223372036854000001L
            SnapshotReadyAtQpc = 9223372036854000002L; OpenStartedAtQpc = 9223372036854000003L
            OpenCompletedAtQpc = 9223372036854000004L; CimReceivedAtQpc = 9223372036854000010L }
        foreach ($id in 100..162) {
            $row = @{ ProcessId = $id; ParentProcessId = 20; CreationDate = [DateTime]::new($ticks, [DateTimeKind]::Utc) }
            Add-NativeObservationFailure $bounded $row 20 cim processUnavailable nativeAcquire ([ComponentModel.Win32Exception]::new(87)) $null $null $trace
        }
        Add-NativeObservationFailure $bounded @{ ProcessId = 20; ParentProcessId = 10; CreationDate = [DateTime]::new($ticks, [DateTimeKind]::Utc) } 20 retained processUnavailable inventory
        $bounded.failedRecords = @($bounded.failedRecords.ToArray())
        Check ($bounded.failedRecords.Count -eq 64 -and @($bounded.failedRecords | Where-Object { $_.Contains('acquisition') }).Count -eq 8)
        $report = Read-ObservationFixture @($bounded, $footer)
        Check ($report.incomplete -and -not $report.invalidRecords -and $report.samples[0].failedRecords.Count -eq 64 -and
            $report.samples[0].failedRecords[0].acquisition.openStartedAtQpc -eq 9223372036854000003L)
        $summary = Get-NativeObservationSummary $report 2 owned $true $true
        Check ($summary.acquisitionProvenance.nativeAcquireFailures -eq 63 -and $summary.acquisitionProvenance.recorded -eq 8 -and
            $summary.acquisitionProvenance.unavailable -eq 55)
        $bounded.failedRecords[8]['acquisition'] = $bounded.failedRecords[0].acquisition
        $report = Read-ObservationFixture @($bounded, $footer)
        Check ($report.incomplete -and $report.invalidRecords)
        $denied = $failure.Clone(); $denied.reason = 'counterReadFailed'; $denied.stage = 'counters'
        $denied.errorKind = 'accessDenied'; $denied.errorCode = 5L; $denied.exitCode = 0L
        $deniedGap = $modernGap.Clone(); $deniedGap.failedRecords = @($denied)
        $deniedGap.skipReasonCounts = New-NativeSkipReasonCounts; $deniedGap.skipReasonCounts.counterReadFailed = 1L
        $report = Read-ObservationFixture @($deniedGap, $footer) $stop $markers
        Check ($report.incomplete -and -not $report.invalidRecords -and $report.skipReasonCounts.counterReadFailed -eq 1)
        Check ($report.samples[0].failedRecords[0].exitCode -eq 0)
        $onlyExit = $modern.Clone(); $onlyExit.processes = @()
        $report = Read-ObservationFixture @($onlyExit, $footer)
        Check ($report.incomplete -and -not $report.invalidRecords) # No measured UI counters.
        foreach ($case in @('event-code', 'event-phase', 'event-fields', 'event-duplicate', 'event-counters',
            'failure-code', 'failure-count', 'failure-duplicate', 'failure-and-exit')) {
            $bad = $modern.Clone(); $bad.lifecycleEvents = @($exit.Clone())
            switch ($case) {
                'event-code' { $bad.lifecycleEvents[0].exitCode = 7L }
                'event-phase' { $bad.lifecycleEvents[0].phase = 'secret-token' }
                'event-fields' { $bad.lifecycleEvents[0]['secret-token'] = 1L }
                'event-duplicate' { $bad.lifecycleEvents = @($exit, $exit) }
                'event-counters' { $bad.lifecycleEvents[0].phase = 'afterCounters' }
                'failure-code' { $bad = $deniedGap.Clone(); $bad.failedRecords = @($denied.Clone()); $bad.failedRecords[0].errorCode = 0L }
                'failure-count' { $bad = $modernGap.Clone(); $bad.failedRecords = @() }
                'failure-duplicate' { $bad = $modernGap.Clone(); $bad.failedRecords = @($failure, $failure) }
                'failure-and-exit' { $bad = $modernGap.Clone(); $bad.lifecycleEvents = @($exit) }
            }
            $report = Read-ObservationFixture @($bad, $footer)
            Check ($report.incomplete -and $report.invalidRecords)
            Check ((Get-NativeObservationSummary $report 2 owned $true $true | ConvertTo-Json -Depth 8) -cnotmatch 'secret-token')
        }

        $childGap = $detailed.Clone(); $childGap.elapsedMs = 1012.5; $childGap.skipped = 1L
        $childGap.skipReasonCounts = New-NativeSkipReasonCounts; $childGap.skipReasonCounts.processExited = 1L
        $rootGap = $childGap.Clone(); $rootGap.elapsedMs = 2012.5; $rootGap.rootSkipped = 1L
        $rootGap.rootExitedDuringSample = $true; $rootGap.processes = @()
        $end = $footer.Clone(); $end.samples = 3
        $report = Read-ObservationFixture @($detailed, $childGap, $rootGap, $end) $stop $markers
        Check ($report.incomplete -and $report.sampleGaps -and $report.skipReasonCounts.processExited -eq 2 -and $report.rootSkipped -eq 1)
        $report['candidate'] = @{ path = 'secret-token' }
        $summary = Get-NativeObservationSummary $report 2 owned $true $true
        $evidence = @(Get-NativeObservationSamples $report 2 owned)
        Check ($summary.incomplete -and $summary.timeline.Count -eq 3 -and $evidence.Count -eq 3)
        Check ($evidence[1].rootSkipped -eq 0 -and -not $evidence[1].rootExitedDuringSample -and $evidence[2].rootExitedDuringSample)
        Check ($evidence[1].elapsedMs -eq 1012.5 -and $evidence[2].processes.Count -eq 0)
        Check ((@{ summary = $summary; selected = $evidence } | ConvertTo-Json -Depth 10) -cnotmatch 'secret-token|candidate')

        # Diagnostics do not turn real evidence failures into complete reports.
        $report = Read-ObservationFixture @($detailed, $footer) @{ forced = $true; reaped = $true; exitCode = -1 }
        Check ($report.incomplete -and $report.collector.forced)
        $report = Read-ObservationFixture @($detailed)
        Check ($report.incomplete -and $null -eq $report.footer)
        $report = Read-ObservationFixture @($detailed, $footer)
        $summary = Get-NativeObservationSummary $report 3 owned $true $true
        Check ($summary.incomplete -and $summary.missingMilestones.Count -eq 2)
        $report = Read-ObservationFixture @(@{ kind = 1; reason = 3; samples = 0; failureStage = 'cim' })
        $summary = Get-NativeObservationSummary $report 2 owned $false $true
        Check ($summary.incomplete -and $summary.sampleCount -eq 0 -and $summary.footer.failureStage -ceq 'cim')

        foreach ($case in @('unknown-reason', 'count-mismatch', 'negative', 'fractional', 'unknown-stage', 'invalid-root')) {
            $bad = $detailed.Clone(); $bad.skipReasonCounts = New-NativeSkipReasonCounts; $badFooter = $footer.Clone()
            switch ($case) {
                'unknown-reason' { $bad.skipReasonCounts['secret-token'] = 1L }
                'count-mismatch' { $bad.skipReasonCounts.processExited = 1L }
                'negative' { $bad.skipReasonCounts.processExited = -1L }
                'fractional' { $bad.skipReasonCounts.processExited = 0.5 }
                'unknown-stage' { $badFooter.failureStage = 'secret-token' }
                'invalid-root' { $bad.rootExitedDuringSample = 'secret-token' }
            }
            $report = Read-ObservationFixture @($bad, $badFooter)
            Check ($report.incomplete -and $report.invalidRecords)
            Check ((Get-NativeObservationSummary $report 2 owned $true $true | ConvertTo-Json -Depth 8) -cnotmatch 'secret-token')
        }
        $line = ($sample | ConvertTo-Json -Compress -Depth 5) + "`n"
        [IO.File]::WriteAllText($path, $line + '{"secret-token":"incomplete', [Text.UTF8Encoding]::new($false))
        $report = Read-NativeResourceReport $path $stop @{}
        Check ($report.incomplete -and $report.partialLine -and $report.samples.Count -eq 1 -and ($report | ConvertTo-Json -Depth 8) -cnotmatch 'secret-token')
        $sample.processes[0].role = 'secret-token'
        [IO.File]::WriteAllText($path, ($sample | ConvertTo-Json -Compress -Depth 5) + "`n", [Text.UTF8Encoding]::new($false))
        $report = Read-NativeResourceReport $path $stop @{}
        Check ($report.incomplete -and $report.invalidRecords -and $report.samples.Count -eq 0)
        $stream = [IO.File]::OpenWrite($path); $stream.Position = 2MB - 513
        Check (-not (Write-NativeSample $stream $sample))
        $stream.SetLength(2MB + 1); $stream.Dispose(); $stream = $null
        Check (Read-NativeResourceReport $path $stop @{}).invalidRecords
        Write-Host 'Native observation identity, bounds, 64-bit counters and partial-record checks passed.'
    } finally { if ($stream) { $stream.Dispose() }; [IO.File]::Delete($path) }
    . (Join-Path $PSScriptRoot 'test-native-pinned-exit.ps1')
    Test-NativePinnedExitSchema
    . (Join-Path $PSScriptRoot 'test-native-process-lifecycle.ps1')
    Test-NativeProcessLifecycle
}

if ($SelfTest) { Test-NativeResourceObservation; return }
if ($MyInvocation.InvocationName -eq '.') { return }
try { Invoke-NativeResourceCollector *> $null; exit 0 } catch { exit 1 }
